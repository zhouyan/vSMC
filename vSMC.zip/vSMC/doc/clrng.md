Generating random numbers on OpenCL device {#clrng}
===================================================

# The problem

The [Random123][Random123] library is ideal for generating random numbers on
OpenCL device. It is easy to use, for example, say inside a kernel, to generate
four standard normal random variates,
~~~{.c}
#include <Random123/threefry64.h>
#include <Random123/u01.h>

threefry4x32_ctr_t c = {{}};
threefry4x32_key_t k = {{}};
k.v[0] = get_global_id(0);
c.v[0] = iter; // some iteration number change between kernel calls.
threefry4x32_ctr_t r = threefry4x32(c, k);
float u[4];
float z[4];
for (int i = 0; i != 4; ++i)
    u[i] = u01_open_closed_32_24(r.v[i]);
z[0] = sqrt(-2 * log(u[0])) * cos(2 * M_PI_F * u[1]);
z[1] = sqrt(-2 * log(u[0])) * sin(2 * M_PI_F * u[1]);
z[2] = sqrt(-2 * log(u[2])) * cos(2 * M_PI_F * u[3]);
z[3] = sqrt(-2 * log(u[2])) * sin(2 * M_PI_F * u[3]);
~~~
As seen above, for every call to `threefry4x32` we can generate four standard
normal random variates. It is fine if we just happen to need four random
numbers. But this is rarely the case. Then we need some tricky code to keep
track of when to call `threefry4x32` again etc., or call it every time we need
a random number and waste a lot of time and generated numbers.

# General utilities

vSMC's OpenCL module provide some facilities partially solve this problem.
First it provide a set of engine wrappers around the raw counter-based RNGs in
`<urng.h>`. Four engines are defined, `cburng2x32`, `cburng4x32`, `cburng2x64`
and `cburng4x64`. By default they use the corresponding Threefry engines. To
configure them to use the Philox engine, define macros `CBRNG2x32` etc. For
example
~~~{.c}
#define CBRNG2x32 philox2x32
~~~
It is the users' responsibility to make sure the macros are correctly defines.
If the macro name and the engine has different bits or width, then the
behaviors are undefined.

To use these engines to generate uniform random numbers,
~~~{.c}
#include <vsmc/opencl/urng.h>

cburng4x32 rng;
cburng4x32_init(&rng);
rng.key.v[0] = get_global_id(0);
rng.ctr.v[0] = iter;
for (int i = 0; i != N; ++i) {
    float u = u01_open_closed_32_24(cburng4x32_rand(&rng));
    // do something with u
}
~~~
Repeated call to `cburng4x32_rand` generate uniform 32 bits unsigned random
integers and can be later converted to other distribution random variates. Note
that the underlying mechanism is still the same, the counter `rng.ctr` is
incremented every time `threefry4x32` is implicitly called, which happens every
four call to `cburng4x32_rand`. The upside is that, first we don't need to
track when to call it ourselves and at most we waste three random numbers.

One shall note that the counter `rng.ctr` need to be set carefully so that
different kernel calls to the same engine with the same key does not overlap
their use of counters. OpenCL does not support static variables and thus
generally we cannot save the rng states between kernel calls. We will see a
workaround later.

To generate standard normal random variates, one can use the following similar
functions
~~~{.c}
#include <vsmc/opencl/normal01.h>

cburng4x32 rng;
cburng4x32_init(&rng);
rng.key.v[0] = get_global_id(0);
rng.ctr.v[0] = iter;
normal01_4x32_24 srnorm; // single precision
normal01_4x32_53 srnorm; // double precision
for (int i = 0; i != N; ++i) {
    float  sz = normal01_4x32_24(&rnorm, &rng);
    double dz = normal01_4x32_53(&rnorm, &rng);
    // do something with these random variates
}
~~~
The most inconvenient part is that the setting of counter. A better solution is
to keep the states of the counter between kernel calls. For example
~~~{.c}
__kernel void ker (__global struct r123array4x32 *counter)
{
    cburng4x32 rng;
    cburng4x32_init(&rng);
    rng.key.v[0] = get_global_id(0);
    rng.ctr = counter[get_global_id(0)];
    // use RNG
    counter[i] = rng.ctr;
}
~~~
If you want you can even save the whole RNG between kernel calls, but that will
involve about three times memory copy. And copying between device and the
global memory is not cheap. In most cases, we can afford waste a few random
numbers instead more than copy a few more large structures. In addition, in
this way, the counter can be reused between different kernels.

# vSMC specific utilities

In vSMC, if a OpenCL program is build by `vsmc::StateCL::build`, then a few
macros and typedef are predefined before the user source. See the documentation
for details. Among them one is `fp_type`, which is a typedef of `float` or
`double` depend on the template parameter of `vsmc::StateCL`. There are
situations that we need the same OpenCL source to work with both `float` and
`double` state types. In this case, a few macros are defined, such as
`U01_OPEN_CLOSED_32`, `NORMAL01_4x32`. They are alias to
`u01_open_closed_32_24` and `normal01_4x32_24` if `fp_type` is `float`, or
their corresponding double precision versions if `fp_type` is `double`.  For
example,
~~~{.c}
cburng4x32 rng;
cburng4x32_init(&rng);
rng.key.v[0] = get_global_id(0);
NORMAL01_4x32 rnorm;
for (int i = 0; i != N; ++i) {
    fp_type z = NORMAL01_4x32(&rnorm, &rng);
    // do something with these random variates
}
~~~
and on the host side,
~~~{.cpp}
if (device_support_double) {
  vsmc::Sampler<StateCL<Dim, cl_double> > sampler(N);
  // ...
} else {
  vsmc::Sampler<StateCL<Dim, cl_float> > sampler(N);
  // ...
}
~~~
In the above example, the code on the device side does not need to change
regardless if the host side decided to use single or double precision floating
points.

[Boost]: http://www.boost.org/
[Random123]: http://www.thesalmons.org/john/random123/releases/latest/docs/index.html
[libdispatch]: http://libdispatch.macosforge.org/
