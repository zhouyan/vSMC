#ifndef VSMC_EXAMPLE_PF_MPI_DO_HPP
#define VSMC_EXAMPLE_PF_MPI_DO_HPP

template <vsmc::MatrixOrder Order>
inline void cv_do (vsmc::ResampleScheme res, char *argv[],
        const std::string &name)
{
    vsmc::Seed::instance().set(101);
    std::size_t N =
        (ParticleNum / 3) * (boost::mpi::communicator().rank() + 1);
    vsmc::Sampler<cv_state<Order> > sampler(N, res);
    sampler
        .init(cv_init<Order>())
        .move(vsmc::MoveAdapter<
                cv_state<Order>, BASE_MOVE, cv_move<Order> >(), true)
        .monitor("pos", 2, vsmc::MonitorEvalAdapter<
                cv_state<Order>, BASE_MONITOR>(cv_est<Order>));
    sampler.initialize(argv[1]);
    sampler.try_iterate(DataNum - 1);

    std::stringstream ss;
    ss << name << ".r" << sampler.particle().value().world().rank();
    std::ofstream est((argv[2] + ss.str()).c_str());
    est << sampler << std::endl;
    est.close();
    est.clear();

    const std::vector<std::size_t> &send_num =
        sampler.particle().value().copy_send_num();
    ss << ".send";
    std::ofstream send((argv[2] + ss.str()).c_str());
    for (std::size_t i = 0; i != send_num.size(); ++i)
        send << send_num[i] << '\n';
    send.close();
    send.clear();
}

#endif // VSMC_EXAMPLE_PF_MPI_DO_HPP
