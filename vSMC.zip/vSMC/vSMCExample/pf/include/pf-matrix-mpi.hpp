#ifndef VSMC_EXAMPLE_PF_MATRIX_MPI_@SMP@_HPP
#define VSMC_EXAMPLE_PF_MATRIX_MPI_@SMP@_HPP

#define BASE_STATE   vsmc::StateMPI
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@

#define WEIGHT_SET_TYPE typename base_state::weight_set_type

#include <vsmc/smp/state_matrix.hpp>
#include <vsmc/smp/backend_@smp@.hpp>
#include <vsmc/mpi/backend_mpi.hpp>

template <vsmc::MatrixOrder Order>
struct BaseState
{
    typedef vsmc::State@SMP@<vsmc::StateMatrix<Order, 5, double> > type;
};

#include "pf-smp.hpp"
#include "pf-mpi-do.hpp"

#endif // VSMC_EXAMPLE_PF_MATRIX_MPI_@SMP@_HPP
