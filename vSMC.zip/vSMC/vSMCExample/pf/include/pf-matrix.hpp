#ifndef VSMC_EXAMPLE_PF_MATRIX_@SMP@_HPP
#define VSMC_EXAMPLE_PF_MATRIX_@SMP@_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_WEIGHT  vsmc::WeightSet@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@

#define WEIGHT_SET_TYPE vsmc::WeightSet@SMP@<base_state>

#include <vsmc/smp/state_matrix.hpp>
#include <vsmc/smp/backend_@smp@.hpp>

template <vsmc::MatrixOrder Order>
struct BaseState {typedef vsmc::StateMatrix<Order, 5, double> type;};

#include "pf-smp.hpp"
#include "pf-smp-do.hpp"

#endif // VSMC_EXAMPLE_PF_MATRIX_@SMP@_HPP
