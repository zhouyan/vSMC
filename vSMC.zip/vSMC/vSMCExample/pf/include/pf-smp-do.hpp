#ifndef VSMC_EXAMPLE_PF_SMP_DO_HPP
#define VSMC_EXAMPLE_PF_SMP_DO_HPP

template <vsmc::MatrixOrder Order>
inline void cv_do (vsmc::ResampleScheme res, char *argv[],
        const std::string &name)
{
    vsmc::Seed::instance().set(101);
    vsmc::Sampler<cv_state<Order> > sampler(ParticleNum, res);
    sampler
        .init(cv_init<Order>())
        .move(vsmc::MoveAdapter<
                cv_state<Order>, BASE_MOVE, cv_move<Order> >(), true)
        .monitor("pos", 2, vsmc::MonitorEvalAdapter<
                cv_state<Order>, BASE_MONITOR>(cv_est<Order>));
    sampler.initialize(argv[1]);
    sampler.try_iterate(DataNum - 1);

    std::ofstream est((argv[2] + name).c_str());
    est << sampler << std::endl;
    est.close();
    est.clear();
}

#endif // VSMC_EXAMPLE_PF_SMP_DO_HPP
