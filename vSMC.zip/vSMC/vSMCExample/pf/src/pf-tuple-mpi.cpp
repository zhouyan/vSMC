#include "pf-tuple-mpi-@smp@.hpp"

int main (int argc, char *argv[])
{
    vsmc::MPIEnvironment env(argc, argv);
    @HALF_NUM_THREADS@;
#include "pf-smp-main.hpp"
}
