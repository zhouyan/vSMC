#include "pf-cl.hpp"

cl_device_type cv_device::opencl_device_type::value = 0;

int main (int argc, char *argv[])
{
    if (argc < 4) {
        std::cout << "Usage: " << argv[0]
            << " <input file>"
            << " <output file>"
            << " <resample scheme>"
            << std::endl;
        return -1;
    }

    vsmc::ResampleScheme ResScheme = vsmc::Stratified;
    if (!std::strcmp(argv[3], "Multinomial"))
        ResScheme = vsmc::Multinomial;
    else if (!std::strcmp(argv[3], "Residual"))
        ResScheme = vsmc::Residual;
    else if (!std::strcmp(argv[3], "Stratified"))
        ResScheme = vsmc::Stratified;
    else if (!std::strcmp(argv[3], "Systematic"))
        ResScheme = vsmc::Systematic;
    else if (!std::strcmp(argv[3], "ResidualStratified"))
        ResScheme = vsmc::ResidualStratified;
    else if (!std::strcmp(argv[3], "ResidualSystematic"))
        ResScheme = vsmc::ResidualSystematic;

    if (!vsmc::CLManager<cv_device>::instance().setup())
        vsmc::CLManager<cv_device>::instance().setup(CL_DEVICE_TYPE_GPU);
    if (!vsmc::CLManager<cv_device>::instance().setup())
        vsmc::CLManager<cv_device>::instance().setup(CL_DEVICE_TYPE_CPU);
    if (!vsmc::CLManager<cv_device>::instance().setup()) {
        std::cout << "Failed to setup OpenCL environment" << std::endl;
        return -1;
    }

    vsmc::Sampler<cv> sampler(ParticleNum, ResScheme);
    std::ifstream src_file("pf-cl.cl");
    std::string src(
            (std::istreambuf_iterator<char>(src_file)),
            (std::istreambuf_iterator<char>()));
    src_file.close();
    std::string opt;
    for (int i = 4; i != argc; ++i)
        opt += argv[i];
    try {
        sampler.particle().value().build(src, opt);
    } catch (...) {
        std::fprintf(stderr, "%s\n", sampler.particle().value().build_log());
        throw;
    }

    std::string name;
    sampler.particle().value().manager().platform().getInfo(
            (cl_device_info) CL_PLATFORM_NAME, &name);
    std::cout << "Using platform: " << name << std::endl;
    sampler.particle().value().manager().device().getInfo(
            (cl_device_info) CL_DEVICE_NAME, &name);
    std::cout << "Using device:   " << name << std::endl;

    sampler.init(cv_init()).move(cv_move(), true).monitor("pos", 2,
            vsmc::MonitorEvalAdapter<cv, vsmc::MonitorEvalCL>("cv_est"));
    sampler.initialize(argv[1]);
    sampler.iterate(DataNum - 1);

    std::ofstream est(argv[2]);
    est << sampler << std::endl;
    est.close();

    return 0;
}
