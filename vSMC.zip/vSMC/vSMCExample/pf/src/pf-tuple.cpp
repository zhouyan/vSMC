#include "pf-tuple-@smp@.hpp"

int main (int argc, char *argv[])
{
#include "pf-smp-main.hpp"
}
