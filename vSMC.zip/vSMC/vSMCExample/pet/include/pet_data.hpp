double Decay;
std::size_t DataSetNum;
std::size_t DataStart;
std::size_t DataStop;
std::size_t DataNum;
std::size_t ModelNum;
std::size_t ConvNum;
double ConvMul;
std::string TimeFile;
std::string ConvFile;
std::string PriorFile;
std::string SDFile;
bool UseStudentT;

std::ifstream config_file;

config_file.open(DataFile.c_str());
if (!config_file)
    throw std::runtime_error("Failed to open data config file");
config_file >> Decay >> DataSetNum >> DataStart >> DataStop
    >> ModelNum >> DataNum >> ConvNum >> ConvMul
    >> DataFile >> TimeFile >> ConvFile >> PriorFile >> SDFile >> UseStudentT;
config_file.close();
config_file.clear();

PETModel ModelType = Normal;
if (UseStudentT)
    ModelType = StudentT;

std::ifstream data_file;

std::vector<double> Data(DataNum * DataSetNum);
data_file.open(DataFile.c_str());
if (!data_file)
    throw std::runtime_error("Failed to open data file");
for (std::size_t r = 0; r != DataSetNum; ++r)
    for (std::size_t c = 0; c != DataNum; ++c)
        data_file >> Data[c + r * DataNum];
data_file.close();
data_file.clear();

std::vector<double> Time(DataNum);
data_file.open(TimeFile.c_str());
if (!data_file)
    throw std::runtime_error("Failed to open time file");
for (std::size_t i = 0; i != DataNum; ++i)
    data_file >> Time[i];
data_file.close();
data_file.clear();

std::vector<double> Conv(DataNum * ConvNum);
data_file.open(ConvFile.c_str());
if (!data_file)
    throw std::runtime_error("Failed to open conv file");
for (std::size_t r = 0; r != ConvNum; ++r)
    for (std::size_t c = 0; c != DataNum; ++c)
        data_file >> Conv[c + r * DataNum];
data_file.close();
data_file.clear();

std::vector<double> Prior(ModelNum * 8 + 4);
std::size_t prior_offset = 0;
data_file.open(PriorFile.c_str());
if (!data_file)
    throw std::runtime_error("Failed to open prior file");
for (std::size_t i = 0; i != ModelNum; ++i)
    data_file >> Prior[prior_offset++]; pet_ignore(data_file); // phi_lb0
for (std::size_t i = 0; i != ModelNum; ++i)
    data_file >> Prior[prior_offset++]; pet_ignore(data_file); // phi_ub0
for (std::size_t i = 0; i != ModelNum; ++i)
    data_file >> Prior[prior_offset++]; pet_ignore(data_file); // theta_lb0
for (std::size_t i = 0; i != ModelNum; ++i)
    data_file >> Prior[prior_offset++]; pet_ignore(data_file); // theta_ub0
data_file >> Prior[prior_offset++]; pet_ignore(data_file); // lambda_a0
data_file >> Prior[prior_offset++]; pet_ignore(data_file); // lambda_b0
data_file >> Prior[prior_offset++]; pet_ignore(data_file); // nu_a0
data_file >> Prior[prior_offset++]; pet_ignore(data_file); // nu_b0
data_file.close();
data_file.clear();

std::vector<double> SD(ModelNum * 2 + 2);
std::size_t sd_offset = 0;
data_file.open(SDFile.c_str());
if (!data_file)
    throw std::runtime_error("Failed to open proposal file");
for (std::size_t i = 0; i != ModelNum; ++i)
    data_file >> SD[sd_offset++]; pet_ignore(data_file); // phi_sd
for (std::size_t i = 0; i != ModelNum; ++i)
    data_file >> SD[sd_offset++]; pet_ignore(data_file); // theta_sd
data_file >> SD[sd_offset++]; pet_ignore(data_file); // lamda_sd;
data_file >> SD[sd_offset++]; pet_ignore(data_file); // nu_sd;
data_file.close();
data_file.clear();

data_info  info_d = {DataNum, &Data[0]};
time_info  info_t = {DataNum, &Time[0]};
conv_info  info_c = {ConvNum, ConvMul, &Conv[0]};
prior_info info_p = {ModelNum, &Prior[0]};
sd_info    info_s = {ModelNum, &SD[0]};
model_info info_m = {Decay, ModelType};
pet_info info = {
    &info_d, true,
    &info_t, true,
    &info_c, true,
    &info_p, true,
    &info_s, true,
    &info_m, true};

if (AskBeforeStart) {
    std::string answer;
    std::string start("start");
    while (answer != start) {
        std::cout << "Data reading is done." << std::endl;
        std::cout << "Enter [start] to start computation?" << std::endl;
        std::cin >> answer;
    }
}
