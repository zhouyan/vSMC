#ifndef VSMC_EXAMPLE_PET_HPP
#define VSMC_EXAMPLE_PET_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@
#define BASE_PATH    vsmc::PathEval@SMP@

#include <vsmc/smp/backend_@smp@.hpp>

const std::size_t InitCompNum = 1;
const std::size_t MinCompNum = 1;
const std::size_t MaxCompNum = 3;

std::string DataFile;
std::size_t SM;
std::size_t CM;

#include "common.hpp"
#include "pet_param.hpp"
#include "pet_state.hpp"
#include "pet_init.hpp"
#include "pet_move.hpp"
#include "pet_monitor.hpp"
#include "pet_proposal.hpp"

template <typename InputStream>
inline void pet_ignore (InputStream &is)
{
    is.ignore(std::numeric_limits<std::streamsize>::max
            VSMC_MACRO_NO_EXPANSION (), '\n');
}

#endif // VSMC_EXAMPLE_PET_HPP
