Config
.add<std::string>("data_file",
     "Name of data config file", &DataFile, "pet_simulate_data.config")
.add<std::size_t>("simple_model",
        "Enable simple model with number of components", &SM, 1)
.add<std::size_t>("complex_model",
        "Enable complex model with number of components", &CM, 2);
