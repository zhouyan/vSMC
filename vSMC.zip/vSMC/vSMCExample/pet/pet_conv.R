# Use multicore for pre-2.14 R, 2.14 and after use parallel
Version <- as.numeric(version$major) + as.numeric(version$minor) / 10
if (Version >= 2.14) library(parallel) else library(multicore)
library(stats)

load("pet_conv.RData")

InputFun <- splinefun(Input$time, Input$CP)

BasisFun <- function(x, uptime, theta)
{exp(-theta * (uptime - x)) * InputFun(x)}

Convolution <- function(theta, t)
{
    integrate(BasisFun, lower=0, upper=t, uptime=t, theta=theta,
              subdivisions=1e8, stop.on.error=FALSE)$value
}

ComputeConv <- function(theta_a, theta_b, theta_step)
{
    Theta <- seq(theta_a, theta_b, theta_step)
    m <- length(Theta)
    n <- length(TimeFrame)

    ConvList <- list()

    for (i in 1:n) {
        cat("Time frame: ", i, "\n")
        tf <- TimeFrame[i]
        ConvList[[i]] <- mclapply(Theta, Convolution, t = tf)
    }

    ConvMat <- matrix(rep(0, m * n), ncol = n)
    for (j in 1:n) {
        for (i in 1:m) {
            ConvMat[i,j] <- ConvList[[j]][[i]]
        }
    }

    list(ConvMat=ConvMat, Theta=Theta)
}

ConvMat <- ComputeConv(0, 1 + 1e-5, 1e-5)
write.table(ConvMat, "pet_conv.data", row.names = FALSE, col.names = FALSE)
