#include "pet-@smp@.hpp"
#include "smc.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "options_smc.hpp"
#include "pet_options.hpp"
#include "options_process.hpp"
#include "pet_data.hpp"

    //////////////////////////////////////////////////////////////////////

    vsmc::Sampler<pet_state> sampler(ParticleNum, vsmc::Stratified, Threshold);
    sampler
        .init(pet_init())
        .mcmc(pet_move_phi(), true)
        .mcmc(pet_move_theta(), true)
        .mcmc(pet_move_lambda(), true)
        .mcmc(pet_move_nu(), true)
        .monitor("vd", 2, pet_vd())
        .path_sampling(smc_path<pet_state>());
    if (ProposalScale == 2) {
        sampler.monitor("pet_moments", 2 * (2 + 2 * (SM > CM ? SM : CM)),
                pet_moments());
    }

    sampler.initialize(&info);
    info.read_time  = false;
    info.read_conv  = false;
    info.read_prior = false;
    info.read_sd    = false;
    info.read_model = false;

    //////////////////////////////////////////////////////////////////////

    std::ofstream zconst_file(("smc." + Suffix).c_str());
    zconst_file << "Schedule Config ";
    print_zconst_header(zconst_file, SM);
    print_zconst_header(zconst_file, CM);
    zconst_file << std::endl;
    if (ProposalScale == 2) {
        typedef pet_proposal_adaptive sd;
        for (std::size_t i = DataStart; i != DataStop; ++i) {
            info_d.data_value = &Data[i * DataNum];
            sampler.initialize(&info);
            smc_do<pet_state, sd>(Config, sampler, zconst_file);
        }
    } else {
        typedef pet_proposal sd;
        for (std::size_t i = DataStart; i != DataStop; ++i) {
            info_d.data_value = &Data[i * DataNum];
            sampler.initialize(&info);
            smc_do<pet_state, sd>(Config, sampler, zconst_file);
        }
    }
    zconst_file.close();
    zconst_file.clear();

    return 0;
}
