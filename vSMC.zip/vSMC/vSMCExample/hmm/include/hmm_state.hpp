#ifndef VSMC_EXAMPLE_HMM_STATE_HPP
#define VSMC_EXAMPLE_HMM_STATE_HPP

struct data_info
{
    const std::size_t data_num;
    const char *file_name;
    const double *data_value;

    data_info (std::size_t num, const char *file) :
        data_num(num), file_name(file), data_value(NULL) {}

    data_info (std::size_t num, const double *data) :
        data_num(num), file_name(NULL), data_value(data) {}
};

class hmm_state :
    public BASE_STATE<vsmc::StateMatrix<vsmc::RowMajor, 1, hmm_param> >
{
    typedef BASE_STATE<vsmc::StateMatrix<vsmc::RowMajor, 1, hmm_param> > base;

    public :

    hmm_state (size_type N) : base(N), sd_init_(1), sd_move_(1), sd_obs_(1) {}

    typedef BASE_WEIGHT<vsmc::NullType> weight_set_type;

    template <typename IntType>
    void copy (std::size_t N, const IntType *copy_from)
    {
        const std::size_t t = state(0, 0).time();
        for (std::size_t to = 0; to != N; ++to) {
            const std::size_t from = copy_from[to];
            state(to, 0).ancestor(t) = from;
            state(to, 0).state(t) = state(from, 0).state(t);
            state(to, 0).log_likelihood(t) = state(from, 0).log_likelihood(t);
        }
    }

    double log_likelihood_const () const
    {return -0.5 * obs_.size() * std::log(2 * M_PI);}

    void read_data (const data_info *info)
    {
        obs_.resize(info->data_num);

        if (info->data_value) {
            // read data from c-array
            for (std::size_t i = 0; i != info->data_num; ++i)
                obs_[i] = info->data_value[i];
        } else if (info->file_name) {
            // read data frome file
            std::ifstream data;
            data.open(info->file_name);
            if (!data) {
                data.close();
                data.clear();
                throw std::runtime_error("Failed to open data file");
            }
            for (std::size_t i = 0; i != info->data_num; ++i)
                data >> obs_[i];
            data.close();
            data.clear();
        } else {
            throw std::runtime_error("Failed to read data");
        }

        for (size_type i = 0; i != size(); ++i)
            state(i, 0).data_num(info->data_num);
    }

    std::size_t data_num () const {return obs_.size();}

    double obs     (std::size_t t) const {return obs_[t];}
    double sd_init ()              const {return sd_init_;}
    double sd_move ()              const {return sd_move_;}
    double sd_obs  ()              const {return sd_obs_;}

    double &obs     (std::size_t t) {return obs_[t];}
    double &sd_init ()              {return sd_init_;}
    double &sd_move ()              {return sd_move_;}
    double &sd_obs  ()              {return sd_obs_;}

    private :

    std::vector<double> obs_;
    double sd_init_;
    double sd_move_;
    double sd_obs_;
};

inline hmm_param hmm_particle (hmm_state::size_type id, const hmm_state &value)
{
    hmm_param param(value.state(id, 0));
    const std::size_t T = param.data_num();
    for (std::size_t t = T - 1; t != 0; --t) {
        const std::size_t parent = param.ancestor(t);
        param.state(t - 1) = value.state(parent, 0).state(t - 1);
        param.log_likelihood(t - 1) =
            value.state(parent, 0).log_likelihood(t - 1);
        param.ancestor(t - 1) = value.state(parent, 0).ancestor(t - 1);
    }

    return param;
}

inline hmm_param hmm_draw (vsmc::Particle<hmm_state> &particle)
{
    vsmc::Particle<hmm_state>::size_type id =
        particle.weight_set().draw(particle.rng(0));

    return hmm_particle(id, particle.value());
}

#endif // VSMC_EXAMPLE_HMM_STATE_HPP
