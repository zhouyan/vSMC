#ifndef VSMC_EXAMPLE_HMM_HPP
#define VSMC_EXAMPLE_HMM_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@
#define BASE_WEIGHT  vsmc::WeightSet@SMP@

#include <vsmc/smp/backend_@smp@.hpp>

double Threshold;
std::size_t ParticleNum;
std::size_t IterNum;
std::size_t BurninNum;
std::size_t DataNum;
std::string DataFile;
double VarInit;
double VarMove;
double VarObs;

#include "common.hpp"
#include "hmm_param.hpp"
#include "hmm_state.hpp"
#include "hmm_init.hpp"
#include "hmm_move.hpp"
#include "hmm_monitor.hpp"

#endif // VSMC_EXAMPLE_HMM_HPP
