#ifndef VSMC_EXAMPLE_HMM_MONITOR_HPP
#define VSMC_EXAMPLE_HMM_MONITOR_HPP

class hmm_est : public BASE_MONITOR<hmm_state, hmm_est>
{
    public :

    void monitor_state (std::size_t iter, std::size_t,
            vsmc::ConstSingleParticle<hmm_state> csp, double *res)
    {
        double x = csp.state(0).state(iter);
        *res = 0.05 * x * x;
    }
};

class hmm_incw : public BASE_MONITOR<hmm_state, hmm_incw>
{
    public :

    void monitor_state (std::size_t iter, std::size_t,
            vsmc::ConstSingleParticle<hmm_state> csp, double *res)
    {*res = std::exp(csp.state(0).log_likelihood(iter));}
};

double hmm_zconst (const vsmc::Monitor<hmm_state> &zconst_monitor)
{
    const std::size_t T = zconst_monitor.iter_size();
    double z = 0;
    for (std::size_t t = 1; t != T; ++t)
        z += std::log(zconst_monitor.record(0, t));

    return z ;
}


#endif // VSMC_EXAMPLE_HMM_MONITOR_HPP
