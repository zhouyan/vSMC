#ifndef VSMC_EXAMPLE_HMM_INIT_HPP
#define VSMC_EXAMPLE_HMM_INIT_HPP

class hmm_init : public BASE_INIT<hmm_state, hmm_init>
{
    public :

    std::size_t initialize_state (vsmc::SingleParticle<hmm_state> sp)
    {
        sp.state(0).init(sp.id(), sd_init_, sp.rng());
        log_weight_[sp.id()] = sp.state(0).log_likelihood(obs_, sd_obs_);

        return 0;
    }

    void initialize_param (vsmc::Particle<hmm_state> &particle, void *info)
    {
        if (info)
            particle.value().read_data(static_cast<const data_info *>(info));
        obs_ = particle.value().obs(0);
        sd_obs_ = particle.value().sd_obs();
        sd_init_ = particle.value().sd_init();
        log_weight_.resize(particle.size());
    }

    void post_processor (vsmc::Particle<hmm_state> &particle)
    {
        particle.weight_set().set_log_weight(&log_weight_[0]);
    }

    private :

    double obs_;
    double sd_obs_;
    double sd_init_;
    std::vector<double> log_weight_;
};

#endif // VSMC_EXAMPLE_HMM_INIT_HPP
