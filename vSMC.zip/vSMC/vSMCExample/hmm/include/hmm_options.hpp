Config
.add<double>     ("threshold",    "Threshold of ESS/N",   &Threshold, 0.5)
.add<std::size_t>("particle_num", "Particle number",      &ParticleNum, 1000)
.add<std::string>("data_file",    "Name of data file",    &DataFile,"hmm.data")
.add<std::size_t>("data_num",     "Number of data",       &DataNum, 100)
.add<double>     ("var_init",     "Initialize variance",  &VarInit, 5)
.add<double>     ("var_move",     "Update move variance", &VarMove, 10)
.add<double>     ("var_obs",      "Observation variance", &VarObs,  10);
