Config
.add<std::size_t>("iter_num",  "Iteration number", &IterNum,   1000)
.add<std::size_t>("burnin_num", "Burnin number",    &BurninNum, 0);
