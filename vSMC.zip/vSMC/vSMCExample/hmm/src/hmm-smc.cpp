#include "hmm-@smp@.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "hmm_options.hpp"
#include "options_process.hpp"

    vsmc::Sampler<hmm_state> sampler(ParticleNum, vsmc::Stratified, Threshold);
    sampler.init(hmm_init()).mcmc(hmm_move(), true);
    sampler.monitor("est", 1, hmm_est());
    sampler.monitor("zconst", 1, hmm_incw());
    sampler.particle().value().sd_init() = std::sqrt(VarInit);
    sampler.particle().value().sd_move() = std::sqrt(VarMove);
    sampler.particle().value().sd_obs()  = std::sqrt(VarObs);
    sampler.start_watch();
    sampler.particle().start_watch();

    data_info info(DataNum, DataFile.c_str());
    sampler.initialize(&info);

    std::ofstream zconst(("hmm-smc.zconst." + Suffix).c_str());
    zconst << "Log.Normalizing.Constant" << std::endl;
    for (std::size_t r = 0; r != Repeat; ++r) {
        if (Repeat > 1) std::cout << "\n\nRun: " << r << std::endl;
        sampler.initialize();
        sampler.iterate(DataNum - 1);
        double z = hmm_zconst(sampler.monitor("zconst")) +
            sampler.particle().value().log_likelihood_const();
        zconst << z << std::endl;
    }
    zconst.close();
    zconst.clear();

    std::ofstream save(("hmm-smc.sampler." + Suffix).c_str());
    save << sampler << std::endl;
    save.close();
    save.clear();

    std::cout << "Time initialize: ";
    std::cout << sampler.watch_init().seconds() << std::endl;
    std::cout << "Time move:       ";
    std::cout << sampler.watch_move().seconds() << std::endl;
    std::cout << "Time mcmc:       ";
    std::cout << sampler.watch_mcmc().seconds() << std::endl;
    std::cout << "Time resampling: ";
    std::cout << sampler.watch_resample().seconds() << std::endl;
    std::cout << "Time monitoring: ";
    std::cout << sampler.watch_monitor().seconds() << std::endl;

    std::cout << "Time resample read weight:           ";
    std::cout << sampler.particle().resample_read_weight_watch()
        .seconds() << std::endl;
    std::cout << "Time resample generate replication:  ";
    std::cout << sampler.particle().resample_get_replication_watch()
        .seconds() << std::endl;
    std::cout << "Time resample generate parent index: ";
    std::cout << sampler.particle().resample_get_copy_from_watch()
        .seconds() << std::endl;
    std::cout << "Time resample copy:                  ";
    std::cout << sampler.particle().resample_copy_watch()
        .seconds() << std::endl;

    return 0;
}
