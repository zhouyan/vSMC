#ifndef VSMC_EXAMPLE_NODE_PROPOSAL_HPP
#define VSMC_EXAMPLE_NODE_PROPOSAL_HPP

class node_proposal
{
    public :

    typedef const vsmc::Sampler<node_state> * value_type;

    node_proposal (value_type config = VSMC_NULLPTR) {}

    void proposal_iter (std::size_t iter,
            vsmc::Particle<node_state> &particle) const
    {
        double alpha = particle.value().state(0, 0).alpha();
        std::size_t cn = particle.value().state(0, 0).comp_num();
        double a0_sd, a1_sd, a2_sd, k_sd;
        alpha2sd(alpha, a0_sd, a1_sd, a2_sd, k_sd);
        for (vsmc::Particle<node_state>::size_type i = 0;
                i != particle.size(); ++i) {
            particle.value().state(i, 0).a0_sd() = a0_sd;
            particle.value().state(i, 0).a1_sd() = a1_sd;
            particle.value().state(i, 0).a2_sd() = a2_sd;
            for (std::size_t d = 0; d != cn - 1; ++d)
                particle.value().state(i, 0).k_sd(d) = k_sd;
        }
    }

    void proposal_init (vsmc::Particle<node_state> &particle) const
    {
        for (vsmc::Particle<node_state>::size_type i = 0;
                i != particle.size(); ++i) {
            double alpha = particle.value().state(i, 0).alpha();
            std::size_t cn = particle.value().state(i, 0).comp_num();
            double a0_sd, a1_sd, a2_sd, k_sd;
            alpha2sd(alpha, a0_sd, a1_sd, a2_sd, k_sd);
            particle.value().state(i, 0).a0_sd() = a0_sd;
            particle.value().state(i, 0).a1_sd() = a1_sd;
            particle.value().state(i, 0).a2_sd() = a2_sd;
            for (std::size_t d = 0; d != cn - 1; ++d)
                particle.value().state(i, 0).k_sd(d) = k_sd;
        }
    }

    private :

    void alpha2sd (double alpha,
            double &a0_sd, double &a1_sd, double &a2_sd, double &k_sd) const
    {
        using std::sqrt;

        a0_sd = 5 / (1 + 100 * alpha);
        a1_sd = 5 / (1 + 100 * alpha);
        a2_sd = 5 / (1 + 100 * alpha);
        k_sd  = 5 / (1 + 100 * alpha);
    }
};

class node_proposal_adaptive
{
    public :

    typedef const vsmc::Sampler<node_state> * value_type;

    node_proposal_adaptive (value_type sampler) : sampler_(sampler) {}

    void proposal_iter (std::size_t iter,
            vsmc::Particle<node_state> &particle) const
    {
        using std::sqrt;

        std::size_t cn = particle.value().state(0,0).comp_num();
        const vsmc::Monitor<node_state> &monitor =
            sampler_->monitor("node_moments");

        const double coeff = 2.38;
        double a0_sd = coeff * sqrt(monitor.record(2 + cn) -
                monitor.record(0) * monitor.record(0));
        double a1_sd = coeff * sqrt(monitor.record(3 + cn) -
                monitor.record(1) * monitor.record(1));
        double a2_sd = coeff * sqrt(monitor.record(4 + cn) -
                monitor.record(2) * monitor.record(2));
        std::vector<double> k_sd(cn - 1);
        for (std::size_t d = 0; d != cn - 1; ++d) {
            k_sd[d] = coeff * sqrt(monitor.record(5 + cn + d) -
                    monitor.record(3 + d) * monitor.record(3 + d));
        }

        for (vsmc::Particle<node_state>::size_type i = 0;
                i != particle.size(); ++i) {
            particle.value().state(i, 0).a0_sd() = a0_sd;
            particle.value().state(i, 0).a1_sd() = a1_sd;
            particle.value().state(i, 0).a2_sd() = a2_sd;
            for (std::size_t d = 0; d != cn - 1; ++d)
                particle.value().state(i, 0).k_sd(d) = k_sd[d];
        }
    }

    private :

    const vsmc::Sampler<node_state> *sampler_;
};

#endif // VSMC_EXAMPLE_NODE_PROPOSAL_HPP
