#ifndef VSMC_EXAMPLE_NODE_HPP
#define VSMC_EXAMPLE_NODE_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@
#define BASE_PATH    vsmc::PathEval@SMP@

#include <vsmc/smp/backend_@smp@.hpp>

const std::size_t InitCompNum = 3;
const std::size_t MinCompNum = 1;
const std::size_t MaxCompNum = 5;

std::string DataFile;
std::size_t DataNum;
std::size_t SM;
std::size_t CM;
double Resolution;
double Shape0;
double Scale0;

#include "common.hpp"
#include "node_param.hpp"
#include "node_state.hpp"
#include "node_init.hpp"
#include "node_move.hpp"
#include "node_monitor.hpp"
#include "node_proposal.hpp"

#endif // VSMC_EXAMPLE_NODE_HPP
