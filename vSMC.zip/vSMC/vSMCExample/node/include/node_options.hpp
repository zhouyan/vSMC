Config
.add<std::string>("data_file",
        "Name of data file", &DataFile, "node-c.data")
.add<std::size_t>("data_num",
        "Number of data", &DataNum, 80)
.add<std::size_t>("simple_model",
        "Enable simple model with number of components", &SM, 3)
.add<std::size_t>("complex_model",
        "Enable complex model with number of components", &CM, 5)
.add<double>("shape0",
        "Scale of Gamma prior", &Shape0, 0.1)
.add<double>("scale0",
        "Scale of Gamma prior", &Scale0, 0.1)
.add<double>("resolution",
        "Resolution of ODE solver", &Resolution, 0.05);
