#include "node-@smp@.hpp"
#include "smc.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "options_smc.hpp"
#include "node_options.hpp"
#include "options_process.hpp"

    //////////////////////////////////////////////////////////////////////

    vsmc::Sampler<node_state> sampler(ParticleNum,vsmc::Stratified,Threshold);
    sampler
        .init(node_init())
        .mcmc(node_move_a0(), true)
        .mcmc(node_move_a1(), true)
        .mcmc(node_move_a2(), true)
        .path_sampling(smc_path<node_state>());
    for (std::size_t i = 0; i != (SM > CM ? SM : CM) - 1; ++i)
        sampler.mcmc(node_move_k(i), true);
    if (ProposalScale == 2) {
        sampler.monitor("node_moments", 2 * (2 + (SM > CM ? SM : CM)),
                node_moments());
    }

    data_info info(DataNum, Resolution, DataFile.c_str());
    sampler.initialize(&info);

    //////////////////////////////////////////////////////////////////////

    std::ofstream zconst_file(("smc." + Suffix).c_str());
    zconst_file << "Schedule Config ";
    print_zconst_header(zconst_file, SM);
    print_zconst_header(zconst_file, CM);
    zconst_file << std::endl;
    if (ProposalScale == 2) {
        typedef node_proposal_adaptive sd;
        smc_do<node_state, sd>(Config, sampler, zconst_file);
    } else {
        typedef node_proposal sd;
        smc_do<node_state, sd>(Config, sampler, zconst_file);
    }
    zconst_file.close();
    zconst_file.clear();

    return 0;
}
