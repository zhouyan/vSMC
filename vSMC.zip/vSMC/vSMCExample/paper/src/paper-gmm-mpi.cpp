#define VSMC_PAPER_MPI 1

#include "paper-gmm-@smp@.cpp"
