library(ggplot2)

pf.data <- read.table("paper-pf.data", header = FALSE)
pf.est <- read.table("paper-pf.est", header = TRUE)
pf.plot.data <- data.frame(
    x = c(pf.est$pos.1, pf.data$V1),
    y = c(pf.est$pos.2, pf.data$V2),
    Data = ordered(c(rep("Estimates", 100), rep("Observations", 100)),
        levels = c("Estimates", "Observations"))
    )
pf.plot <- ggplot(pf.plot.data) + aes(x = x, y = y, group = Data,
    color = Data, linetype = Data) + geom_line() + geom_point() +
    xlab("X position") + ylab("Y position") + theme_bw() +
    theme(legend.position = "top", legend.direction = "horizontal")

pdf("pf.pdf")
print(pf.plot)
dev.off()

pdf("pf-plain.pdf")
plot(pf.data$V1, pf.data$V2, col = 4, xlim = c(-6.4, -1), ylim = c(3, 14),
    xlab = "Position x", ylab = "Position y")
lines(pf.est$pos.1, pf.est$pos.2, col = 2)
dev.off()
