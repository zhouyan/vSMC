Examples of [vSMC](https://github.com/zhouyan/vSMC)
