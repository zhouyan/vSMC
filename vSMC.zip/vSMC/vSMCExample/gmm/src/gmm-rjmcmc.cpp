#include "gmm-@smp@.hpp"
#include "gmm_move_rj.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "gmm_options.hpp"
    std::size_t BurninNum;
    std::size_t IterNum;
    Config
        .add<std::size_t>("burnin_num",
                "Number of burin iterations, only used for PMCMC",
                &BurninNum, 10000)
        .add<std::size_t>("iter_num",
                "Number of recored iterations, only used for PMCMC",
                &IterNum, 10000);
#include "options_process.hpp"

    //////////////////////////////////////////////////////////////////////

    vsmc::Sampler<gmm_state> sampler(Repeat, vsmc::Stratified, 0);
    sampler.particle().value().ordered() = true;
    sampler
        .init(gmm_init_rjmcmc())
        .mcmc(gmm_move_mu(), true)
        .mcmc(gmm_move_lambda(), true)
        .mcmc(gmm_move_weight(), true)
        .mcmc(gmm_rj_sc<gmm_logodds_flat>(), true)
        .mcmc(gmm_rj_bd<gmm_logodds_flat>(), true);

    data_info info(DataNum, DataFile.c_str());
    sampler.initialize(&info);

    for (std::size_t d = 0; d != BurninNum; ++d) {
        if (!(d % 1000)) std::cout << "Burnin: " << d << std::endl;
        sampler.iterate();
    }

    std::vector<std::vector<std::size_t> > cn(Repeat);
    for (std::size_t i = 0; i != Repeat; ++i)
        cn[i].resize(MaxCompNum);
    for (std::size_t d = 0; d != IterNum; ++d) {
        if (!(d % 1000)) std::cout << "Iter: " << d << std::endl;
        sampler.iterate();
        for (std::size_t r = 0; r != Repeat; ++r)
            ++cn[r][sampler.particle().value().state(r,0).comp_num() - 1];
    }

    //////////////////////////////////////////////////////////////////////

    std::ofstream zconst_file;
    zconst_file.open(("rjmcmc." + Suffix).c_str());
    if (!zconst_file)
        throw std::runtime_error("Fail to open zconst file");
    for (std::size_t r = 0; r != Repeat; ++r) {
        for (std::size_t d = 0; d != MaxCompNum; ++d)
            zconst_file << cn[r][d] / static_cast<double>(IterNum) << ' ';
        zconst_file << '\n';
    }
    zconst_file.close();
    zconst_file.clear();

    //////////////////////////////////////////////////////////////////////

    return 0;
}
