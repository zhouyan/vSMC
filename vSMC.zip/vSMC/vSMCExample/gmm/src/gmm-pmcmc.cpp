#include "gmm-@smp@.hpp"
#include "pmcmc.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "options_pmcmc.hpp"
#include "gmm_options.hpp"
#include "options_process.hpp"

    //////////////////////////////////////////////////////////////////////

    vsmc::Sampler<gmm_state> sampler(ChainNum, vsmc::Stratified, 0);
    sampler.init(gmm_init());
    sampler.mcmc(pmcmc_global<gmm_state>(), false);

    Parallel ?
        sampler.move(pmcmc_local_parallel<gmm_move>(), false):
        sampler.move(pmcmc_local_serial<gmm_state, gmm_move>(), false);

    data_info info(DataNum, DataFile.c_str());
    sampler.initialize(&info);

    //////////////////////////////////////////////////////////////////////

    std::ofstream zconst_file;
    zconst_file.open(("pmcmc." + Suffix).c_str());
    if (!zconst_file)
        throw std::runtime_error("Fail to open zconst file");
    zconst_file << "Schedule Chains";
    if (SM) zconst_file << " Path." << SM << ' ';
    if (CM) zconst_file << " Path." << CM << ' ';
    zconst_file << std::endl;
    pmcmc_do<gmm_state, gmm_init, gmm_proposal>(Config, sampler, zconst_file);
    zconst_file.close();
    zconst_file.clear();

    return 0;
}
