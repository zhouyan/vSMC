#include "gmm-smc-cl.hpp"

std::string gmm_device::platform_name_("Default");
cl_device_type gmm_device::opencl_device_type::value =
    CL_DEVICE_TYPE_DEFAULT;

int main (int argc, char **argv)
{
#include "options_main.hpp"
#include "gmm_options_cl.hpp"
#include "options_process.hpp"

    gmm_device::set_opencl_platform(PlatformName);
    if (DeviceType == std::string("Default"))
        gmm_device::opencl_device_type::value = CL_DEVICE_TYPE_DEFAULT;
    else if (DeviceType == std::string("CPU"))
        gmm_device::opencl_device_type::value = CL_DEVICE_TYPE_CPU;
    else if (DeviceType == std::string("GPU"))
        gmm_device::opencl_device_type::value = CL_DEVICE_TYPE_GPU;
    else if (DeviceType == std::string("Accelerator"))
        gmm_device::opencl_device_type::value = CL_DEVICE_TYPE_ACCELERATOR;

    if (!vsmc::CLManager<gmm_device>::instance().setup()) {
        std::cout << "Failed to setup OpenCL environment" << std::endl;
        std::cout << "Platform name: " << PlatformName << std::endl;
        std::cout << "Device type: " << DeviceType << std::endl;
        return -1;
    }

    if (FPTypeBits == 32) {
        gmm_do_smc<cl_float>(ParticleNum, IterNum, DataNum, DataFile,
                Threshold, vSMCIncPath, R123IncPath, SM, CM, Repeat);
    } else if (FPTypeBits == 64) {
        gmm_do_smc<cl_double>(ParticleNum, IterNum, DataNum, DataFile,
                Threshold, vSMCIncPath, R123IncPath, SM, CM, Repeat);
    } else {
        std::fprintf(stderr, "cl_type_bits ahs to be 32 or 64\n");
        return -1;
    }

    return 0;
}
