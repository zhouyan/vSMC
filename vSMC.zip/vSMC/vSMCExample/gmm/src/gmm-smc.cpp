#include "gmm-@smp@.hpp"
#include "smc.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "options_smc.hpp"
#include "gmm_options.hpp"
#include "options_process.hpp"

    //////////////////////////////////////////////////////////////////////

    vsmc::Sampler<gmm_state> sampler(ParticleNum, vsmc::Stratified, Threshold);
    sampler
        .init(gmm_init())
        .mcmc(gmm_move_mu(), true)
        .mcmc(gmm_move_lambda(), true)
        .mcmc(gmm_move_weight(), true)
        .path_sampling(smc_path<gmm_state>());
    if (ProposalScale == 2) {
        sampler
            .monitor("rm.mu", 2, gmm_rm_mu())
            .monitor("rm.lambda", 2, gmm_rm_lambda())
            .monitor("rm.weight", 2, gmm_rm_weight());
    }

    data_info info(DataNum, DataFile.c_str());
    sampler.initialize(&info);

    //////////////////////////////////////////////////////////////////////

    std::ofstream zconst_file(("smc." + Suffix).c_str());
    zconst_file << "Schedule Config ";
    print_zconst_header(zconst_file, SM);
    print_zconst_header(zconst_file, CM);
    zconst_file << std::endl;
    if (ProposalScale == 2) {
        typedef gmm_proposal_adaptive sd;
        smc_do<gmm_state, sd>(Config, sampler, zconst_file);
    } else {
        typedef gmm_proposal sd;
        smc_do<gmm_state, sd>(Config, sampler, zconst_file);
    }
    zconst_file.close();
    zconst_file.clear();

    return 0;
}
