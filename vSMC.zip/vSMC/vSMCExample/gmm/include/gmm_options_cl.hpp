std::string vSMCIncPath;
std::string R123IncPath;
std::string PlatformName;
std::string DeviceType;
std::size_t FPTypeBits;
std::size_t ParticleNum;
double Threshold;
std::size_t IterNum;
std::string DataFile;
std::size_t DataNum;
std::size_t SM;
std::size_t CM;
Config
.add<std::string>("vsmc_inc_path",
        "vSMC include path", &vSMCIncPath, ".")
.add<std::string>("r123_inc_path",
        "Random123 include path", &R123IncPath, ".")
.add<std::string>("cl_platform_name",
        "OpenCL platform name", &PlatformName, "Default")
.add<std::string>("cl_device_type",
        "OpenCL device type", &DeviceType, "Default")
.add<std::size_t>("cl_fp_type_bits",
        "Bits of OpenCL fp type (32: float; 64: double)",
        &FPTypeBits, 32)
.add<double>("threshold",
        "Threshold for resampling, only used by SMC", &Threshold, 0.5)
.add<std::size_t>("particle_num",
        "Particle number", &ParticleNum, 1000)
.add<std::size_t>("iter_num",
        "Iteration number", &IterNum, 100)
.add<std::size_t>("prior2",
        "Alias to iter_num", &IterNum, 100)
.add<std::string>("data_file",
        "Name of data file", &DataFile, "gmm.data")
.add<std::size_t>("data_num",
        "Number of data", &DataNum, 100)
.add<std::size_t>("simple_model",
        "Enable simple model with number of components", &SM, 4)
.add<std::size_t>("complex_model",
        "Enable complex model with number of components", &CM, 5);
