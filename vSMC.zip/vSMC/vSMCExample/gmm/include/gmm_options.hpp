Config
.add<std::string>("data_file",
        "Name of data file", &DataFile, "gmm.data")
.add<std::size_t>("data_num",
        "Number of data", &DataNum, 100)
.add<std::size_t>("simple_model",
        "Enable simple model with number of components", &SM, 4)
.add<std::size_t>("complex_model",
        "Enable complex model with number of components", &CM, 5);
