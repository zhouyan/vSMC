#ifndef VSMC_EXAMPLE_COMMON_HPP
#define VSMC_EXAMPLE_COMMON_HPP

#include <vsmc/core/sampler.hpp>
#include <vsmc/smp/state_matrix.hpp>
#include "options.hpp"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

std::string Suffix;
std::size_t Repeat;
vsmc::Seed::result_type Seed;
bool AskBeforeStart;
int ProposalScale;

OptionMap Config;

template <typename T>
inline void grow (std::size_t num, T &orig)
{
    if (orig.size() < num && num > 0) {
        T temp(num);
        for (std::size_t i = 0; i != orig.size(); ++i)
            temp[i] = orig[i];
        orig.resize(num);
        for (std::size_t i = 0; i != num; ++i)
            orig[i] = temp[i];
    }
}

template <typename T>
inline bool is_valid (T val)
{
    if (val != val)
        return false;
    if (val > std::numeric_limits<T>::max VSMC_MACRO_NO_EXPANSION ())
        return false;
    if (val < std::numeric_limits<T>::min VSMC_MACRO_NO_EXPANSION ())
        return false;
    return true;
}

#ifndef USE_CL

#ifdef VSMC_USE_C99_LGAMMA
#define VSMC_LGAMMA lgamma
#elif VSMC_USE_STD_LGAMMA
#define VSMC_LGAMMA std::lgamma
#elif VSMC_USE_BOOST_LGAMMA
#include <boost/math/special_functions/gamma.hpp>
#define VSMC_LGAMMA boost::math::lgamma
#endif

#endif // USE_CL

#endif // VSMC_EXAMPLE_COMMON_HPP
