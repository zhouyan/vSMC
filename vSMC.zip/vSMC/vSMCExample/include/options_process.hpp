if (Config.process(argc, argv))
    return 0;

if (ProposalScale == 2)
    Suffix += ".Adaptive";

if (AskBeforeStart) {
    std::string answer;
    std::string start("start");
    while (answer != start) {
        std::cout << "Enter [start] to start computation?" << std::endl;
        std::cin >> answer;
    }
}

vsmc::Seed::instance().set(Seed);
