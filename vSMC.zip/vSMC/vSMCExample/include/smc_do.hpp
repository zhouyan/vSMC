#ifndef VSMC_EXAMPLE_SMC_DO_HPP
#define VSMC_EXAMPLE_SMC_DO_HPP

void print_zconst_header (std::ostream &zconst_file, std::size_t model_num)
{
    if (model_num == 0)
        return;

    zconst_file
        << "Iteration." << model_num
        << " SMC." << model_num << " Path." << model_num;
#ifdef VSMC_PET_HPP
    zconst_file << " VDMean." << model_num << " VDVar." << model_num;
#endif
    zconst_file << ' ';
}

template <typename T>
void smc_do (vsmc::Sampler<T> &sampler, std::ostream &zconst_file,
        const std::string schedule_name, std::size_t model_num)
{
    if (model_num == 0)
        return;

    sampler.particle().value().comp_num(model_num);
    sampler.initialize();
    vsmc::StopWatch watch;
    watch.start();
    while (sampler.particle().value().state(0, 0).alpha() < 1)
        sampler.iterate();
    watch.stop();
    std::fprintf(stderr, "time.model.order.%u %f\n",
            static_cast<unsigned>(model_num), watch.seconds());

    zconst_file << sampler.iter_size() - 1 << ' ';
    zconst_file << sampler.particle().value().zconst()
        + sampler.particle().value().log_likelihood_const() << ' ';
    zconst_file << sampler.path_sampling()
        + sampler.particle().value().log_likelihood_const() << ' ';
#ifdef VSMC_PET_HPP
    zconst_file << sampler.monitor("vd").record(0) << ' ';
    zconst_file << sampler.monitor("vd").record(1) -
        sampler.monitor("vd").record(0) * sampler.monitor("vd").record(0);
#endif
    zconst_file << ' ';

    std::ofstream sampler_file;
    std::string fn;
    std::stringstream ss;
    ss << model_num;
    std::string model_name(ss.str());

    fn = std::string("smc.sampler.");
    fn += Suffix + "." + schedule_name +  "." + model_name;
    sampler_file.open(fn.c_str());
    sampler_file << sampler;
    sampler_file.close();
    sampler_file.clear();
}

template <typename MoveType, typename T>
void smc_do (vsmc::Sampler<T> &sampler,
        std::ostream &zconst_file, const std::string &schedule_name,
        typename MoveType::alpha_type::value_type alpha_config)
{
    sampler.move(MoveType(alpha_config, &sampler), false);
    for (std::size_t i = 0; i != Repeat; ++i) {
        if (Repeat > 1)
            std::cout << "Run: " << i + 1 << std::endl;
        zconst_file << schedule_name << ' ';
        zconst_file << alpha_config << ' ';
        smc_do(sampler, zconst_file, schedule_name, SM);
        smc_do(sampler, zconst_file, schedule_name, CM);
        zconst_file << std::endl;
    }
}

template <typename T, typename SD, typename Config>
void smc_do (const Config &config, vsmc::Sampler<T> &sampler,
        std::ostream &zconst_file)
{
    typedef move_smc<T, alpha_ess<T, ess01<T> >,  SD> ess;
    typedef move_smc<T, alpha_ess<T, cess01<T> >, SD> cess;
    typedef move_smc<T, alpha_linear   <T>,       SD> linear;
    typedef move_smc<T, alpha_prior    <T, 2>,    SD> prior2;
    typedef move_smc<T, alpha_prior    <T, 5>,    SD> prior5;
    typedef move_smc<T, alpha_posterior<T, 2>,    SD> posterior2;
    typedef move_smc<T, alpha_posterior<T, 5>,    SD> posterior5;

    if (config.count("ess"))
        smc_do<ess>(sampler, zconst_file, "ESS", ESSDrop);

    if (config.count("cess"))
        smc_do<cess>(sampler, zconst_file, "CESS", CESSDrop);

    if (config.count("linear"))
        smc_do<linear>(sampler, zconst_file, "Linear", LinearIterNum);

    if (config.count("prior2"))
        smc_do<prior2>(sampler, zconst_file, "Prior2", Prior2IterNum);

    if (config.count("prior5"))
        smc_do<prior5>(sampler, zconst_file, "Prior5", Prior5IterNum);

    if (config.count("posterior2"))
        smc_do<posterior2>(sampler, zconst_file, "Posterior2",
                Posterior2IterNum);

    if (config.count("posterior5"))
        smc_do<posterior5>(sampler, zconst_file, "Posterior5",
                Posterior5IterNum);
}

#endif // VSMC_EXAMPLE_SMC_DO_HPP
