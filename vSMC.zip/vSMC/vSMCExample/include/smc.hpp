#ifndef VSMC_EXAMPLE_SMC_HPP
#define VSMC_EXAMPLE_SMC_HPP

std::size_t ParticleNum;
double Threshold;
double ESSDrop;
double CESSDrop;
std::size_t LinearIterNum;
std::size_t Prior2IterNum;
std::size_t Prior5IterNum;
std::size_t Posterior2IterNum;
std::size_t Posterior5IterNum;

#include "move_alpha.hpp"
#include "move_smc.hpp"
#include "smc_path.hpp"
#include "smc_do.hpp"

#endif // VSMC_EXAMPLE_SMC_HPP
