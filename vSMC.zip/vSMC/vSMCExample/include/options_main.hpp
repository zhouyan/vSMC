Config
.add<std::string>("suffix",
        "Suffix to output file", &Suffix, "save")
.add<std::size_t>("repeat",
        "Number of repeatition of experiments", &Repeat, 1)
.add<vsmc::Seed::result_type>("seed",
        "Seed to the sampler", &Seed, 1)
.add<bool>("ask_before_start",
        "Ask before starting the computation", &AskBeforeStart, false);
