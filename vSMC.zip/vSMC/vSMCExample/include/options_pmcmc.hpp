Config
.add<std::size_t>("chain_num",
        "Number of MCMC chains", &ChainNum, 1000)
.add<std::size_t>("burnin_num",
        "Number of burin iterations, only used for PMCMC", &BurninNum, 10000)
.add<std::size_t>("iter_num",
        "Number of recored iterations, only used for PMCMC", &IterNum, 10000)
.add<std::size_t>("linear",
        "Enbale linear schedule (SMC: iterations)", &LinearIterNum)
.add<std::size_t>("prior2",
        "Enbale prior2  schedule (SMC: iterations)", &Prior2IterNum)
.add<std::size_t>("prior5",
        "Enbale prior5 schedule (SMC: iterations)", &Prior5IterNum)
.add<std::size_t>("posterior2",
        "Enbale posterior2 schedule (SMC: iterations)", &Posterior2IterNum)
.add<std::size_t>("posterior5",
        "Enbale posterior5 schedule (SMC: iterations)", &Posterior5IterNum)
.add<bool>("parallel",
        "Enable parallel PMCMC", &Parallel, false);
