#ifndef VSMC_EXAMPLE_OPTIONS_HPP
#define VSMC_EXAMPLE_OPTIONS_HPP

#include <cstring>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

class OptionBase
{
    public :

    virtual bool compare_set (const char *, const char *) = 0;
    virtual void print_help () const = 0;
    virtual ~OptionBase () {}
};

template <typename T>
class Option : public OptionBase
{
    public :

    Option (const char *name, const char *desc, T *ptr) :
        name_(std::string("--") + name),
        desc_(desc), ptr_(ptr), has_default_(false) {}

    template <typename V>
    Option (const char *name, const char *desc, T *ptr, const V &val) :
        name_(std::string("--") + name),
        desc_(desc), ptr_(ptr), default_(val), has_default_(true)
    {*ptr = val;}

    bool compare_set (const char *name, const char *sval)
    {
        if (std::strcmp(name_.c_str(), name))
            return false;

        std::stringstream ss;
        ss << sval;
        T tval;
        ss >> tval;
        if (ss.fail()) {
            fprintf(stderr, "Invalid value for option %s: %s\n",
                    name_.c_str(), sval);
            return false;
        }

        *ptr_ = tval;

        return true;
    }

    void print_help () const
    {
        std::cout << "  " << std::setw(20) << std::left << name_ << desc_;
        if (has_default_)
            std::cout << " (default: " << default_ << ")";
        std::cout << std::endl;
    }

    private :

    std::string name_;
    std::string desc_;
    T *const ptr_;
    T default_;
    bool has_default_;
};

class OptionMap
{
    public :

    ~OptionMap ()
    {
        for (std::size_t i = 0; i != options_.size(); ++i)
            delete options_[i];
    }

    template <typename T>
    OptionMap &add (const char *name, const char *desc, T *ptr)
    {
        options_.push_back(new Option<T>(name, desc, ptr));

        return *this;
    }

    template <typename T, typename V>
    OptionMap &add (const char *name, const char *desc, T *ptr, const V &val)
    {
        options_.push_back(new Option<T>(name, desc, ptr, val));

        return *this;
    }

    bool process (int argc, const char *const *argv)
    {
        set_.clear();
        for (int ac = 1; ac != argc; ++ac) {
            if (!std::strcmp(argv[ac], "--help")) {
                for (std::size_t i = 0; i != options_.size(); ++i)
                    options_[i]->print_help();
                return true;
            }
        }

        int ac = 1;
        while (ac < argc) {
            bool set = false;
            for (std::size_t i = 0; i != options_.size(); ++i) {
                set = options_[i]->compare_set(argv[ac], argv[ac + 1]);
                if (set) set_.push_back(argv[ac]);
            }
            ac += set ? 2 : 1;
        }

        return false;
    }

    bool process (int argc, char *const *argv)
    {
        const char **cargv = new const char *[argc];
        for (int i = 0; i != argc; ++i)
            cargv[i] = argv[i];

        return process(argc, cargv);
    }

    bool count (const char *name) const
    {
        std::string oname("--");
        oname += name;
        std::vector<std::string>::const_iterator iter = set_.begin();
        for (; iter != set_.end(); ++iter)
            if (*iter == oname)
                break;

        return iter != set_.end();
    }

    private :

    std::vector<OptionBase *> options_;
    std::vector<std::string> set_;
};

#endif // VSMC_EXAMPLE_OPTIONS_HPP
