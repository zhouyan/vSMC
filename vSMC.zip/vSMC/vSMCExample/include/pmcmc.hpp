#ifndef VSMC_EXAMPLE_PMCMC_HPP
#define VSMC_EXAMPLE_PMCMC_HPP

std::size_t ChainNum;
std::size_t BurninNum;
std::size_t IterNum;
std::size_t LinearIterNum;
std::size_t Prior2IterNum;
std::size_t Prior5IterNum;
std::size_t Posterior2IterNum;
std::size_t Posterior5IterNum;
bool Parallel;

#include "move_alpha.hpp"
#include "move_pmcmc.hpp"
#include "pmcmc_do.hpp"

#endif // VSMC_EXAMPLE_PMCMC_HPP
