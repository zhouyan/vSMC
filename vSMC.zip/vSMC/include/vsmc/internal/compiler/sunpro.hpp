#ifndef VSMC_INTERNAL_COMPILER_SUNPRO_HPP
#define VSMC_INTERNAL_COMPILER_SUNPRO_HPP

#pragma error_messages(off, nonewline)
#pragma error_messages(off, anonnotype)

#endif // VSMC_INTERNAL_COMPILER_SUNPRO_HPP
