#ifndef VSMC_INTERNAL_CXX11_UTILITY_HPP
#define VSMC_INTERNAL_CXX11_UTILITY_HPP

#include <vsmc/internal/config.hpp>
#include <vsmc/cxx11/type_traits.hpp>

#endif // VSMC_INTERNAL_CXX11_UTILITY_HPP
