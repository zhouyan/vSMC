#include <cassert>

int main ()
{
    auto x = 1;
    assert(x == 1);
}
