#ifndef VSMC_EXAMPLE_PET_INIT_HPP
#define VSMC_EXAMPLE_PET_INIT_HPP

class pet_init : public BASE_INIT<pet_state, pet_init>
{
    public :

    void pre_processor (vsmc::Particle<pet_state> &particle)
    {
        particle.value().alpha(0);
        particle.value().alpha_inc(0);
        particle.set_equal_weight();
    }

    void initialize_param (vsmc::Particle<pet_state> &particle, void *info)
    {
        if (particle.value().state(0, 0).comp_num() == 0)
            particle.value().comp_num(InitCompNum);
        if (info)
            particle.value().read_data(static_cast<const pet_info *>(info));
    }

    std::size_t initialize_state (vsmc::SingleParticle<pet_state> sp)
    {
        const std::size_t cn = sp.state(0).comp_num();
        for (std::size_t d = 0; d != cn; ++d) {
            double phi_lb0 = sp.particle().value().phi_lb0(d);
            double phi_ub0 = sp.particle().value().phi_ub0(d);
            double theta_lb0 = d ?
                sp.state(0).theta(d - 1):
                sp.particle().value().theta_lb0(d);
            double theta_ub0 = sp.particle().value().theta_ub0(d);

            vsmc::cxx11::uniform_real_distribution<> rphi(
                    phi_lb0, phi_ub0);
            vsmc::cxx11::uniform_real_distribution<> rtheta(
                    theta_lb0, theta_ub0);
            sp.state(0).phi(d) = rphi(sp.rng());
            sp.state(0).theta(d) = rtheta(sp.rng());
        }
        double lambda_a0 = sp.particle().value().lambda_a0();
        double lambda_b0 = sp.particle().value().lambda_b0();
        vsmc::cxx11::gamma_distribution<> rlambda(lambda_a0, lambda_b0);
        sp.state(0).lambda() = rlambda(sp.rng());
        if (sp.state(0).lambda() < 1e-13)
            sp.state(0).lambda() = 1e-13;
        if (sp.particle().value().model() == StudentT) {
            double nu_a0 = sp.particle().value().nu_a0();
            double nu_b0 = sp.particle().value().nu_b0();
            vsmc::cxx11::uniform_real_distribution<> rnu(nu_a0, nu_b0);
            sp.state(0).nu() = 1 / rnu(sp.rng());
        }
        sp.particle().value().log_target(sp.state(0));

        return 0;
    }
};

#endif // VSMC_EXAMPLE_PET_INIT_HPP
