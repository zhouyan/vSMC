#include "pet_@smp@.hpp"
#include "smc.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "options_smc.hpp"
#include "pet_options.hpp"
#include "options_process.hpp"
#include "pet_data.hpp"

    vsmc::Sampler<pet_state> sampler(ParticleNum);
    sampler.init(pet_init());
    sampler.initialize(&info);
    info.read_time  = false;
    info.read_conv  = false;
    info.read_prior = false;
    info.read_sd    = false;
    info.read_model = false;

    std::ofstream output("is.save");
    output << "Model." << SM << '\t' << "Model." << CM << '\n';
    for (std::size_t r = 0; r != Repeat; ++r) {
        double py = 0;

        sampler.particle().value().comp_num(SM);
        sampler.initialize();
        py = 0;
        for (std::size_t i = 0; i != ParticleNum; ++i)
            py += std::exp(
                    sampler.particle().value().state(i, 0).log_likelihood());
        py /= static_cast<double>(ParticleNum);
        py = std::log(py);
        py += sampler.particle().value().log_likelihood_const();
        output << py << '\t';

        sampler.particle().value().comp_num(CM);
        sampler.initialize();
        py = 0;
        for (std::size_t i = 0; i != ParticleNum; ++i)
            py += std::exp(
                    sampler.particle().value().state(i, 0).log_likelihood());
        py /= static_cast<double>(ParticleNum);
        py = std::log(py);
        py += sampler.particle().value().log_likelihood_const();
        output << py << '\n';
    }
    output.close();
    output.clear();

    return 0;
}
