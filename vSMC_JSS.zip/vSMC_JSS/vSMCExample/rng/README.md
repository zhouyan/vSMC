# Examples of the RNG module

These examples demonstrate the RNG module of the [vSMC][vSMC] library

- `rng_cl` Generating random numbers on OpenCL devices with [vSMC][vSMC]
  utilities for the [Random123][Random123] library
- `rng_mkl` Generating random numbers using [Intel MKL][Intel MKL] with
  [vSMC][vSMC] C++11 style engines
- `rng_r123` Generating random numbers using the [Random123][Random123] library
  with [vSMC][vSMC] `RngSet` class
- `rng_std` Generating random numbers using C++11 engines
- `rng_stdbb` Generating random numbers in parallel using the [vSMC][vSMC]
  thread-local storage `RngSet` class
- `rng_u01` Generating uniform random numbers on `[0, 1]`, `(0, 1]`, `[0, 1)`
  and `(0, 0)` using the [vSMC][vSMC] `UniformRealDistribution` class

In addition, if the [TestU01][TestU01] library is found, the following tests
are built,

- `rng_mkl_test_u01`: Test [Intel MKL][Intel MKL] RNG
- `rng_r123_test_u01`: Test [Random123][Random123] RNG
- `rng_std_test_u01`: Test C++11 RNG

[Intel MKL]: http://software.intel.com/en-us/intel-mkl
[Random123]: http://www.thesalmons.org/john/random123/releases/latest/docs/index.html
[TestU01]: http://www.iro.umontreal.ca/~simardr/testu01/tu01.html
[vSMC]: http://www.cmake.org/
