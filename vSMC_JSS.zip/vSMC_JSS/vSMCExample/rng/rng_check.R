vsmc_use_hdf5 <- @VSMC_USE_HDF5_R_FLAG@

if (vsmc_use_hdf5) {
    suppressPackageStartupMessages(library(rhdf5))
    cppoutput <- h5read("@VSMC_RNG_CHECK_NAME@.hdf5", "/@VSMC_RNG_CHECK_NAME@")
    eng.names <- names(cppoutput)
} else {
    cppoutput <- read.table("@VSMC_RNG_CHECK_NAME@.tab", header = TRUE)
    eng.names <- dimnames(cppoutput)[[2]]
}

pdf("@VSMC_RNG_CHECK_NAME@.pdf", width = 14, height = 7)
for (ename in eng.names) {
    hist(cppoutput[[ename]], main = "@VSMC_RNG_CHECK_NAME@", xlab = ename)
}
