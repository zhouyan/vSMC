suppressPackageStartupMessages(library(ggplot2))

vsmc_use_hdf5 <- @VSMC_USE_HDF5_R_FLAG@

source("rng_cl_dt.R")
dist.names <- dimnames(refoutput)[[2]]

if (vsmc_use_hdf5) {
    suppressPackageStartupMessages(library(rhdf5))
    cppoutput <- h5read("rng_cl.hdf5", "/rng_cl")
} else {
    cppoutput <- read.table("rng_cl.tab", header = TRUE)
}

output <- list()
for (dname in dist.names) {
    output[[dname]] <- c(refoutput[[dname]], cppoutput[[dname]])
}
output <- as.data.frame(output)

output$Prog <- c(rep("R", N), rep("C++", N),
    rep("OpenCL 2x32", N), rep("OpenCL 4x32", N))

for (dname in dist.names) {
    if (dname != "Prog") {
        name <- paste("plot.", dname, sep ="")
        dat <- data.frame(Value = output[[dname]], Prog = output$Prog)
        .GlobalEnv[[name]] <- ggplot(dat)
        .GlobalEnv[[name]] <- .GlobalEnv[[name]] + aes(x = Value)
        .GlobalEnv[[name]] <- .GlobalEnv[[name]] + aes(group = Prog)
        .GlobalEnv[[name]] <- .GlobalEnv[[name]] + aes(color = Prog)
        .GlobalEnv[[name]] <- .GlobalEnv[[name]] + geom_density()
        .GlobalEnv[[name]] <- .GlobalEnv[[name]] + ggtitle(dname)
    }
}

pdf("rng_cl.pdf", width = 14, height = 7)
for (dname in dist.names) {
    if (dname != "Prog") {
        name <- paste("plot.", dname, sep ="")
        cat("Print ", name, "\n", sep = "")
        print(.GlobalEnv[[name]])
    }
}
garbage <- dev.off()
