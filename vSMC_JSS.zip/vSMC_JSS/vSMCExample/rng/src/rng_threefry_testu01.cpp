#include "rng_testu01.hpp"
#include <vsmc/rng/threefry.hpp>

VSMC_TESTU01_GEN_STD(VSMC_Threefry2x32, vsmc::Threefry2x32)
VSMC_TESTU01_GEN_STD(VSMC_Threefry4x32, vsmc::Threefry4x32)
VSMC_TESTU01_GEN_STD(VSMC_Threefry2x64, vsmc::Threefry2x64)
VSMC_TESTU01_GEN_STD(VSMC_Threefry4x64, vsmc::Threefry4x64)

int main (int argc, char **argv)
{
    vsmc::ProgramOptionMap config;
    testu01_args(config);

    VSMC_TESTU01_OPTION(VSMC_Threefry2x32);
    VSMC_TESTU01_OPTION(VSMC_Threefry4x32);
    VSMC_TESTU01_OPTION(VSMC_Threefry2x64);
    VSMC_TESTU01_OPTION(VSMC_Threefry4x64);

    config.process(argc, argv);

    VSMC_TESTU01(VSMC_Threefry2x32);
    VSMC_TESTU01(VSMC_Threefry4x32);
    VSMC_TESTU01(VSMC_Threefry2x64);
    VSMC_TESTU01(VSMC_Threefry4x64);

    return 0;
}
