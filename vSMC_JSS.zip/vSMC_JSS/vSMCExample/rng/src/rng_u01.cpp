#include "rng_u01.hpp"

int main (int argc, char **argv)
{
    std::size_t N = DefaultN;

    if (argc > 1)
        N = static_cast<std::size_t>(std::atoi(argv[1]));

    do_test(N, "rng_u01");

    return 0;
}
