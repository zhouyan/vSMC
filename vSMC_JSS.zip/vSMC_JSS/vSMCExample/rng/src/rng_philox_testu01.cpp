#include "rng_testu01.hpp"
#include <vsmc/rng/philox.hpp>

VSMC_TESTU01_GEN_STD(VSMC_Philox2x32, vsmc::Philox2x32)
VSMC_TESTU01_GEN_STD(VSMC_Philox4x32, vsmc::Philox4x32)
VSMC_TESTU01_GEN_STD(VSMC_Philox2x64, vsmc::Philox2x64)
VSMC_TESTU01_GEN_STD(VSMC_Philox4x64, vsmc::Philox4x64)

int main (int argc, char **argv)
{
    vsmc::ProgramOptionMap config;
    testu01_args(config);

    VSMC_TESTU01_OPTION(VSMC_Philox2x32);
    VSMC_TESTU01_OPTION(VSMC_Philox4x32);
    VSMC_TESTU01_OPTION(VSMC_Philox2x64);
    VSMC_TESTU01_OPTION(VSMC_Philox4x64);

    config.process(argc, argv);

    VSMC_TESTU01(VSMC_Philox2x32);
    VSMC_TESTU01(VSMC_Philox4x32);
    VSMC_TESTU01(VSMC_Philox2x64);
    VSMC_TESTU01(VSMC_Philox4x64);

    return 0;
}
