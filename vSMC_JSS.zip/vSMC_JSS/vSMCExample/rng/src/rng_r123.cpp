#include "rng_r123.hpp"

int main (int argc, char **argv)
{
    std::size_t N = DefaultN;

    if (argc > 1)
        N = static_cast<std::size_t>(std::atoi(argv[1]));

    do_test(N, "rng_r123");

    return 0;
}
