#include "rng_testu01.hpp"
#include <vsmc/rng/rd_seed.hpp>

VSMC_TESTU01_GEN_STD(VSMC_RD_SEED16, vsmc::RdSeed16)
VSMC_TESTU01_GEN_STD(VSMC_RD_SEED32, vsmc::RdSeed32)
VSMC_TESTU01_GEN_STD(VSMC_RD_SEED64, vsmc::RdSeed64)

int main (int argc, char **argv)
{
    vsmc::ProgramOptionMap config;
    testu01_args(config);

    VSMC_TESTU01_OPTION(VSMC_RD_SEED16);
    VSMC_TESTU01_OPTION(VSMC_RD_SEED32);
    VSMC_TESTU01_OPTION(VSMC_RD_SEED64);

    config.process(argc, argv);

    VSMC_TESTU01(VSMC_RD_SEED16);
    VSMC_TESTU01(VSMC_RD_SEED32);
    VSMC_TESTU01(VSMC_RD_SEED64);

    return 0;
}
