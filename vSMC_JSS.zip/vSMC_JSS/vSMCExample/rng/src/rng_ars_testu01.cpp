#include "rng_testu01.hpp"
#include <vsmc/rng/ars.hpp>

namespace vsmc {

typedef vsmc::ARSEngine<uint32_t, 10, 1> ARS_32_1;
typedef vsmc::ARSEngine<uint64_t, 10, 1> ARS_64_1;
typedef vsmc::ARSEngine<uint32_t, 10, 2> ARS_32_2;
typedef vsmc::ARSEngine<uint64_t, 10, 2> ARS_64_2;
typedef vsmc::ARSEngine<uint32_t, 10, 4> ARS_32_4;
typedef vsmc::ARSEngine<uint64_t, 10, 4> ARS_64_4;
typedef vsmc::ARSEngine<uint32_t, 10, 8> ARS_32_8;
typedef vsmc::ARSEngine<uint64_t, 10, 8> ARS_64_8;

}

VSMC_TESTU01_GEN_STD(VSMC_ARS_32_1, vsmc::ARS_32_1)
VSMC_TESTU01_GEN_STD(VSMC_ARS_64_1, vsmc::ARS_64_1)
VSMC_TESTU01_GEN_STD(VSMC_ARS_32_2, vsmc::ARS_32_2)
VSMC_TESTU01_GEN_STD(VSMC_ARS_64_2, vsmc::ARS_64_2)
VSMC_TESTU01_GEN_STD(VSMC_ARS_32_4, vsmc::ARS_32_4)
VSMC_TESTU01_GEN_STD(VSMC_ARS_64_4, vsmc::ARS_64_4)
VSMC_TESTU01_GEN_STD(VSMC_ARS_32_8, vsmc::ARS_32_8)
VSMC_TESTU01_GEN_STD(VSMC_ARS_64_8, vsmc::ARS_64_8)

int main (int argc, char **argv)
{
    vsmc::ProgramOptionMap config;
    testu01_args(config);

    VSMC_TESTU01_OPTION(VSMC_ARS_32_1);
    VSMC_TESTU01_OPTION(VSMC_ARS_64_1);
    VSMC_TESTU01_OPTION(VSMC_ARS_32_2);
    VSMC_TESTU01_OPTION(VSMC_ARS_64_2);
    VSMC_TESTU01_OPTION(VSMC_ARS_32_4);
    VSMC_TESTU01_OPTION(VSMC_ARS_64_4);
    VSMC_TESTU01_OPTION(VSMC_ARS_32_8);
    VSMC_TESTU01_OPTION(VSMC_ARS_64_8);

    config.process(argc, argv);

    VSMC_TESTU01(VSMC_ARS_32_1);
    VSMC_TESTU01(VSMC_ARS_64_1);
    VSMC_TESTU01(VSMC_ARS_32_2);
    VSMC_TESTU01(VSMC_ARS_64_2);
    VSMC_TESTU01(VSMC_ARS_32_4);
    VSMC_TESTU01(VSMC_ARS_64_4);
    VSMC_TESTU01(VSMC_ARS_32_8);
    VSMC_TESTU01(VSMC_ARS_64_8);

    return 0;
}
