#include "rng_rd_rand.hpp"

int main (int argc, char **argv)
{
    std::size_t N = DefaultN;

    if (argc > 1)
        N = static_cast<std::size_t>(std::atoi(argv[1]));

    do_test(N, "rng_rd_rand");

    return 0;
}
