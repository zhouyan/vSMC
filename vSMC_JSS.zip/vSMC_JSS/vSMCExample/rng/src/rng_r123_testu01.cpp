#include "rng_testu01.hpp"

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable:4521)
#endif
#include <Random123/philox.h>
#include <Random123/threefry.h>
#include <Random123/conventional/Engine.hpp>
#ifdef _MSC_VER
#pragma warning(pop)
#endif

#if VSMC_USE_AES_NI
#include <Random123/aes.h>
#include <Random123/ars.h>
#endif

VSMC_TESTU01_GEN_STD(R123_Threefry2x32, r123::Engine<r123::Threefry2x32>)
VSMC_TESTU01_GEN_STD(R123_Threefry4x32, r123::Engine<r123::Threefry4x32>)
VSMC_TESTU01_GEN_STD(R123_Threefry2x64, r123::Engine<r123::Threefry2x64>)
VSMC_TESTU01_GEN_STD(R123_Threefry4x64, r123::Engine<r123::Threefry4x64>)
VSMC_TESTU01_GEN_STD(R123_Philox2x32,   r123::Engine<r123::Philox2x32>)
VSMC_TESTU01_GEN_STD(R123_Philox4x32,   r123::Engine<r123::Philox4x32>)
VSMC_TESTU01_GEN_STD(R123_Philox2x64,   r123::Engine<r123::Philox2x64>)
VSMC_TESTU01_GEN_STD(R123_Philox4x64,   r123::Engine<r123::Philox4x64>)

#if VSMC_USE_AES_NI
VSMC_TESTU01_GEN_STD(R123_AESNI4x32, r123::Engine<r123::AESNI4x32>)
VSMC_TESTU01_GEN_STD(R123_ARS4x32r5,  r123::Engine<r123::ARS4x32_R<5> >)
VSMC_TESTU01_GEN_STD(R123_ARS4x32r6,  r123::Engine<r123::ARS4x32_R<6> >)
VSMC_TESTU01_GEN_STD(R123_ARS4x32r7,  r123::Engine<r123::ARS4x32_R<7> >)
VSMC_TESTU01_GEN_STD(R123_ARS4x32r8,  r123::Engine<r123::ARS4x32_R<8> >)
VSMC_TESTU01_GEN_STD(R123_ARS4x32r9,  r123::Engine<r123::ARS4x32_R<9> >)
VSMC_TESTU01_GEN_STD(R123_ARS4x32r10, r123::Engine<r123::ARS4x32_R<10> >)
#endif

int main (int argc, char **argv)
{
    vsmc::ProgramOptionMap config;
    testu01_args(config);

    VSMC_TESTU01_OPTION(R123_Threefry2x32);
    VSMC_TESTU01_OPTION(R123_Threefry4x32);
    VSMC_TESTU01_OPTION(R123_Threefry2x64);
    VSMC_TESTU01_OPTION(R123_Threefry4x64);
    VSMC_TESTU01_OPTION(R123_Philox2x32);
    VSMC_TESTU01_OPTION(R123_Philox4x32);
    VSMC_TESTU01_OPTION(R123_Philox2x64);
    VSMC_TESTU01_OPTION(R123_Philox4x64);

#if VSMC_USE_AES_NI
    VSMC_TESTU01_OPTION(R123_AESNI4x32);
    VSMC_TESTU01_OPTION(R123_ARS4x32r5);
    VSMC_TESTU01_OPTION(R123_ARS4x32r6);
    VSMC_TESTU01_OPTION(R123_ARS4x32r7);
    VSMC_TESTU01_OPTION(R123_ARS4x32r8);
    VSMC_TESTU01_OPTION(R123_ARS4x32r9);
    VSMC_TESTU01_OPTION(R123_ARS4x32r10);
#endif

    config.process(argc, argv);

    VSMC_TESTU01(R123_Threefry2x32);
    VSMC_TESTU01(R123_Threefry4x32);
    VSMC_TESTU01(R123_Threefry2x64);
    VSMC_TESTU01(R123_Threefry4x64);
    VSMC_TESTU01(R123_Philox2x32);
    VSMC_TESTU01(R123_Philox4x32);
    VSMC_TESTU01(R123_Philox2x64);
    VSMC_TESTU01(R123_Philox4x64);

#if VSMC_USE_AES_NI
    VSMC_TESTU01(R123_AESNI4x32);
    VSMC_TESTU01(R123_ARS4x32r5);
    VSMC_TESTU01(R123_ARS4x32r6);
    VSMC_TESTU01(R123_ARS4x32r7);
    VSMC_TESTU01(R123_ARS4x32r8);
    VSMC_TESTU01(R123_ARS4x32r9);
    VSMC_TESTU01(R123_ARS4x32r10);
#endif

    return 0;
}
