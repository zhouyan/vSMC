#include "rng_testu01.hpp"
#include <vsmc/rng/rd_rand.hpp>

VSMC_TESTU01_GEN_STD(VSMC_RD_RAND16, vsmc::RdRand16)
VSMC_TESTU01_GEN_STD(VSMC_RD_RAND32, vsmc::RdRand32)
VSMC_TESTU01_GEN_STD(VSMC_RD_RAND64, vsmc::RdRand64)

int main (int argc, char **argv)
{
    vsmc::ProgramOptionMap config;
    testu01_args(config);

    VSMC_TESTU01_OPTION(VSMC_RD_RAND16);
    VSMC_TESTU01_OPTION(VSMC_RD_RAND32);
    VSMC_TESTU01_OPTION(VSMC_RD_RAND64);

    config.process(argc, argv);

    VSMC_TESTU01(VSMC_RD_RAND16);
    VSMC_TESTU01(VSMC_RD_RAND32);
    VSMC_TESTU01(VSMC_RD_RAND64);

    return 0;
}
