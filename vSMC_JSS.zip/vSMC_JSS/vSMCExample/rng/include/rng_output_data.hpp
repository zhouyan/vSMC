#ifndef VSMC_EXAMPLE_RNG_OUTPUT_DATA_HPP
#define VSMC_EXAMPLE_RNG_OUTPUT_DATA_HPP

#include <cstddef>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>

template <typename T>
inline void do_output_data (const std::string &base_name,
        const std::vector<std::string> &vnames,
        const std::vector<std::vector<T> > &values)
{
    if (vnames.size() != values.size())
        return;

    if (vnames.size() == 0)
        return;

    if (values[0].size() == 0)
        return;

    std::size_t M = vnames.size();
    std::size_t N = values[0].size();
    N = N > 10000 ? 10000 : N;

    std::string file_name = base_name + ".tab";
    std::ofstream output_file(file_name.c_str());
    for (std::size_t j = 0; j != M; ++j)
        output_file << vnames[j] << ' ';
    output_file << '\n';

    output_file << std::scientific;
    for (std::size_t i = 0; i != N; ++i) {
        for (std::size_t j = 0; j != M; ++j)
            output_file << values[j][i] << ' ';
        output_file << '\n';
    }

    output_file.close();
    output_file.clear();
}

#endif // VSMC_EXAMPLE_RNG_OUTPUT_DATA_HPP
