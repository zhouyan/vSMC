#ifndef VSMC_EXAMPLE_RNG_ARS_HPP
#define VSMC_EXAMPLE_RNG_ARS_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/ars.hpp>

#if VSMC_USE_RANDOM123
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable:4521)
#endif
#include <Random123/ars.h>
#include <Random123/conventional/Engine.hpp>
#ifdef _MSC_VER
#pragma warning(pop)
#endif
#endif // VSMC_USE_RANDOM123

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    typedef vsmc::ARSEngine<uint32_t, 10, 1> ARS_32_1;
    typedef vsmc::ARSEngine<uint64_t, 10, 1> ARS_64_1;
    typedef vsmc::ARSEngine<uint32_t, 10, 2> ARS_32_2;
    typedef vsmc::ARSEngine<uint64_t, 10, 2> ARS_64_2;
    typedef vsmc::ARSEngine<uint32_t, 10, 4> ARS_32_4;
    typedef vsmc::ARSEngine<uint64_t, 10, 4> ARS_64_4;
    typedef vsmc::ARSEngine<uint32_t, 10, 8> ARS_32_8;
    typedef vsmc::ARSEngine<uint64_t, 10, 8> ARS_64_8;

    VSMC_DO_ENG(do_eng, ARS_32_1, "VSMC_ARS_32_1");
    VSMC_DO_ENG(do_eng, ARS_64_1, "VSMC_ARS_64_1");
    VSMC_DO_ENG(do_eng, ARS_32_2, "VSMC_ARS_32_2");
    VSMC_DO_ENG(do_eng, ARS_64_2, "VSMC_ARS_64_2");
    VSMC_DO_ENG(do_eng, ARS_32_4, "VSMC_ARS_32_4");
    VSMC_DO_ENG(do_eng, ARS_64_4, "VSMC_ARS_64_4");
    VSMC_DO_ENG(do_eng, ARS_32_8, "VSMC_ARS_32_8");
    VSMC_DO_ENG(do_eng, ARS_64_8, "VSMC_ARS_64_8");

    VSMC_DO_ENG(do_set, ARS_32_1, "VSMC_ARS_32_1_RS");
    VSMC_DO_ENG(do_set, ARS_64_1, "VSMC_ARS_64_1_RS");
    VSMC_DO_ENG(do_set, ARS_32_2, "VSMC_ARS_32_2_RS");
    VSMC_DO_ENG(do_set, ARS_64_2, "VSMC_ARS_64_2_RS");
    VSMC_DO_ENG(do_set, ARS_32_4, "VSMC_ARS_32_4_RS");
    VSMC_DO_ENG(do_set, ARS_64_4, "VSMC_ARS_64_4_RS");
    VSMC_DO_ENG(do_set, ARS_32_8, "VSMC_ARS_32_8_RS");
    VSMC_DO_ENG(do_set, ARS_64_8, "VSMC_ARS_64_8_RS");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, ARS_32_1, "VSMC_ARS_32_1_MT");
    VSMC_DO_ENG(do_tbb, ARS_64_1, "VSMC_ARS_64_1_MT");
    VSMC_DO_ENG(do_tbb, ARS_32_2, "VSMC_ARS_32_2_MT");
    VSMC_DO_ENG(do_tbb, ARS_64_2, "VSMC_ARS_64_2_MT");
    VSMC_DO_ENG(do_tbb, ARS_32_4, "VSMC_ARS_32_4_MT");
    VSMC_DO_ENG(do_tbb, ARS_64_4, "VSMC_ARS_64_4_MT");
    VSMC_DO_ENG(do_tbb, ARS_32_8, "VSMC_ARS_32_8_MT");
    VSMC_DO_ENG(do_tbb, ARS_64_8, "VSMC_ARS_64_8_MT");
#endif

#if VSMC_USE_RANDOM123
    VSMC_DO_ENG(do_eng, r123::Engine<r123::ARS4x32_R<10> >, "R123_ARS4x32");
    VSMC_DO_ENG(do_set, r123::Engine<r123::ARS4x32_R<10> >, "R123_ARS4x32_RS");
#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, r123::Engine<r123::ARS4x32_R<10> >, "R123_ARS4x32_MT");
#endif
#endif
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_ARS_HPP
