#ifndef VSMC_EXAMPLE_RNG_GSL_HPP
#define VSMC_EXAMPLE_RNG_GSL_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/gsl_rng.hpp>

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    VSMC_DO_ENG(do_eng, vsmc::GSL_MT19937,   "GSL_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::GSL_RANLXS0,   "GSL_RANLXS0");
    VSMC_DO_ENG(do_eng, vsmc::GSL_RANLXS1,   "GSL_RANLXS1");
    VSMC_DO_ENG(do_eng, vsmc::GSL_RANLXS2,   "GSL_RANLXS2");
    VSMC_DO_ENG(do_eng, vsmc::GSL_RANLXD1,   "GSL_RANLXD1");
    VSMC_DO_ENG(do_eng, vsmc::GSL_RANLXD2,   "GSL_RANLXD2");
    VSMC_DO_ENG(do_eng, vsmc::GSL_RANLUX,    "GSL_RANLUX");
    VSMC_DO_ENG(do_eng, vsmc::GSL_RANLUX389, "GSL_RANLUX389");
    VSMC_DO_ENG(do_eng, vsmc::GSL_CMRG,      "GSL_CMRG");
    VSMC_DO_ENG(do_eng, vsmc::GSL_MRG,       "GSL_MRG");
    VSMC_DO_ENG(do_eng, vsmc::GSL_TAUS,      "GSL_TAUS");
    VSMC_DO_ENG(do_eng, vsmc::GSL_TAUS2,     "GSL_TAUS2");
    VSMC_DO_ENG(do_eng, vsmc::GSL_GFSR4,     "GSL_GFSR4");
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_GSL_HPP
