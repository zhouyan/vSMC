#ifndef VSMC_EXAMPLE_RNG_ENG_HPP
#define VSMC_EXAMPLE_RNG_ENG_HPP

#include <vsmc/cxx11/random.hpp>
#include <vsmc/rng/rng_set.hpp>
#include <vsmc/utility/stop_watch.hpp>

#if VSMC_USE_HDF5
#include "rng_output_data_hdf5.hpp"
#else
#include "rng_output_data.hpp"
#endif

static const std::size_t DefaultN = 1000000;

#define VSMC_DO_ENG(func, eng, name) \
    func< eng >(N, name, enames, values, sw, bytes);

template <typename Eng>
inline void do_eng (std::size_t N, const std::string &name,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    Eng eng;
    vsmc::cxx11::uniform_real_distribution<double> runif(0, 1);
    std::vector<double> output(N);
    double *const output_ptr = &output[0];
    vsmc::StopWatch watch;

    watch.start();
    for (std::size_t i = 0; i != N; ++i)
        eng();
    watch.stop();
    for (std::size_t i = 0; i != N; ++i)
        output_ptr[i] = runif(eng);

    enames.push_back(name);
    values.push_back(output);
    sw.push_back(watch);
    bytes.push_back(N * sizeof(typename Eng::result_type));
}

template <typename Eng>
inline void do_set (std::size_t N, const std::string &name,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    std::size_t M = 1;
    if (N % 1000 == 0 && N > 1000) {
        M = 1000;
        N /= 1000;
    }

    vsmc::RngSet<Eng, vsmc::Vector> rng_set(N);
    vsmc::cxx11::uniform_real_distribution<double> runif(0, 1);
    std::vector<double> output(N * M);
    double *output_ptr = &output[0];
    vsmc::StopWatch watch;

    watch.start();
    for (std::size_t i = 0; i != N; ++i)
        for (std::size_t j = 0; j != M; ++j)
            rng_set[i]();
    watch.stop();
    for (std::size_t i = 0; i != N; ++i)
        for (std::size_t j = 0; j != M; ++j, ++output_ptr)
            *output_ptr = runif(rng_set[i]);

    enames.push_back(name);
    values.push_back(output);
    sw.push_back(watch);
    bytes.push_back(N * M * sizeof(typename Eng::result_type));
}

#if VSMC_USE_TBB
#include <tbb/tbb.h>

template <typename Eng>
class do_tbb_work
{
    public :

    do_tbb_work (std::size_t M, vsmc::RngSet<Eng, vsmc::Vector> &rng_set) :
        rng_set_(rng_set), M_(M) {}

    void operator() (const tbb::blocked_range<std::size_t> &range) const
    {
        const std::size_t M = M_;
        for (std::size_t i = range.begin(); i != range.end(); ++i)
            for (std::size_t j = 0; j != M; ++j)
                rng_set_[i]();
    }

    private :

    vsmc::RngSet<Eng, vsmc::Vector> &rng_set_;
    std::size_t M_;
}; // class do_tbb_work

template <typename Eng>
inline void do_tbb (std::size_t N, const std::string &name,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    std::size_t M = 1;
    if (N % 1000 == 0 && N > 1000) {
        M = 1000;
        N /= 1000;
    }

    vsmc::RngSet<Eng, vsmc::Vector> rng_set(N);
    vsmc::cxx11::uniform_real_distribution<double> runif(0, 1);
    std::vector<double> output(N * M);
    double *output_ptr = &output[0];
    vsmc::StopWatch watch;
    do_tbb_work<Eng> work(M, rng_set);

    tbb::parallel_for(tbb::blocked_range<std::size_t>(0, N), work);
    watch.start();
    tbb::parallel_for(tbb::blocked_range<std::size_t>(0, N), work);
    watch.stop();
    for (std::size_t i = 0; i != N; ++i)
        for (std::size_t j = 0; j != M; ++j, ++output_ptr)
            *output_ptr = runif(rng_set[i]);

    enames.push_back(name);
    values.push_back(output);
    sw.push_back(watch);
    bytes.push_back(N * M * sizeof(typename Eng::result_type));
}

#endif // VSMC_USE_TBB

inline void print_char (char a, std::size_t n = 100)
{
    for (std::size_t i = 0; i != n; ++i)
        std::cout << a;
    std::cout << std::endl;
}

inline void do_output_sw (
        const std::string &name,
        const std::vector<std::string> &enames,
        const std::vector<vsmc::StopWatch> &sw,
        const std::vector<std::size_t> &bytes)
{
    std::size_t M = enames.size();
    if (M == 0) return;
    if (sw.size() != M) return;

    print_char('=');
    std::cout << std::left  << std::setw(40) << name;
    std::cout << std::right << std::setw(20) << "Time (ms)";
    std::cout << std::right << std::setw(20) << "GB/s";
    std::cout << std::right << std::setw(20) << "Speedup";
    std::cout << std::endl;
    print_char('-');

    double tbase = sw[0].milliseconds();
    for (std::size_t j = 0; j != M; ++j) {
        double time = sw[j].milliseconds();
        double gbps = static_cast<double>(bytes[j]) / time * 1e-6;
        std::cout << std::left  << std::setw(40) << enames[j];
        std::cout << std::right << std::setw(20) << std::fixed << time;
        std::cout << std::right << std::setw(20) << std::fixed << gbps;
        std::cout << std::right << std::setw(20) << std::fixed << tbase / time;
        std::cout << std::endl;
    }
    print_char('=');
}

#endif // VSMC_EXAMPLE_RNG_ENG_HPP
