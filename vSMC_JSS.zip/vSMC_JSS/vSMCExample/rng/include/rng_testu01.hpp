#ifndef VSMC_EXAMPLE_RNG_TESTU01_HPP
#define VSMC_EXAMPLE_RNG_TESTU01_HPP

#include <vsmc/cxx11/random.hpp>
#include <vsmc/utility/program_option.hpp>

extern "C" {
#include <unif01.h>
#include <bbattery.h>
}

#define VSMC_TESTU01_GEN_STD(name, Eng) \
extern "C" {                                                                 \
    inline double name (void)                                                \
    {                                                                        \
        static vsmc::cxx11::uniform_real_distribution<double> runif(0, 1);   \
        static Eng eng;                                                      \
                                                                             \
        return runif(eng);                                                   \
    }                                                                        \
}

#define VSMC_TESTU01_GEN_MKL(name, BRNG) \
extern "C" {                                                                 \
    inline double name (void)                                                \
    {                                                                        \
        static vsmc::MKLStream<BRNG> stream;                                 \
        static vsmc::MKLUniformDistribution<double> runif(0, 1);             \
                                                                             \
        return runif(stream);                                                \
    }                                                                        \
}

#define VSMC_TESTU01_OPTION(Gen) \
    bool Test##Gen = false;                                                        \
    config.add(#Gen, "Run RNG " #Gen " tests", &Test##Gen, false);

#define VSMC_TESTU01(Gen) if (Test##Gen) testu01(#Gen, Gen);

extern "C" {
    typedef double (*gf_type) (void);
}

static bool SmallCrush;
static bool Crush;
static bool BigCrush;
static bool DieHard;
static bool FIPS_140_2;

inline void testu01_args (vsmc::ProgramOptionMap &config)
{
    config
        .add("SmallCrush", "Run SmallCrush tests", &SmallCrush, false)
        .add("Crush",      "Run Crush tests",      &Crush,      false)
        .add("BigCrush",   "Run BigCrush tests",   &BigCrush,   false)
        .add("DieHard",    "Run DieHard tests",    &DieHard,    false)
        .add("FIPS_140_2", "Run FIPS_140_2 tests", &FIPS_140_2, false);
}

inline void testu01 (const char *name, gf_type gf)
{
    unif01_Gen *gen = unif01_CreateExternGen01(const_cast<char *>(name), gf);

    if (SmallCrush) bbattery_SmallCrush    (gen);
    if (Crush)      bbattery_Crush         (gen);
    if (BigCrush)   bbattery_BigCrush      (gen);
    if (DieHard)    bbattery_pseudoDIEHARD (gen);
    if (FIPS_140_2) bbattery_FIPS_140_2    (gen);

    unif01_DeleteExternGen01(gen);
}

#endif // VSMC_EXAMPLE_RNG_TESTU01_HPP
