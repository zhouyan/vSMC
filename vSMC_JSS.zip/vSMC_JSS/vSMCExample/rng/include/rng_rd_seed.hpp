#ifndef VSMC_EXAMPLE_RNG_RD_SEED_HPP
#define VSMC_EXAMPLE_RNG_RD_SEED_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/rd_seed.hpp>

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    VSMC_DO_ENG(do_eng, vsmc::RdSeed16,    "VSMC_RD_SEED6");
    VSMC_DO_ENG(do_eng, vsmc::RdSeed32,    "VSMC_RD_SEED2");
    VSMC_DO_ENG(do_eng, vsmc::RdSeed64,    "VSMC_RD_SEED4");

    VSMC_DO_ENG(do_set, vsmc::RdSeed16,    "VSMC_RD_SEED16 (RS)");
    VSMC_DO_ENG(do_set, vsmc::RdSeed32,    "VSMC_RD_SEED32 (RS)");
    VSMC_DO_ENG(do_set, vsmc::RdSeed64,    "VSMC_RD_SEED64 (RS)");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, vsmc::RdSeed16,    "VSMC_RD_SEED16 (MT)");
    VSMC_DO_ENG(do_tbb, vsmc::RdSeed32,    "VSMC_RD_SEED32 (MT)");
    VSMC_DO_ENG(do_tbb, vsmc::RdSeed64,    "VSMC_RD_SEED64 (MT)");
#endif
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_RD_SEED_HPP
