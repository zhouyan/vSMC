#ifndef VSMC_EXAMPLE_RNG_AES_HPP
#define VSMC_EXAMPLE_RNG_AES_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/aes.hpp>

#if VSMC_USE_RANDOM123
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable:4521)
#endif
#include <Random123/aes.h>
#include <Random123/conventional/Engine.hpp>
#ifdef _MSC_VER
#pragma warning(pop)
#endif
#endif // VSMC_USE_RANDOM123

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    typedef vsmc::AES128Engine<uint32_t, 1> AES128_32_1;
    typedef vsmc::AES128Engine<uint64_t, 1> AES128_64_1;
    typedef vsmc::AES128Engine<uint32_t, 2> AES128_32_2;
    typedef vsmc::AES128Engine<uint64_t, 2> AES128_64_2;
    typedef vsmc::AES128Engine<uint32_t, 4> AES128_32_4;
    typedef vsmc::AES128Engine<uint64_t, 4> AES128_64_4;
    typedef vsmc::AES128Engine<uint32_t, 8> AES128_32_8;
    typedef vsmc::AES128Engine<uint64_t, 8> AES128_64_8;

    VSMC_DO_ENG(do_eng, AES128_32_1, "VSMC_AES128_32_1");
    VSMC_DO_ENG(do_eng, AES128_64_1, "VSMC_AES128_64_1");
    VSMC_DO_ENG(do_eng, AES128_32_2, "VSMC_AES128_32_2");
    VSMC_DO_ENG(do_eng, AES128_64_2, "VSMC_AES128_64_2");
    VSMC_DO_ENG(do_eng, AES128_32_4, "VSMC_AES128_32_4");
    VSMC_DO_ENG(do_eng, AES128_64_4, "VSMC_AES128_64_4");
    VSMC_DO_ENG(do_eng, AES128_32_8, "VSMC_AES128_32_8");
    VSMC_DO_ENG(do_eng, AES128_64_8, "VSMC_AES128_64_8");

    VSMC_DO_ENG(do_set, AES128_32_1, "VSMC_AES128_32_1_RS");
    VSMC_DO_ENG(do_set, AES128_64_1, "VSMC_AES128_64_1_RS");
    VSMC_DO_ENG(do_set, AES128_32_2, "VSMC_AES128_32_2_RS");
    VSMC_DO_ENG(do_set, AES128_64_2, "VSMC_AES128_64_2_RS");
    VSMC_DO_ENG(do_set, AES128_32_4, "VSMC_AES128_32_4_RS");
    VSMC_DO_ENG(do_set, AES128_64_4, "VSMC_AES128_64_4_RS");
    VSMC_DO_ENG(do_set, AES128_32_8, "VSMC_AES128_32_8_RS");
    VSMC_DO_ENG(do_set, AES128_64_8, "VSMC_AES128_64_8_RS");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, AES128_32_1, "VSMC_AES128_32_1_MT");
    VSMC_DO_ENG(do_tbb, AES128_64_1, "VSMC_AES128_64_1_MT");
    VSMC_DO_ENG(do_tbb, AES128_32_2, "VSMC_AES128_32_2_MT");
    VSMC_DO_ENG(do_tbb, AES128_64_2, "VSMC_AES128_64_2_MT");
    VSMC_DO_ENG(do_tbb, AES128_32_4, "VSMC_AES128_32_4_MT");
    VSMC_DO_ENG(do_tbb, AES128_64_4, "VSMC_AES128_64_4_MT");
    VSMC_DO_ENG(do_tbb, AES128_32_8, "VSMC_AES128_32_8_MT");
    VSMC_DO_ENG(do_tbb, AES128_64_8, "VSMC_AES128_64_8_MT");
#endif

    typedef vsmc::AES192Engine<uint32_t, 1> AES192_32_1;
    typedef vsmc::AES192Engine<uint64_t, 1> AES192_64_1;
    typedef vsmc::AES192Engine<uint32_t, 2> AES192_32_2;
    typedef vsmc::AES192Engine<uint64_t, 2> AES192_64_2;
    typedef vsmc::AES192Engine<uint32_t, 4> AES192_32_4;
    typedef vsmc::AES192Engine<uint64_t, 4> AES192_64_4;
    typedef vsmc::AES192Engine<uint32_t, 8> AES192_32_8;
    typedef vsmc::AES192Engine<uint64_t, 8> AES192_64_8;

    VSMC_DO_ENG(do_eng, AES192_32_1, "VSMC_AES192_32_1");
    VSMC_DO_ENG(do_eng, AES192_64_1, "VSMC_AES192_64_1");
    VSMC_DO_ENG(do_eng, AES192_32_2, "VSMC_AES192_32_2");
    VSMC_DO_ENG(do_eng, AES192_64_2, "VSMC_AES192_64_2");
    VSMC_DO_ENG(do_eng, AES192_32_4, "VSMC_AES192_32_4");
    VSMC_DO_ENG(do_eng, AES192_64_4, "VSMC_AES192_64_4");
    VSMC_DO_ENG(do_eng, AES192_32_8, "VSMC_AES192_32_8");
    VSMC_DO_ENG(do_eng, AES192_64_8, "VSMC_AES192_64_8");

    VSMC_DO_ENG(do_set, AES192_32_1, "VSMC_AES192_32_1_RS");
    VSMC_DO_ENG(do_set, AES192_64_1, "VSMC_AES192_64_1_RS");
    VSMC_DO_ENG(do_set, AES192_32_2, "VSMC_AES192_32_2_RS");
    VSMC_DO_ENG(do_set, AES192_64_2, "VSMC_AES192_64_2_RS");
    VSMC_DO_ENG(do_set, AES192_32_4, "VSMC_AES192_32_4_RS");
    VSMC_DO_ENG(do_set, AES192_64_4, "VSMC_AES192_64_4_RS");
    VSMC_DO_ENG(do_set, AES192_32_8, "VSMC_AES192_32_8_RS");
    VSMC_DO_ENG(do_set, AES192_64_8, "VSMC_AES192_64_8_RS");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, AES192_32_1, "VSMC_AES192_32_1_MT");
    VSMC_DO_ENG(do_tbb, AES192_64_1, "VSMC_AES192_64_1_MT");
    VSMC_DO_ENG(do_tbb, AES192_32_2, "VSMC_AES192_32_2_MT");
    VSMC_DO_ENG(do_tbb, AES192_64_2, "VSMC_AES192_64_2_MT");
    VSMC_DO_ENG(do_tbb, AES192_32_4, "VSMC_AES192_32_4_MT");
    VSMC_DO_ENG(do_tbb, AES192_64_4, "VSMC_AES192_64_4_MT");
    VSMC_DO_ENG(do_tbb, AES192_32_8, "VSMC_AES192_32_8_MT");
    VSMC_DO_ENG(do_tbb, AES192_64_8, "VSMC_AES192_64_8_MT");
#endif

    typedef vsmc::AES256Engine<uint32_t, 1> AES256_32_1;
    typedef vsmc::AES256Engine<uint64_t, 1> AES256_64_1;
    typedef vsmc::AES256Engine<uint32_t, 2> AES256_32_2;
    typedef vsmc::AES256Engine<uint64_t, 2> AES256_64_2;
    typedef vsmc::AES256Engine<uint32_t, 4> AES256_32_4;
    typedef vsmc::AES256Engine<uint64_t, 4> AES256_64_4;
    typedef vsmc::AES256Engine<uint32_t, 8> AES256_32_8;
    typedef vsmc::AES256Engine<uint64_t, 8> AES256_64_8;

    VSMC_DO_ENG(do_eng, AES256_32_1, "VSMC_AES256_32_1");
    VSMC_DO_ENG(do_eng, AES256_64_1, "VSMC_AES256_64_1");
    VSMC_DO_ENG(do_eng, AES256_32_2, "VSMC_AES256_32_2");
    VSMC_DO_ENG(do_eng, AES256_64_2, "VSMC_AES256_64_2");
    VSMC_DO_ENG(do_eng, AES256_32_4, "VSMC_AES256_32_4");
    VSMC_DO_ENG(do_eng, AES256_64_4, "VSMC_AES256_64_4");
    VSMC_DO_ENG(do_eng, AES256_32_8, "VSMC_AES256_32_8");
    VSMC_DO_ENG(do_eng, AES256_64_8, "VSMC_AES256_64_8");

    VSMC_DO_ENG(do_set, AES256_32_1, "VSMC_AES256_32_1_RS");
    VSMC_DO_ENG(do_set, AES256_64_1, "VSMC_AES256_64_1_RS");
    VSMC_DO_ENG(do_set, AES256_32_2, "VSMC_AES256_32_2_RS");
    VSMC_DO_ENG(do_set, AES256_64_2, "VSMC_AES256_64_2_RS");
    VSMC_DO_ENG(do_set, AES256_32_4, "VSMC_AES256_32_4_RS");
    VSMC_DO_ENG(do_set, AES256_64_4, "VSMC_AES256_64_4_RS");
    VSMC_DO_ENG(do_set, AES256_32_8, "VSMC_AES256_32_8_RS");
    VSMC_DO_ENG(do_set, AES256_64_8, "VSMC_AES256_64_8_RS");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, AES256_32_1, "VSMC_AES256_32_1_MT");
    VSMC_DO_ENG(do_tbb, AES256_64_1, "VSMC_AES256_64_1_MT");
    VSMC_DO_ENG(do_tbb, AES256_32_2, "VSMC_AES256_32_2_MT");
    VSMC_DO_ENG(do_tbb, AES256_64_2, "VSMC_AES256_64_2_MT");
    VSMC_DO_ENG(do_tbb, AES256_32_4, "VSMC_AES256_32_4_MT");
    VSMC_DO_ENG(do_tbb, AES256_64_4, "VSMC_AES256_64_4_MT");
    VSMC_DO_ENG(do_tbb, AES256_32_8, "VSMC_AES256_32_8_MT");
    VSMC_DO_ENG(do_tbb, AES256_64_8, "VSMC_AES256_64_8_MT");
#endif

#if VSMC_USE_RANDOM123
    VSMC_DO_ENG(do_eng, r123::Engine<r123::AESNI4x32>, "R123_AESNI4x32");
    VSMC_DO_ENG(do_set, r123::Engine<r123::AESNI4x32>, "R123_AESNI4x32_RS");
#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, r123::Engine<r123::AESNI4x32>, "R123_AESNI4x32_MT");
#endif
#endif
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_AES_HPP
