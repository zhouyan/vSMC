#ifndef VSMC_EXAMPLE_RNG_MKL_HPP
#define VSMC_EXAMPLE_RNG_MKL_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/mkl_rng.hpp>

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    VSMC_DO_ENG(do_eng, vsmc::MKL_MCG59,        "MKL_MCG59");
    VSMC_DO_ENG(do_eng, vsmc::MKL_MT19937,      "MKL_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::MKL_MT19937_64,   "MKL_MT19937_64");
    VSMC_DO_ENG(do_eng, vsmc::MKL_MT2203,       "MKL_MT2203");
    VSMC_DO_ENG(do_eng, vsmc::MKL_MT2203_64,    "MKL_MT2203_64");
    VSMC_DO_ENG(do_eng, vsmc::MKL_SFMT19937_64, "MKL_SFMT19937_64");

#if VSMC_USE_RD_RAND
    VSMC_DO_ENG(do_eng, vsmc::MKL_NONDETERM,    "MKL_NONDETERM");
    VSMC_DO_ENG(do_eng, vsmc::MKL_NONDETERM_64, "MKL_NONDETERM_64");
#endif
}

template <typename Dist>
inline Dist get_dist () {return Dist();}

template <>
inline vsmc::MKLBinomialDistribution<> get_dist ()
{return vsmc::MKLBinomialDistribution<>(100);}

template <>
inline vsmc::MKLHypergeometricDistribution<> get_dist ()
{return vsmc::MKLHypergeometricDistribution<>(1000, 100, 500);}

template <>
inline vsmc::MKLNegBinomialDistribution<> get_dist ()
{return vsmc::MKLNegBinomialDistribution<>(100);}

template <typename Dist>
inline void do_dist_seq (std::size_t N, const std::string &name,
        std::vector<std::string> &enames,
        std::vector<vsmc::StopWatch> &sw)
{
    static std::vector<typename Dist::result_type> output(N);
    static typename Dist::result_type *const output_ptr = &output[0];
    static vsmc::MKLStream<VSL_BRNG_MT19937> stream;
    static Dist dist(get_dist<Dist>());
    vsmc::StopWatch watch;

    watch.start();
    for (std::size_t i = 0; i != N; ++i)
        output_ptr[i] = dist(stream);
    watch.stop();

    enames.push_back("SEQ: " + name);
    sw.push_back(watch);
}

template <typename Dist>
inline void do_dist_vec (std::size_t N, const std::string &name,
        std::vector<std::string> &enames,
        std::vector<vsmc::StopWatch> &sw)
{
    static std::vector<typename Dist::result_type> output(N);
    static typename Dist::result_type *const output_ptr = &output[0];
    static vsmc::MKLStream<VSL_BRNG_MT19937> stream;
    static Dist dist(get_dist<Dist>());
    vsmc::StopWatch watch;

    watch.start();
    dist(stream, static_cast<MKL_INT>(N), output_ptr);
    watch.stop();

    enames.push_back("VEC: " + name);
    sw.push_back(watch);
}

template <typename Dist>
inline void do_dist (std::size_t N, const std::string &name,
        std::vector<std::string> &enames,
        std::vector<vsmc::StopWatch> &sw)
{
    do_dist_seq<Dist>(N, name, enames, sw);
    do_dist_vec<Dist>(N, name, enames, sw);
}

inline void do_dist (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<vsmc::StopWatch> &sw)
{
    do_dist<vsmc::MKLUniformDistribution<float> >(
            N, "MKLUniformDistribution<float>", enames, sw);
    do_dist<vsmc::MKLUniformDistribution<double> >(
            N, "MKLUniformDistribution<double>", enames, sw);
    do_dist<vsmc::MKLUniformDistribution<MKL_INT> >(
            N, "MKLUniformDistribution<MKL_INT>", enames, sw);
    do_dist<vsmc::MKLBernoulliDistribution<> >(
            N, "MKL_Bernoulli", enames, sw);
    do_dist<vsmc::MKLGeometricDistribution<> >(
            N, "MKL_Geometric", enames, sw);
    do_dist<vsmc::MKLBinomialDistribution<> >(
            N, "MKL_Binomial", enames, sw);
    do_dist<vsmc::MKLHypergeometricDistribution<> >(
            N, "MKL_Hypergeometric", enames, sw);
    do_dist<vsmc::MKLPoissonDistribution<> >(
            N, "MKL_Poisson", enames, sw);
    do_dist<vsmc::MKLNegBinomialDistribution<> >(
            N, "MKL_NegBinomial", enames, sw);
    do_dist<vsmc::MKLGaussianDistribution<float> >(
            N, "MKLGaussianDistribution<float>", enames, sw);
    do_dist<vsmc::MKLGaussianDistribution<double> >(
            N, "MKLGaussianDistribution<double>", enames, sw);
    do_dist<vsmc::MKLExponentialDistribution<float> >(
            N, "MKLExponentialDistribution<float>", enames, sw);
    do_dist<vsmc::MKLExponentialDistribution<double> >(
            N, "MKLExponentialDistribution<double>", enames, sw);
    do_dist<vsmc::MKLLaplaceDistribution<float> >(
            N, "MKLLaplaceDistribution<float>", enames, sw);
    do_dist<vsmc::MKLLaplaceDistribution<double> >(
            N, "MKLLaplaceDistribution<double>", enames, sw);
    do_dist<vsmc::MKLWeibullDistribution<float> >(
            N, "MKLWeibullDistribution<float>", enames, sw);
    do_dist<vsmc::MKLWeibullDistribution<double> >(
            N, "MKLWeibullDistribution<double>", enames, sw);
    do_dist<vsmc::MKLCauchyDistribution<float> >(
            N, "MKLCauchyDistribution<float>", enames, sw);
    do_dist<vsmc::MKLCauchyDistribution<double> >(
            N, "MKLCauchyDistribution<double>", enames, sw);
    do_dist<vsmc::MKLRayleighDistribution<float> >(
            N, "MKLRayleighDistribution<float>", enames, sw);
    do_dist<vsmc::MKLRayleighDistribution<double> >(
            N, "MKLRayleighDistribution<double>", enames, sw);
    do_dist<vsmc::MKLLognormalDistribution<float> >(
            N, "MKLLognormalDistribution<float>", enames, sw);
    do_dist<vsmc::MKLLognormalDistribution<double> >(
            N, "MKLLognormalDistribution<double>", enames, sw);
    do_dist<vsmc::MKLGumbelDistribution<float> >(
            N, "MKLGumbelDistribution<float>", enames, sw);
    do_dist<vsmc::MKLGumbelDistribution<double> >(
            N, "MKLGumbelDistribution<double>", enames, sw);
    do_dist<vsmc::MKLGammaDistribution<float> >(
            N, "MKLGammaDistribution<float>", enames, sw);
    do_dist<vsmc::MKLGammaDistribution<double> >(
            N, "MKLGammaDistribution<double>", enames, sw);
    do_dist<vsmc::MKLBetaDistribution<float> >(
            N, "MKLBetaDistribution<float>", enames, sw);
    do_dist<vsmc::MKLBetaDistribution<double> >(
            N, "MKLBetaDistribution<double>", enames, sw);
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

inline void do_dist_test (std::size_t N)
{
    std::vector<std::string> enames;
    std::vector<vsmc::StopWatch> sw;
    do_dist(N, enames, sw);
    std::vector<std::size_t> bytes(sw.size(), 0);
    do_output_sw("MKL Distributions", enames, sw, bytes);
}

#endif // VSMC_EXAMPLE_RNG_MKL_HPP
