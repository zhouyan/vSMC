#ifndef VSMC_EXAMPLE_RNG_RD_RAND_HPP
#define VSMC_EXAMPLE_RNG_RD_RAND_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/rd_rand.hpp>

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    VSMC_DO_ENG(do_eng, vsmc::RdRand16,    "VSMC_RD_RAND16");
    VSMC_DO_ENG(do_eng, vsmc::RdRand32,    "VSMC_RD_RAND32");
    VSMC_DO_ENG(do_eng, vsmc::RdRand64,    "VSMC_RD_RAND64");

    VSMC_DO_ENG(do_set, vsmc::RdRand16,    "VSMC_RD_RAND16 (RS)");
    VSMC_DO_ENG(do_set, vsmc::RdRand32,    "VSMC_RD_RAND32 (RS)");
    VSMC_DO_ENG(do_set, vsmc::RdRand64,    "VSMC_RD_RAND64 (RS)");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, vsmc::RdRand16,    "VSMC_RD_RAND16 (MT)");
    VSMC_DO_ENG(do_tbb, vsmc::RdRand32,    "VSMC_RD_RAND32 (MT)");
    VSMC_DO_ENG(do_tbb, vsmc::RdRand64,    "VSMC_RD_RAND64 (MT)");
#endif
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_RD_RAND_HPP
