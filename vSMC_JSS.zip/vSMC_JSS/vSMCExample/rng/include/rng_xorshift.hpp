#ifndef VSMC_EXAMPLE_RNG_XORSHIFT_HPP
#define VSMC_EXAMPLE_RNG_XORSHIFT_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/xorshift.hpp>

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    VSMC_DO_ENG(do_eng, vsmc::Xorshift1x32,   "VSMC_XORSHIFT1x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift2x32,   "VSMC_XORSHIFT2x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift4x32,   "VSMC_XORSHIFT4x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift8x32,   "VSMC_XORSHIFT8x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift16x32,  "VSMC_XORSHIFT16x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift32x32,  "VSMC_XORSHIFT32x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift64x32,  "VSMC_XORSHIFT64x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift128x32, "VSMC_XORSHIFT128x32");

    VSMC_DO_ENG(do_eng, vsmc::Xorshift1x64,  "VSMC_XORSHIFT1x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift2x64,  "VSMC_XORSHIFT2x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift4x64,  "VSMC_XORSHIFT4x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift8x64,  "VSMC_XORSHIFT8x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift16x64, "VSMC_XORSHIFT16x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift32x64, "VSMC_XORSHIFT32x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorshift64x64, "VSMC_XORSHIFT64x64");

    VSMC_DO_ENG(do_eng, vsmc::Xorwow1x32,   "VSMC_XORWOW1x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow2x32,   "VSMC_XORWOW2x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow4x32,   "VSMC_XORWOW4x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow8x32,   "VSMC_XORWOW8x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow16x32,  "VSMC_XORWOW16x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow32x32,  "VSMC_XORWOW32x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow64x32,  "VSMC_XORWOW64x32");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow128x32, "VSMC_XORWOW128x32");

    VSMC_DO_ENG(do_eng, vsmc::Xorwow1x64,  "VSMC_XORWOW1x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow2x64,  "VSMC_XORWOW2x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow4x64,  "VSMC_XORWOW4x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow8x64,  "VSMC_XORWOW8x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow16x64, "VSMC_XORWOW16x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow32x64, "VSMC_XORWOW32x64");
    VSMC_DO_ENG(do_eng, vsmc::Xorwow64x64, "VSMC_XORWOW64x64");
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_XORSHIFT_HPP
