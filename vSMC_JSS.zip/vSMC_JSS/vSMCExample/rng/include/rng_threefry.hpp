#ifndef VSMC_EXAMPLE_RNG_THREEFRY_HPP
#define VSMC_EXAMPLE_RNG_THREEFRY_HPP

#include "rng_eng.hpp"
#include <vsmc/rng/threefry.hpp>

#if VSMC_USE_RANDOM123
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable:4521)
#endif
#include <Random123/threefry.h>
#include <Random123/conventional/Engine.hpp>
#ifdef _MSC_VER
#pragma warning(pop)
#endif
#endif // VSMC_USE_RANDOM123

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    VSMC_DO_ENG(do_eng, vsmc::Threefry2x32, "VSMC_Threefry2x32");
    VSMC_DO_ENG(do_eng, vsmc::Threefry4x32, "VSMC_Threefry4x32");
    VSMC_DO_ENG(do_eng, vsmc::Threefry2x64, "VSMC_Threefry2x64");
    VSMC_DO_ENG(do_eng, vsmc::Threefry4x64, "VSMC_Threefry4x64");

    VSMC_DO_ENG(do_set, vsmc::Threefry2x32, "VSMC_Threefry2x32_RS");
    VSMC_DO_ENG(do_set, vsmc::Threefry4x32, "VSMC_Threefry4x32_RS");
    VSMC_DO_ENG(do_set, vsmc::Threefry2x64, "VSMC_Threefry2x64_RS");
    VSMC_DO_ENG(do_set, vsmc::Threefry4x64, "VSMC_Threefry4x64_RS");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, vsmc::Threefry2x32, "VSMC_Threefry2x32_MT");
    VSMC_DO_ENG(do_tbb, vsmc::Threefry4x32, "VSMC_Threefry4x32_MT");
    VSMC_DO_ENG(do_tbb, vsmc::Threefry2x64, "VSMC_Threefry2x64_MT");
    VSMC_DO_ENG(do_tbb, vsmc::Threefry4x64, "VSMC_Threefry4x64_MT");
#endif

#if VSMC_USE_RANDOM123
    VSMC_DO_ENG(do_eng, r123::Engine<r123::Threefry2x32>, "R123_Threefry2x32");
    VSMC_DO_ENG(do_eng, r123::Engine<r123::Threefry4x32>, "R123_Threefry4x32");
    VSMC_DO_ENG(do_eng, r123::Engine<r123::Threefry2x64>, "R123_Threefry2x64");
    VSMC_DO_ENG(do_eng, r123::Engine<r123::Threefry4x64>, "R123_Threefry4x64");

    VSMC_DO_ENG(do_set, r123::Engine<r123::Threefry2x32>, "R123_Threefry2x32_RS");
    VSMC_DO_ENG(do_set, r123::Engine<r123::Threefry4x32>, "R123_Threefry4x32_RS");
    VSMC_DO_ENG(do_set, r123::Engine<r123::Threefry2x64>, "R123_Threefry2x64_RS");
    VSMC_DO_ENG(do_set, r123::Engine<r123::Threefry4x64>, "R123_Threefry4x64_RS");

#if VSMC_USE_TBB
    VSMC_DO_ENG(do_tbb, r123::Engine<r123::Threefry2x32>, "R123_Threefry2x32_MT");
    VSMC_DO_ENG(do_tbb, r123::Engine<r123::Threefry4x32>, "R123_Threefry4x32_MT");
    VSMC_DO_ENG(do_tbb, r123::Engine<r123::Threefry2x64>, "R123_Threefry2x64_MT");
    VSMC_DO_ENG(do_tbb, r123::Engine<r123::Threefry4x64>, "R123_Threefry4x64_MT");
#endif
#endif
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_THREEFRY_HPP
