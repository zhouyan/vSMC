#ifndef VSMC_EXAMPLE_RNG_U01_HPP
#define VSMC_EXAMPLE_RNG_U01_HPP

#include <vsmc/rng/uniform_real_distribution.hpp>

#include "rng_eng.hpp"

#define VSMC_DO_U01(eng, ubits, fp_type, fbits, left, right) \
    do_u01<eng, fp_type, vsmc::left, vsmc::right>(N,                         \
            "u01_" #eng "_" #left "_" #right "_" #ubits "_" #fbits,          \
            enames, values, sw, bytes);

template <typename Eng, typename FPType, typename Left, typename Right>
inline void do_u01(std::size_t N, const std::string &name,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    Eng eng;
    vsmc::UniformRealDistribution<FPType, Left, Right> runif(0, 1);
    static std::vector<double> output(N);
    static double *const output_ptr = &output[0];
    vsmc::StopWatch watch;

    watch.start();
    for (std::size_t i = 0; i != N; ++i)
        output_ptr[i] = runif(eng);
    watch.stop();

    enames.push_back(name);
    values.push_back(output);
    sw.push_back(watch);
    bytes.push_back(N * sizeof(typename Eng::result_type));
}

inline void do_u01 (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    typedef vsmc::cxx11::mersenne_twister_engine<uint32_t, 32, 624, 397, 31,
            0x9908b0df, 11,
            0xffffffff, 7,
            0x9d2c5680, 15,
            0xefc60000, 18, 1812433253> mt32;

    typedef vsmc::cxx11::mersenne_twister_engine<uint64_t, 64, 312, 156, 31,
            0xb5026f5aa96619e9, 29,
            0x5555555555555555, 17,
            0x71d67fffeda60000, 37,
            0xfff7eee000000000, 43, 6364136223846793005> mt64;

    using vsmc::cxx11::mt19937;
    using vsmc::cxx11::mt19937_64;

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,    "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64, "STD_MT19937_64");

    VSMC_DO_U01(mt32, 32, float, 24, Open,   Open);
    VSMC_DO_U01(mt32, 32, float, 24, Open,   Closed);
    VSMC_DO_U01(mt32, 32, float, 24, Closed, Open);
    VSMC_DO_U01(mt32, 32, float, 24, Closed, Closed);

    VSMC_DO_U01(mt64, 32, double, 53, Open,   Open);
    VSMC_DO_U01(mt64, 32, double, 53, Open,   Closed);
    VSMC_DO_U01(mt64, 32, double, 53, Closed, Open);
    VSMC_DO_U01(mt64, 32, double, 53, Closed, Closed);

    VSMC_DO_U01(mt64, 64, double, 53, Open,   Open);
    VSMC_DO_U01(mt64, 64, double, 53, Open,   Closed);
    VSMC_DO_U01(mt64, 64, double, 53, Closed, Open);
    VSMC_DO_U01(mt64, 64, double, 53, Closed, Closed);

    VSMC_DO_U01(mt19937, uint, double, 53, Open,   Open);
    VSMC_DO_U01(mt19937, uint, double, 53, Open,   Closed);
    VSMC_DO_U01(mt19937, uint, double, 53, Closed, Open);
    VSMC_DO_U01(mt19937, uint, double, 53, Closed, Closed);

    VSMC_DO_U01(mt19937_64, uint, double, 53, Open,   Open);
    VSMC_DO_U01(mt19937_64, uint, double, 53, Open,   Closed);
    VSMC_DO_U01(mt19937_64, uint, double, 53, Closed, Open);
    VSMC_DO_U01(mt19937_64, uint, double, 53, Closed, Closed);
}

inline void do_test (std::size_t N, const std::string &basename)
{
    vsmc::UniformRealDistribution<double, vsmc::Open, vsmc::Open> runif1(0, 1);
    vsmc::UniformRealDistribution<double, vsmc::Open, vsmc::Open> runif2(0, 2);
    vsmc::UniformRealDistribution<double, vsmc::Open, vsmc::Open> runif3(0, 1);

    vsmc::UniformRealDistribution<double, vsmc::Open, vsmc::Open>::param_type
        param1;

    std::ofstream output;
    output.open("rng_u01.out");
    output << runif1 << std::endl;
    output << runif1.param() << std::endl;
    output.close();
    output.clear();

    std::ifstream input;
    input.open("rng_u01.out");
    input >> runif1;
    assert(runif1 == runif3);
    input >> param1;
    runif1.param(param1);
    assert(runif1.param() == runif3.param());

    assert(runif1 != runif2);
    assert(runif1.param() != runif2.param());

    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_u01(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_U01_HPP
