#ifndef VSMC_EXAMPLE_RNG_OPENCL_HPP
#define VSMC_EXAMPLE_RNG_OPENCL_HPP

#include <vsmc/cxx11/random.hpp>
#include <vsmc/opencl/cl_manager.hpp>
#include <vsmc/opencl/cl_manip.hpp>
#include <vsmc/utility/stop_watch.hpp>
#include <iomanip>
#include <iostream>
#include <sstream>

#if VSMC_USE_HDF5
#include "rng_output_data_hdf5.hpp"
#else
#include "rng_output_data.hpp"
#endif

struct rng_device;

inline void set_kernel_vec (const std::string &kbase, cl::Program &program,
        std::vector<cl::Kernel> &kernel_vec, bool clear_first = true)
{
    if (clear_first) kernel_vec.clear();
    std::string kernel_name_2x32(kbase + "_2x32_ker");
    std::string kernel_name_4x32(kbase + "_4x32_ker");
    kernel_vec.push_back(cl::Kernel(program, kernel_name_2x32.c_str()));
    kernel_vec.push_back(cl::Kernel(program, kernel_name_4x32.c_str()));
}

inline void print_char (char a, std::size_t n = 120)
{
    for (std::size_t i = 0; i != n; ++i)
        std::cout << a;
    std::cout << std::endl;
}

template <typename FP, typename DistType, typename RNG>
inline vsmc::StopWatch do_cpp (std::size_t N, DistType &dist, RNG &rng,
        std::vector<FP> &output_host)
{
    vsmc::StopWatch watch_rng;
    watch_rng.start();
    for (std::size_t i = 0; i != N; ++i)
        output_host[i] = dist(rng);
    watch_rng.stop();
    std::cout << std::right << std::fixed << std::setw(20)
        << watch_rng.milliseconds();

    return watch_rng;
}

template <typename FP>
inline std::pair<vsmc::StopWatch, vsmc::StopWatch> do_ocl (std::size_t N,
        std::vector<cl::Kernel> &kernel_vec,
        cl::Buffer &output_dev, std::vector<FP> &output_host, double tcpp)
{
    vsmc::CLManager<rng_device> &manager =
        vsmc::CLManager<rng_device>::instance();

    std::size_t offset = N;
    vsmc::StopWatch watch_rng;
    vsmc::StopWatch watch_dat;
    for (std::size_t i = 0; i != kernel_vec.size(); ++i, offset += N) {
        std::size_t global_size, local_size;
        vsmc::cl_preferred_work_size(N, kernel_vec[i], manager.device(),
                global_size, local_size);
        vsmc::cl_set_kernel_args(kernel_vec[i], 0, static_cast<cl_ulong>(N),
                output_dev);

        // Run kernel once to cache
        watch_rng.start();
        manager.run_kernel(kernel_vec[i], N, local_size);
        vsmc::StopWatch watch;
        watch.start();
        manager.run_kernel(kernel_vec[i], N, local_size);
        watch.stop();
        watch_rng.stop();

        watch_dat.start();
        manager.read_buffer<FP>(output_dev, N, &output_host[offset]);
        watch_dat.stop();

        double tocl = watch.milliseconds();
        std::cout << std::right << std::fixed << std::setw(20) << tocl;
        std::cout << std::right << std::fixed << std::setw(20) << tcpp / tocl;
    }

    return std::make_pair(watch_rng, watch_dat);
}

template <typename FP, typename DistType, typename RNG>
inline std::pair<vsmc::StopWatch, vsmc::StopWatch> do_dist (std::size_t N,
        std::vector<cl::Kernel> &kernel_vec,
        const std::string &dname, DistType &dist, RNG &rng,
        cl::Buffer &output_dev, std::vector<FP> &output_host)
{
    std::cout << std::left << std::setw(20) << dname;
    vsmc::StopWatch tcpp = do_cpp(N, dist, rng, output_host);
    std::pair<vsmc::StopWatch, vsmc::StopWatch> tocl =
        do_ocl(N, kernel_vec, output_dev, output_host, tcpp.milliseconds());
    std::cout << std::endl;

    vsmc::StopWatch watch_rng = tcpp + tocl.first;
    vsmc::StopWatch watch_dat = tocl.second;

    return std::make_pair(watch_rng, watch_dat);
}

template <typename FP>
inline void do_rng (std::size_t N, cl::Program &program,
        std::vector<std::string> &dnames,
        std::vector<std::string> &unames,
        std::vector<std::string> &rcodes,
        std::vector<std::vector<FP> > &values,
        std::vector<std::vector<cl_uint> > &values_ui)
{
    vsmc::CLManager<rng_device> &manager =
        vsmc::CLManager<rng_device>::instance();

    vsmc::StopWatch watch_rng;
    vsmc::StopWatch watch_dat;
    std::pair<vsmc::StopWatch, vsmc::StopWatch> watch_pair;

    vsmc::cxx11::mt19937 rng;
    std::vector<cl::Kernel> kernel_vec;

    watch_dat.start();
    cl::Buffer output_dev      = manager.create_buffer<FP>(N);
    cl::Buffer output_ui_0_dev = manager.create_buffer<cl_uint>(N);
    cl::Buffer output_ui_1_dev = manager.create_buffer<cl_uint>(N);
    cl::Buffer output_ui_2_dev = manager.create_buffer<cl_uint>(N);
    cl::Buffer output_ui_3_dev = manager.create_buffer<cl_uint>(N);
    std::vector<FP>      output_host(3 * N);
    std::vector<cl_uint> output_ui_0_host(N);
    std::vector<cl_uint> output_ui_1_host(N);
    std::vector<cl_uint> output_ui_2_host(N);
    std::vector<cl_uint> output_ui_3_host(N);
    watch_dat.stop();

    dnames.clear();
    unames.clear();
    rcodes.clear();
    values.clear();
    values_ui.clear();

    // Test R123
    print_char('=');
    std::cout << std::left  << std::setw(20) << "Engines";
    std::cout << std::right << std::setw(20) << "Time (ms)";
    std::cout << std::endl;
    print_char('-');

    std::vector<std::string> engines;
    std::vector<std::string> engnames;
    engines.push_back("threefry");
    engines.push_back("philox");
    engines.push_back("cburng_threefry");
    engines.push_back("cburng_philox");
    kernel_vec.clear();
    for (std::size_t i = 0; i != engines.size(); ++i) {
        set_kernel_vec(engines[i], program, kernel_vec, false);
        unames.push_back(engines[i] + ".2x32.v0");
        unames.push_back(engines[i] + ".2x32.v1");
        unames.push_back(engines[i] + ".2x32.v2");
        unames.push_back(engines[i] + ".2x32.v3");
        unames.push_back(engines[i] + ".4x32.v0");
        unames.push_back(engines[i] + ".4x32.v1");
        unames.push_back(engines[i] + ".4x32.v2");
        unames.push_back(engines[i] + ".4x32.v3");
        engnames.push_back(engines[i] + "2x32");
        engnames.push_back(engines[i] + "4x32");
    }
    for (std::size_t i = 0; i != kernel_vec.size(); ++i) {
        std::size_t global_size = 0;
        std::size_t local_size = 0;
        vsmc::cl_preferred_work_size(N, kernel_vec[i], manager.device(),
                global_size, local_size);
        vsmc::cl_set_kernel_args(kernel_vec[i], 0, static_cast<cl_ulong>(N),
                output_ui_0_dev, output_ui_1_dev,
                output_ui_2_dev, output_ui_3_dev);

        // Run kernel once first to cache
        watch_rng.start();
        manager.run_kernel(kernel_vec[i], N, local_size);
        vsmc::StopWatch watch;
        watch.start();
        manager.run_kernel(kernel_vec[i], N, local_size);
        watch.stop();
        watch_rng.stop();

        std::cout << std::left << std::setw(20) << engnames[i];
        std::cout << std::right << std::fixed << std::setw(20);
        std::cout << watch.milliseconds() << std::endl;

        watch_dat.start();
        manager.read_buffer<cl_uint>(output_ui_0_dev, N, &output_ui_0_host[0]);
        manager.read_buffer<cl_uint>(output_ui_1_dev, N, &output_ui_1_host[0]);
        manager.read_buffer<cl_uint>(output_ui_2_dev, N, &output_ui_2_host[0]);
        manager.read_buffer<cl_uint>(output_ui_3_dev, N, &output_ui_3_host[0]);
        values_ui.push_back(output_ui_0_host);
        values_ui.push_back(output_ui_1_host);
        values_ui.push_back(output_ui_2_host);
        values_ui.push_back(output_ui_3_host);
        watch_dat.stop();
    }

    // Test distributions
    print_char('=');
    std::cout << std::left  << std::setw(20) << "Distribuiton";
    std::cout << std::right << std::setw(20) << "CPP MT19937 Time (ms)";
    std::cout << std::right << std::setw(20) << "OCL 2x32 Time (ms)";
    std::cout << std::right << std::setw(20) << "OCL 2x32 Speedup";
    std::cout << std::right << std::setw(20) << "OCL 4x32 Time (ms)";
    std::cout << std::right << std::setw(20) << "OCL 4x32 Speedup";
    std::cout << std::endl;
    print_char('-');

    // Test u01
    vsmc::cxx11::uniform_real_distribution<FP> runif(0, 1);
    dnames.push_back("u01");
    rcodes.push_back("runif(N)");
    set_kernel_vec("u01", program, kernel_vec);
    watch_pair = do_dist(N, kernel_vec, "u01", runif, rng,
            output_dev, output_host);
    watch_dat.start();
    values.push_back(output_host);
    watch_dat.stop();
    watch_rng += watch_pair.first;
    watch_dat += watch_pair.second;

    // Test normal01
    vsmc::cxx11::normal_distribution<FP> rnorm(0, 1);
    dnames.push_back("normal01");
    rcodes.push_back("rnorm(N)");
    set_kernel_vec("normal01", program, kernel_vec);
    watch_pair = do_dist(N, kernel_vec, "normal01", rnorm, rng,
            output_dev, output_host);
    watch_dat.start();
    values.push_back(output_host);
    watch_dat.stop();
    watch_rng += watch_pair.first;
    watch_dat += watch_pair.second;

    // Test gammak1
    std::vector<FP> gammak1_shape;
    gammak1_shape.push_back(static_cast<FP>(0.1));
    gammak1_shape.push_back(static_cast<FP>(0.5));
    gammak1_shape.push_back(static_cast<FP>(1.0));
    gammak1_shape.push_back(static_cast<FP>(1.5));
    gammak1_shape.push_back(static_cast<FP>(2.5));
    gammak1_shape.push_back(static_cast<FP>(3.5));
    gammak1_shape.push_back(static_cast<FP>(4.5));
    gammak1_shape.push_back(static_cast<FP>(10.));
    gammak1_shape.push_back(static_cast<FP>(15.));
    gammak1_shape.push_back(static_cast<FP>(30.));
    for (std::size_t i = 0; i != gammak1_shape.size(); ++i) {
        std::stringstream dname;
        dname << "gammak1_" << gammak1_shape[i];

        std::stringstream rcode;
        rcode << "rgamma(N, " << gammak1_shape[i] << ")";

        vsmc::cxx11::gamma_distribution<FP> rgamma(gammak1_shape[i], 1);
        dnames.push_back(dname.str());
        rcodes.push_back(rcode.str());
        set_kernel_vec("gammak1", program, kernel_vec);
        for (std::size_t k = 0; k != kernel_vec.size(); ++k)
            vsmc::cl_set_kernel_args(kernel_vec[k], 2, gammak1_shape[i]);
        watch_pair = do_dist(N, kernel_vec, dname.str(), rgamma, rng,
                output_dev, output_host);
        watch_dat.start();
        values.push_back(output_host);
        watch_dat.stop();
        watch_rng += watch_pair.first;
        watch_dat += watch_pair.second;
    }

    print_char('=');
    std::cout << std::left << std::setw(20) << "Done rng:" << std::fixed
        << watch_rng.seconds() << " sec" << std::endl;
    std::cout << std::left << std::setw(20) << "Done data:" << std::fixed
        << watch_dat.seconds() << " sec" << std::endl;
}

template <typename FP>
inline void do_output (std::size_t N,
        std::vector<std::string> &dnames,
        std::vector<std::string> &unames,
        std::vector<std::string> &rcodes,
        std::vector<std::vector<FP> > &values,
        std::vector<std::vector<cl_uint> > &values_ui)
{

    do_output_data("rng_cl", dnames, values);
    do_output_data("rng_cl_uint", unames, values_ui);

    std::size_t M = rcodes.size();
    if (M == 0)
        return;

    std::ofstream output_file("rng_cl_dt.R");
    output_file << "N <- " << N << '\n';
    output_file << "refoutput <- data.frame(\n";
    for (std::size_t j = 0; j != M; ++j) {
        output_file << dnames[j] << " = " << rcodes[j];
        output_file << (j == M - 1 ? ')' : ',') << '\n';
    }
    output_file.close();
    output_file.clear();
}

template <typename FT>
inline void do_test (std::size_t N, cl::Program &program)
{
    std::vector<std::string> dnames;
    std::vector<std::string> unames;
    std::vector<std::string> rcodes;
    std::vector<std::vector<FT> > values;
    std::vector<std::vector<cl_uint> > values_ui;
    vsmc::StopWatch watch;

    watch.reset();
    watch.start();
    do_rng<FT>(N, program, dnames, unames, rcodes, values, values_ui);
    watch.stop();
    std::cout << std::left << std::setw(20) << "Done test:" << std::fixed
        << watch.seconds() << " sec" << std::endl;

    watch.reset();
    watch.start();
    do_output<FT>(N, dnames, unames, rcodes, values, values_ui);
    watch.stop();
    std::cout << std::left << std::setw(20) << "Done output:" << std::fixed
        << watch.seconds() << " sec" << std::endl;
    print_char('=');
}

#endif // VSMC_EXAMPLE_RNG_OPENCL_HPP
