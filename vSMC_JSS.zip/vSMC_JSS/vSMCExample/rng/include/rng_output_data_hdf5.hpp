#ifndef VSMC_EXAMPLE_RNG_OUTPUT_DATA_HDF5_HPP
#define VSMC_EXAMPLE_RNG_OUTPUT_DATA_HDF5_HPP

#include <vsmc/utility/hdf5io.hpp>
#include <fstream>

template <typename T>
inline void do_output_data (const std::string &base_name,
        const std::vector<std::string> &vnames,
        const std::vector<std::vector<T> > &values)
{
    if (vnames.size() != values.size())
        return;

    if (vnames.size() == 0)
        return;

    if (values[0].size() == 0)
        return;

    std::size_t M = vnames.size();
    std::size_t N = values[0].size();
    std::vector<const T *> vptr(M);
    for (std::size_t j = 0; j != M; ++j)
        vptr[j] = &values[j][0];
    vsmc::hdf5store_data_frame<T>(N, M, (base_name + ".hdf5"), base_name,
            vptr.begin(), vnames.begin());
}

#endif // VSMC_EXAMPLE_RNG_OUTPUT_DATA_HDF5_HPP
