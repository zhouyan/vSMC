#ifndef VSMC_EXAMPLE_RNG_STD_HPP
#define VSMC_EXAMPLE_RNG_STD_HPP

#include "rng_eng.hpp"

inline void do_rng (std::size_t N,
        std::vector<std::string> &enames,
        std::vector<std::vector<double> > &values,
        std::vector<vsmc::StopWatch> &sw,
        std::vector<std::size_t> &bytes)
{
    enames.clear();
    values.clear();
    sw.clear();
    bytes.clear();

    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937,       "STD_MT19937");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::mt19937_64,    "STD_MT19937_64");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::minstd_rand0,  "STD_MINSTD_RAND0");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::minstd_rand,   "STD_MINSTD_RAND");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::ranlux24_base, "STD_RANLUX24_BASE");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::ranlux48_base, "STD_RANLUX48_BASE");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::ranlux24,      "STD_RANLUX24");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::ranlux48,      "STD_RANLUX48");
    VSMC_DO_ENG(do_eng, vsmc::cxx11::knuth_b,       "STD_KNUTH_B");
}

inline void do_test (std::size_t N, const std::string &basename)
{
    std::vector<std::string> enames;
    std::vector<std::vector<double> > values;
    std::vector<vsmc::StopWatch> sw;
    std::vector<std::size_t> bytes;
    do_rng(N, enames, values, sw, bytes);
    do_output_sw("Engine (" + basename + ")", enames, sw, bytes);
    do_output_data(basename, enames, values);
}

#endif // VSMC_EXAMPLE_RNG_STD_HPP
