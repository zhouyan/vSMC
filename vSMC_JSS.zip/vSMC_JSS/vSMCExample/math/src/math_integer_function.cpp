#include <vsmc/math/integer_function.hpp>

int main ()
{
    VSMC_STATIC_ASSERT(
            (vsmc::math::Factorial<0>::value == 1ULL), FACTORIAL_0);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Factorial<1>::value == 1ULL), FACTORIAL_5);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Factorial<5>::value == 120ULL), FACTORIAL_5);

    VSMC_STATIC_ASSERT(
            (vsmc::math::IsPowerOf<0, 0>::value), IS_POWER_OF_0_0);

    VSMC_STATIC_ASSERT(
            (vsmc::math::IsPowerOf<1, 0>::value), IS_POWER_OF_1_0);

    VSMC_STATIC_ASSERT(
            (!vsmc::math::IsPowerOf<2, 0>::value), IS_POWER_OF_2_0);

    VSMC_STATIC_ASSERT(
            (vsmc::math::IsPowerOf<2, 2>::value), IS_POWER_OF_2_2);

    VSMC_STATIC_ASSERT(
            (vsmc::math::IsPowerOf<5, 5>::value), IS_POWER_OF_5_5);

    VSMC_STATIC_ASSERT(
            (!vsmc::math::IsPowerOf<0, 5>::value), IS_POWER_OF_0_5);

    VSMC_STATIC_ASSERT(
            (vsmc::math::IsPowerOf<8, 2>::value), IS_POWER_OF_8_2);

    VSMC_STATIC_ASSERT(
            (vsmc::math::IsPowerOf<9, 3>::value), IS_POWER_OF_9_3);

    VSMC_STATIC_ASSERT(
            (!vsmc::math::IsPowerOf<9, 2>::value), IS_POWER_OF_9_2);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Power<0, 0>::value == 1), POWER_0_0);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Power<0, 1>::value == 0), POWER_0_1);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Power<2, 0>::value == 1), POWER_2_2);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Power<2, 3>::value == 8), POWER_5_5);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Fibonacci<1>::value == 0), FIBONACCI_1);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Fibonacci<2>::value == 1), FIBONACCI_2);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Fibonacci<3>::value == 1), FIBONACCI_3);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Fibonacci<4>::value == 2), FIBONACCI_4);

    VSMC_STATIC_ASSERT(
            (vsmc::math::Fibonacci<12>::value == 89), FIBONACCI_12);

    return 0;
}
