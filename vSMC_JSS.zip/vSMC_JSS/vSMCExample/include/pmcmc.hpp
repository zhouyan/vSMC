#ifndef VSMC_EXAMPLE_PMCMC_HPP
#define VSMC_EXAMPLE_PMCMC_HPP

static std::size_t ChainNum;
static std::size_t BurninNum;
static std::size_t IterNum;
static std::size_t LinearIterNum;
static std::size_t Prior2IterNum;
static std::size_t Prior5IterNum;
static std::size_t Posterior2IterNum;
static std::size_t Posterior5IterNum;
static bool Parallel;

#include "move_alpha.hpp"
#include "move_pmcmc.hpp"
#include "pmcmc_do.hpp"

#endif // VSMC_EXAMPLE_PMCMC_HPP
