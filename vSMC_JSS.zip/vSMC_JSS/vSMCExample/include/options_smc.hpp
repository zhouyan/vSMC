Config
.add("threshold",       "Threshold for resampling",     &Threshold,   0.5)
.add("particle_num",   "Particle number",               &ParticleNum, 1000)
.add("proposal_scale", "Proposal: 1: Default; 2: Adaptive", &ProposalScale, 1)
.add("mh_alpha",       "MH schedule (alph == 1)",       &MHAlpha)
.add("mh_iter",        "MH iteration number",           &MHIterNum)
.add("ess",            "Enable ESS adaptive schedule",  &ESSDrop)
.add("cess",           "Enable CESS adaptive schedule", &CESSDrop)
.add("linear",         "Enbale linear schedule",        &LinearIterNum)
.add("prior2",         "Enbale prior2 schedule",        &Prior2IterNum)
.add("prior5",         "Enbale prior5 schedule",        &Prior5IterNum)
.add("posterior2",     "Enbale posterior2 schedule",    &Posterior2IterNum)
.add("posterior5",     "Enbale posterior5 schedule",    &Posterior5IterNum);
