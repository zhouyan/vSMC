#ifndef VSMC_EXAMPLE_SMC_HPP
#define VSMC_EXAMPLE_SMC_HPP

static std::size_t ParticleNum;
static double Threshold;
static std::vector<double> MHAlpha;
static std::vector<std::size_t> MHIterNum;
static std::vector<double> ESSDrop;
static std::vector<double> CESSDrop;
static std::vector<std::size_t> LinearIterNum;
static std::vector<std::size_t> Prior2IterNum;
static std::vector<std::size_t> Prior5IterNum;
static std::vector<std::size_t> Posterior2IterNum;
static std::vector<std::size_t> Posterior5IterNum;


#include "move_alpha.hpp"
#include "move_smc.hpp"
#include "smc_path.hpp"
#include "smc_do.hpp"

#endif // VSMC_EXAMPLE_SMC_HPP
