#define VSMC_PAPER_MPI

#include "paper_gmm_@smp@.cpp"
