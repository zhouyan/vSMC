#ifndef VSMC_EXAMPLE_PAPER_HPP
#define VSMC_EXAMPLE_PAPER_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@
#define BASE_PATH    vsmc::PathEval@SMP@

#include <vsmc/core/sampler.hpp>
#include <vsmc/core/state_matrix.hpp>
#include <vsmc/smp/adapter.hpp>
#include <vsmc/smp/backend_@smp@.hpp>
#include <vsmc/math/constants.hpp>
#include <fstream>

#endif // VSMC_EXAMPLE_PAPER_HPP
