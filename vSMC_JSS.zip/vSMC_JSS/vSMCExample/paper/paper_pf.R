suppressPackageStartupMessages(library(ggplot2))

pf.data <- read.table("paper_pf.data", header = FALSE)
pf.est <- read.table("paper_pf.est", header = TRUE)
pf.plot.data <- data.frame(
    x = c(pf.est$pos.1, pf.data$V1),
    y = c(pf.est$pos.2, pf.data$V2),
    Data = ordered(c(rep("Estimates", 100), rep("Observations", 100)),
        levels = c("Estimates", "Observations")))
pf.plot <- ggplot(pf.plot.data) + aes(x = x, y = y, group = Data,
    color = Data, linetype = Data) + geom_line() + geom_point() +
    xlab("X position") + ylab("Y position") + theme_bw()

pdf("pf.pdf", width = 8, height = 5)
print(pf.plot)
GC <- dev.off()
