#ifndef VSMC_EXAMPLE_GMM_HPP
#define VSMC_EXAMPLE_GMM_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@
#define BASE_PATH    vsmc::PathEval@SMP@

#include <vsmc/smp/backend_@smp@.hpp>
#include <vsmc/cxx11/cmath.hpp>

static const std::size_t InitCompNum = 4;
static const std::size_t MinCompNum = 1;
static const std::size_t MaxCompNum = 10;

static std::string DataFile;
static std::size_t DataNum;
static std::size_t SM;
static std::size_t CM;

#include "common.hpp"
#include "gmm_param.hpp"
#include "gmm_state.hpp"
#include "gmm_init.hpp"
#include "gmm_move.hpp"
#include "gmm_monitor.hpp"
#include "gmm_proposal.hpp"

#endif // VSMC_EXAMPLE_GMM_HPP
