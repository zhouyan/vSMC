std::string vSMCIncPath;
std::string R123IncPath;
std::string PlatformName;
std::string DeviceType;
std::string DeviceVendorName;
std::size_t FPTypeBits;
std::size_t ParticleNum;
double Threshold;
std::size_t IterNum;
std::string DataFile;
std::size_t DataNum;
std::size_t SM;
std::size_t CM;
Config
.add("particle_num",  "Particle number",    &ParticleNum, 1000)
.add("iter_num",      "Iteration number",   &IterNum,     100)
.add("prior2",        "Alias to iter_num",  &IterNum,     100)
.add("data_num",      "Number of data",     &DataNum,     100)
.add("data_file",     "Name of data file",  &DataFile,    "gmm.data")
.add("simple_model",  "Enable simple model with components number",  &SM, 4)
.add("complex_model", "Enable complex model with components number", &CM, 5)
.add("vsmc_inc_path",    "vSMC include path",      &vSMCIncPath, ".")
.add("r123_inc_path",    "Random123 include path", &R123IncPath, ".")
.add("cl_platform_name", "Platform name",
        &PlatformName, "vSMCOpenCLDefault")
.add("cl_device_type", "Device type",
        &DeviceType, "vSMCOpenCLDefault")
.add("cl_device_vendor","Device vendor",
        &DeviceVendorName, "vSMCOpenCLDefault")
.add("cl_fp_type_bits",  "Bits of OpenCL fp type (32: float; 64: double)",
        &FPTypeBits, 32)
.add("threshold",     "Threshold for resampling, only used by SMC",
        &Threshold, 0.5);
