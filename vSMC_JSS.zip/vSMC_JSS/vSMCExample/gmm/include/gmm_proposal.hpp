#ifndef VSMC_EXAMPLE_GMM_PROPOSAL_HPP
#define VSMC_EXAMPLE_GMM_PROPOSAL_HPP

class gmm_proposal
{
    public :

    typedef const vsmc::Sampler<gmm_state> * value_type;

    gmm_proposal () {}
    gmm_proposal (value_type) {}

    void proposal_iter (std::size_t, vsmc::Particle<gmm_state> &particle) const
    {
        double alpha = particle.value().state(0, 0).alpha();
        double weight_sd, mu_sd, lambda_sd;
        alpha2sd(alpha, mu_sd, lambda_sd, weight_sd);
        for (vsmc::Particle<gmm_state>::size_type i = 0;
                i != particle.size(); ++i) {
            particle.value().state(i, 0).mu_sd()     = mu_sd;
            particle.value().state(i, 0).lambda_sd() = lambda_sd;
            particle.value().state(i, 0).weight_sd() = weight_sd;
        }
    }

    void proposal_init (vsmc::Particle<gmm_state> &particle) const
    {
        for (vsmc::Particle<gmm_state>::size_type i = 0;
                i != particle.size(); ++i) {
            alpha2sd(
                    particle.value().state(i, 0).alpha(),
                    particle.value().state(i, 0).mu_sd(),
                    particle.value().state(i, 0).lambda_sd(),
                    particle.value().state(i, 0).weight_sd());
        }
    }

    private :

    void alpha2sd (double alpha,
            double &mu_sd, double &lambda_sd, double &weight_sd) const
    {
        using std::sqrt;

        alpha = alpha < 0.05 ? 0.05 : alpha;
        mu_sd     = 0.15 / alpha;
        lambda_sd = (1 + sqrt(1.0 / alpha)) * 0.15;
        weight_sd = (1 + sqrt(1.0 / alpha)) * 0.2;
    }
};

class gmm_proposal_adaptive
{
    public :

    typedef const vsmc::Sampler<gmm_state> * value_type;

    gmm_proposal_adaptive (value_type sampler) : sampler_(sampler) {}

    void proposal_iter (std::size_t, vsmc::Particle<gmm_state> &particle) const
    {
        using std::sqrt;

        double coeff = 2.38 / sqrt(static_cast<double>(
                    particle.value().state(0, 0).comp_num()));
        double mu_sd     = coeff * get_sd("rm.mu");
        double lambda_sd = coeff * get_sd("rm.lambda");
        double weight_sd = coeff * get_sd("rm.weight");
        for (vsmc::Particle<gmm_state>::size_type i = 0;
                i != particle.size(); ++i) {
            particle.value().state(i, 0).mu_sd()     = mu_sd;
            particle.value().state(i, 0).lambda_sd() = lambda_sd;
            particle.value().state(i, 0).weight_sd() = weight_sd;
        }
    }

    private :

    const vsmc::Sampler<gmm_state> *const sampler_;

    double get_sd (const std::string &name) const
    {
        using std::sqrt;

        const vsmc::Monitor<gmm_state> &monitor = sampler_->monitor(name);
        double mean = monitor.record(0);
        double r2mn = monitor.record(1);

        return sqrt(r2mn - mean * mean);
    }
};

#endif // VSMC_EXAMPLE_GMM_PROPOSAL_HPP
