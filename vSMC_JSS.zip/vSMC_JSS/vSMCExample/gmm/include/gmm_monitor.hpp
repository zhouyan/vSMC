#ifndef VSMC_EXAMPLE_GMM_MONITOR_HPP
#define VSMC_EXAMPLE_GMM_MONITOR_HPP

class gmm_monitor : public BASE_MONITOR<gmm_state, gmm_monitor>
{
    public :

    void monitor_state (std::size_t, std::size_t dim,
            vsmc::ConstSingleParticle<gmm_state> csp, double *res)
    {
        assert(!(dim % 3));
        assert(csp.state(0).comp_num() >= dim / 3);
        const std::size_t cn = dim / 3;
        for (std::size_t d = 0; d != cn; ++d) {
            res[d + 1] = csp.state(0).mu(d);
            res[d + 1 + cn] = csp.state(0).lambda(d);
            res[d + 1 + 2 * cn] = csp.state(0).weight(d);
        }
    }
};

class gmm_comp_num : public BASE_MONITOR<gmm_state, gmm_comp_num>
{
    public :

    void monitor_state (std::size_t, std::size_t,
            vsmc::ConstSingleParticle<gmm_state> csp, double *res)
    {*res = static_cast<double>(csp.state(0).comp_num());}
};

class gmm_rm_mu : public BASE_MONITOR<gmm_state, gmm_rm_mu>
{
    public :

    void monitor_state (std::size_t, std::size_t dim,
            vsmc::ConstSingleParticle<gmm_state> csp, double *res)
    {
        double mu = 0;
        const std::size_t cn = csp.state(0).comp_num();
        for (std::size_t i = 0; i != cn; ++i)
            mu += csp.state(0).mu(i);
        mu /= cn;
        res[0] = mu;
        for (std::size_t d = 1; d != dim; ++d)
            res[d] = res[d - 1] * mu;
    }
};

class gmm_rm_lambda : public BASE_MONITOR<gmm_state, gmm_rm_lambda>
{
    public :

    void monitor_state (std::size_t, std::size_t dim,
            vsmc::ConstSingleParticle<gmm_state> csp, double *res)
    {
        using std::log;

        double log_lambda = 0;
        const std::size_t cn = csp.state(0).comp_num();
        for (std::size_t i = 0; i != cn; ++i)
            log_lambda += log(csp.state(0).lambda(i));
        log_lambda /= cn;
        res[0] = log_lambda;
        for (std::size_t d = 1; d != dim; ++d)
            res[d] = res[d - 1] * log_lambda;
    }
};

class gmm_rm_weight : public BASE_MONITOR<gmm_state, gmm_rm_weight>
{
    public :

    void monitor_state (std::size_t, std::size_t dim,
            vsmc::ConstSingleParticle<gmm_state> csp, double *res)
    {
        double max_w = csp.state(0).weight(0);
        const std::size_t cn = csp.state(0).comp_num();
        for (std::size_t i = 0; i != cn; ++i)
            if (max_w < csp.state(0).weight(i))
                max_w = csp.state(0).weight(i);
        double logit_weight = 0;
        for (std::size_t i = 0; i != cn; ++i)
                logit_weight += csp.state(0).weight(i) / max_w;
        logit_weight /= cn;
        res[0] = logit_weight;
        for (std::size_t d = 1; d != dim; ++d)
            res[d] = res[d - 1] * logit_weight;
    }
};

class gmm_moments : public BASE_MONITOR<gmm_state, gmm_moments>
{
    public :

    void monitor_state (std::size_t, std::size_t dim,
            vsmc::ConstSingleParticle<gmm_state> csp, double *res)
    {
        for (std::size_t i = 0; i != dim; ++i)
            res[i] = 0;
        assert(dim >= csp.state(0).comp_num() * 3);
        const std::size_t cn = csp.state(0).comp_num();
        std::size_t offset = 0;
        for (std::size_t d = 0; d != cn; ++d)
            res[offset++] = csp.state(0).mu(d);
        for (std::size_t d = 0; d != cn; ++d)
            res[offset++] = csp.state(0).lambda(d);
        for (std::size_t d = 0; d != cn; ++d)
            res[offset++] = csp.state(0).weight(d);
    }
};

#endif // VSMC_EXAMPLE_GMM_MONITOR_HPP
