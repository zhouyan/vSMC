#include "pf_cl.hpp"

int main (int argc, char *argv[])
{
    if (argc < 4) {
        std::cout << "Usage: " << argv[0]
            << " <input file>"
            << " <output file>"
            << " <resample scheme>"
            << std::endl;
        return -1;
    }

    if (!vsmc::CLManager<vsmc::CLDefault>::instance().setup()) {
        std::cout << "Failed to setup OpenCL environment" << std::endl;
        return -1;
    }

    vsmc::ResampleScheme ResScheme = vsmc::Stratified;
    if (!std::strcmp(argv[3], "Multinomial"))
        ResScheme = vsmc::Multinomial;
    else if (!std::strcmp(argv[3], "Residual"))
        ResScheme = vsmc::Residual;
    else if (!std::strcmp(argv[3], "Stratified"))
        ResScheme = vsmc::Stratified;
    else if (!std::strcmp(argv[3], "Systematic"))
        ResScheme = vsmc::Systematic;
    else if (!std::strcmp(argv[3], "ResidualStratified"))
        ResScheme = vsmc::ResidualStratified;
    else if (!std::strcmp(argv[3], "ResidualSystematic"))
        ResScheme = vsmc::ResidualSystematic;

    vsmc::Sampler<cv> sampler(ParticleNum, ResScheme, 0.5);
    std::ifstream src_file("pf_cl.cl");
    std::string src(
            (std::istreambuf_iterator<char>(src_file)),
            (std::istreambuf_iterator<char>()));
    src_file.close();
    std::string opt;
    for (int i = 4; i != argc; ++i) {
        opt += " ";
        opt += argv[i];
    }
    sampler.particle().value().build(src, opt);

    std::string name;
    sampler.particle().value().manager().platform().getInfo(
            static_cast<cl_device_info>(CL_PLATFORM_NAME), &name);
    std::cout << "Using platform: " << name << std::endl;
    sampler.particle().value().manager().device().getInfo(
            static_cast<cl_device_info>(CL_DEVICE_NAME), &name);
    std::cout << "Using device:   " << name << std::endl;

    sampler.init(cv_init()).move(cv_move(), true).monitor("pos", 2,
            vsmc::MonitorEvalAdapter<cv, vsmc::MonitorEvalCL>("cv_est"));

#if VSMC_USE_HDF5
    std::string hdf5_trace_file_name(argv[2]);
    hdf5_trace_file_name += ".trace.hdf5";
    sampler.initialize(argv[1]);
    vsmc::hdf5store<vsmc::RowMajor, cv::fp_type>(
            sampler.particle().value(),
            hdf5_trace_file_name, "Trace.0");
    for (std::size_t i = 0; i != DataNum - 1; ++i) {
        std::stringstream ss;
        ss << "Trace." << (i + 1);
        sampler.iterate();
        vsmc::hdf5store<vsmc::RowMajor, cv::fp_type>(
                sampler.particle().value(),
                hdf5_trace_file_name, ss.str(), true);
    }
#else
    sampler.initialize(argv[1]);
    sampler.iterate(DataNum - 1);
#endif

    std::ofstream est(argv[2]);
    est << sampler << std::endl;
    est.close();

#if VSMC_USE_HDF5
    std::string hdf5_sampler_file_name(argv[2]);
    hdf5_sampler_file_name += ".hdf5";
    vsmc::hdf5store(sampler, hdf5_sampler_file_name, "Sampler");
#endif

    return 0;
}
