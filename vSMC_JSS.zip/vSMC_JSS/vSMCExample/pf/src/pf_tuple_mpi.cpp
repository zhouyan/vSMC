#include "pf_tuple_mpi_@smp@.hpp"

int main (int argc, char *argv[])
{
    vsmc::MPIEnvironment env(argc, argv);
    @HALF_NUM_THREADS@;
#include "pf_smp_main.hpp"
}
