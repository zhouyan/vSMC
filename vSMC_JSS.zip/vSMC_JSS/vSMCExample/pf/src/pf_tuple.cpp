#include "pf_tuple_@smp@.hpp"

int main (int argc, char *argv[])
{
#include "pf_smp_main.hpp"
}
