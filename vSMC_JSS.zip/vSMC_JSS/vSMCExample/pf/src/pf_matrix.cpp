#include "pf_matrix_@smp@.hpp"

int main (int argc, char *argv[])
{
#include "pf_smp_main.hpp"
}
