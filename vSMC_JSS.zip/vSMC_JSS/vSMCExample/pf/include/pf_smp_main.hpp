try {
    if (argc < 4) {
        std::cout << "Usage: " << argv[0]
            << " <input file>"
            << " <output file>"
            << " <resample scheme>"
            << std::endl;
        return -1;
    }

    vsmc::ResampleScheme ResScheme = vsmc::Stratified;
    if (!std::strcmp(argv[3], "Multinomial"))
        ResScheme = vsmc::Multinomial;
    else if (!std::strcmp(argv[3], "Residual"))
        ResScheme = vsmc::Residual;
    else if (!std::strcmp(argv[3], "Stratified"))
        ResScheme = vsmc::Stratified;
    else if (!std::strcmp(argv[3], "Systematic"))
        ResScheme = vsmc::Systematic;
    else if (!std::strcmp(argv[3], "ResidualStratified"))
        ResScheme = vsmc::ResidualStratified;
    else if (!std::strcmp(argv[3], "ResidualSystematic"))
        ResScheme = vsmc::ResidualSystematic;

    cv_do<vsmc::RowMajor>(ResScheme, argv, ".row");
    cv_do<vsmc::ColMajor>(ResScheme, argv, ".col");
} catch (vsmc::RuntimeAssert &err) {
    std::fprintf(stderr, "%s\n", err.what());
    throw err;
} catch (std::exception &err) {
    std::fprintf(stderr, "Uncaught expections: %s\n", err.what());
    throw err;
}

return 0;
