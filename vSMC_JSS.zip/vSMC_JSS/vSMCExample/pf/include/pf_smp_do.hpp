#ifndef VSMC_EXAMPLE_PF_SMP_DO_HPP
#define VSMC_EXAMPLE_PF_SMP_DO_HPP

template <vsmc::MatrixOrder Order>
inline void cv_do (vsmc::ResampleScheme res, char *argv[],
        const std::string &name)
{
    vsmc::Seed::instance().set(101);
    vsmc::Sampler<cv_state<Order> > sampler(ParticleNum, res, 0.5);
    sampler
        .init(cv_init<Order>())
        .move(vsmc::MoveAdapter<
                cv_state<Order>, BASE_MOVE, cv_move<Order> >(), true)
        .monitor("pos", 2, vsmc::MonitorEvalAdapter<
                cv_state<Order>, BASE_MONITOR>(cv_est<Order>));
#if VSMC_USE_HDF5
    sampler.initialize(argv[1]);
    vsmc::hdf5store(sampler.particle().value(),
            argv[2] + name + ".trace.hdf5", "Trace.0");
    for (std::size_t i = 0; i != DataNum - 1; ++i) {
        std::stringstream ss;
        ss << "Trace." << (i + 1);
        sampler.iterate();
        vsmc::hdf5store(sampler.particle().value(),
                argv[2] + name + ".trace.hdf5", ss.str(), true);
    }
#else
    sampler.initialize(argv[1]);
    sampler.iterate(DataNum - 1);
#endif

    std::string est_file_name(argv[2] + name);
    std::ofstream est_file;
    est_file.open(est_file_name.c_str());
    est_file << sampler << std::endl;
    est_file.close();
    est_file.clear();

#if VSMC_USE_HDF5
    vsmc::hdf5store(sampler, argv[2] + name + ".hdf5", "Sampler");
#endif
}

#endif // VSMC_EXAMPLE_PF_SMP_DO_HPP
