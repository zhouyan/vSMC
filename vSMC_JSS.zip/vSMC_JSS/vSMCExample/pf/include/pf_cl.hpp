#ifndef VSMC_EXAMPLE_PF_CL_HPP
#define VSMC_EXAMPLE_PF_CL_HPP

#include <vsmc/core/sampler.hpp>
#include <vsmc/opencl/adapter.hpp>
#include <vsmc/opencl/backend_cl.hpp>
#include <Random123/array.h>

#if VSMC_USE_HDF5
#include <vsmc/utility/hdf5io.hpp>
#endif

#include <fstream>
#include <iostream>

const std::size_t DataNum = 100;
const std::size_t ParticleNum = 10000;
const std::size_t StateSize = 4 * sizeof(cl_float);

class cv : public vsmc::StateCL<StateSize, cl_float, vsmc::CLDefault>
{
    public :

    cv (size_type N) : vsmc::StateCL<StateSize, cl_float, vsmc::CLDefault>(N)
    {
        counter_ = manager().create_buffer<struct r123array4x32>(N);
    }

    const cl::Buffer &obs_x () const {return obs_x_;}
    const cl::Buffer &obs_y () const {return obs_y_;}
    const cl::Buffer &counter () const {return counter_;}

    void read_data (const char *file)
    {
        if (!file)
            return;

        std::vector<cv::fp_type> x(DataNum);
        std::vector<cv::fp_type> y(DataNum);
        std::ifstream data(file);
        for (std::size_t i = 0; i != DataNum; ++i)
            data >> x[i] >> y[i];
        data.close();
        data.clear();

        obs_x_ = manager().create_buffer<cv::fp_type>(x.begin(), x.end());
        obs_y_ = manager().create_buffer<cv::fp_type>(y.begin(), y.end());
    }

    private :

    cl::Buffer obs_x_;
    cl::Buffer obs_y_;
    cl::Buffer counter_;
};

class cv_init : public vsmc::InitializeCL<cv>
{
    public :

    void initialize_state (std::string &kernel_name)
    {kernel_name = std::string("cv_init");}

    void initialize_param (vsmc::Particle<cv> &particle, void *file)
    {particle.value().read_data(static_cast<const char *>(file));}

    void pre_processor (vsmc::Particle<cv> &particle)
    {
        if (log_weight_.size() != particle.size()) {
            log_weight_device_ = particle.value().manager()
                .create_buffer<cv::fp_type>(particle.size());
            log_weight_.resize(particle.size());
        }

        vsmc::cl_set_kernel_args(
                kernel(), kernel_args_offset(),
                log_weight_device_,
                particle.value().obs_x(),
                particle.value().obs_y(),
                particle.value().counter());
    }

    void post_processor (vsmc::Particle<cv> &particle)
    {
        particle.value().manager().read_buffer<cv::fp_type>(
                log_weight_device_, particle.size(), &log_weight_[0]);
        particle.weight_set().set_log_weight(&log_weight_[0]);
    }

    private :

    cl::Buffer log_weight_device_;
    std::vector<double> log_weight_;
};

class cv_move : public vsmc::MoveCL<cv>
{
    public :

    void move_state (std::size_t, std::string &kernel_name)
    {kernel_name = std::string("cv_move");}

    void pre_processor (std::size_t, vsmc::Particle<cv> &particle)
    {
        if (inc_weight_.size() != particle.size()) {
            inc_weight_device_ = particle.value().manager()
                .create_buffer<cv::fp_type>(particle.size());
            inc_weight_.resize(particle.size());
        }

        vsmc::cl_set_kernel_args(
                kernel(), kernel_args_offset(),
                inc_weight_device_,
                particle.value().obs_x(),
                particle.value().obs_y(),
                particle.value().counter());
    }

    void post_processor (std::size_t, vsmc::Particle<cv> &particle)
    {
        particle.value().manager().read_buffer<cv::fp_type>(
                inc_weight_device_, particle.size(), &inc_weight_[0]);
        particle.weight_set().add_log_weight(&inc_weight_[0]);
    }

    private :

    cl::Buffer inc_weight_device_;
    std::vector<double> inc_weight_;
};

#endif // VSMC_EXAMPLE_PF_CL_HPP
