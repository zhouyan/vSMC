execnames <- c("seq", "cilk", "gcd", "omp", "std", "tbb")
basenames <- character()
basenames <- c(basenames, paste("pf_matrix", execnames, sep = "_"))
basenames <- c(basenames, paste("pf_tuple", execnames, sep = "_"))
basenames <- c(basenames, paste("pf_matrix_mpi", execnames, sep = "_"))
basenames <- c(basenames, paste("pf_tuple_mpi", execnames, sep = "_"))
basenames <- c(basenames, "pf_cl")
resenames <- c(
    "Multinomial",
    "Residual",
    "Stratified",
    "Systematic",
    "ResidualStratified",
    "ResidualSystematic")
filenames <- expand.grid(basenames, resenames)
filenames <- paste(filenames$Var1, filenames$Var2, sep = "_")

obs <- read.table("pf.data", header = FALSE)
pdf("pf.pdf")
for (rowcol in c(".row", ".col", "")) {
    for (filename in filenames) {
        read.xy <- FALSE
        save_file <- paste(filename, rowcol, sep = "")
        save_file0 <- paste(filename, rowcol, ".r0", sep = "")
        save_file1 <- paste(filename, rowcol, ".r1", sep = "")
        if (file.exists(save_file)) {
            xy <- read.table(save_file, header = TRUE)
            read.xy <- TRUE
        }
        if (file.exists(save_file0) && file.exists(save_file1)) {
            xy0 <- read.table(save_file0, header = TRUE)
            xy1 <- read.table(save_file1, header = TRUE)
            xy <- xy0 + xy1
            read.xy <- TRUE
        }
        if (read.xy) {
            name <- paste(filename, rowcol, sep = "")
            cat("Print ", name, "\n", sep = "")
            plot(obs[,1], obs[,2], col = 4, main = name,
                xlim = c(-6.4, -1), ylim = c(3, 14),
                xlab = "Position x", ylab = "Position y")
            lines(xy$pos.1, xy$pos.2, col = 2)
        }
    }
}
garbage <- dev.off()
