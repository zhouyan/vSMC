#ifndef VSMC_EXAMPLE_NODE_HPP
#define VSMC_EXAMPLE_NODE_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@
#define BASE_PATH    vsmc::PathEval@SMP@

#include <vsmc/smp/backend_@smp@.hpp>

static const std::size_t InitCompNum = 3;
static const std::size_t MinCompNum = 1;
static const std::size_t MaxCompNum = 5;

static std::string DataFile;
static std::size_t DataNum;
static std::size_t SM;
static std::size_t CM;
static double Resolution;
static double Shape0;
static double Scale0;

#include "common.hpp"
#include "node_param.hpp"
#include "node_state.hpp"
#include "node_init.hpp"
#include "node_move.hpp"
#include "node_monitor.hpp"
#include "node_proposal.hpp"

#endif // VSMC_EXAMPLE_NODE_HPP
