#ifndef VSMC_EXAMPLE_NODE_INIT_HPP
#define VSMC_EXAMPLE_NODE_INIT_HPP

class node_init : public BASE_INIT<node_state, node_init>
{
    public :

    void pre_processor (vsmc::Particle<node_state> &particle)
    {
        particle.value().alpha(0);
        particle.value().alpha_inc(0);
        particle.set_equal_weight();
    }

    void initialize_param (vsmc::Particle<node_state> &particle, void *info)
    {
        if (particle.value().state(0, 0).comp_num() == 0)
            particle.value().comp_num(InitCompNum);
        if (info)
            particle.value().read_data(static_cast<const data_info *>(info));
    }

    std::size_t initialize_state (vsmc::SingleParticle<node_state> sp)
    {
        double shape0 = sp.particle().value().shape0();
        double scale0 = sp.particle().value().scale0();

        vsmc::cxx11::gamma_distribution<> rgamma(shape0, scale0);

        const std::size_t cn = sp.state(0).comp_num();
        sp.state(0).a0() = rgamma(sp.rng());
        sp.state(0).a1() = rgamma(sp.rng());
        sp.state(0).a2() = rgamma(sp.rng());
        for (std::size_t d = 0; d != cn - 1; ++d)
            sp.state(0).k(d) = rgamma(sp.rng());
        sp.particle().value().log_target(sp.state(0));

        return 0;
    }
};

#endif // VSMC_EXAMPLE_NODE_INIT_HPP
