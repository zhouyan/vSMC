#include <vsmc/opencl/cl_query.hpp>

int main ()
{
    std::cout << vsmc::CLQuery() << std::endl;
}
