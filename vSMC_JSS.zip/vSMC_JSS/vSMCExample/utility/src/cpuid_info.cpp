#include <vsmc/utility/cpuid.hpp>

int main ()
{
    std::cout << vsmc::CPUID() << std::endl;
}
