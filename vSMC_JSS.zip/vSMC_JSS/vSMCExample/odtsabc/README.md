# Observation-driven time series using approximate Bayesian computation

This example implements approximate Bayesian computation algorithms for the
observation-driven time series model found in:

Jasra, A. (2014). Approximate Bayesian Computation for a Class of Time Series Models. arXiv preprint arXiv:1401.0265.

## Algorithms
