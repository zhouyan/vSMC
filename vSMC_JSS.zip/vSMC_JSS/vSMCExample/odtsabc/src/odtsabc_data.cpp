#include <vsmc/utility/program_option.hpp>
#include <vsmc/cxx11/cmath.hpp>
#include <vsmc/cxx11/random.hpp>
#include <vsmc/math/constants.hpp>
#include <fstream>

static const std::size_t NTrial = 100;
static const double Epsilon = 0.01;
#include "odtsabc_alg.hpp"

int main (int argc, char **argv)
{
    static std::size_t DataNum;
    static std::string DataFile;
    static unsigned Seed;
    static double X0;
    static double Beta0;
    static double Beta1;
    static double Beta2;

    vsmc::ProgramOptionMap Config;
    Config
        .add("data_num",  "Number of data", &DataNum,  532)
        .add("data_file", "Data file",      &DataFile, "odtsabc_simulate.data")
        .add("seed",      "Seed of RNG",    &Seed,     101)
        .add("x0",        "x0",             &X0,       0.1)
        .add("beta0",     "beta0",          &Beta0,    5e-5)
        .add("beta1",     "beta1",          &Beta1,    0.5)
        .add("beta2",     "beta2",          &Beta2,    0.1);
    Config.process(argc, argv);

    odtsabc_alg alg;
    vsmc::cxx11::mt19937 eng(Seed);
    vsmc::cxx11::uniform_real_distribution<double> runif(-Epsilon, Epsilon);
    std::vector<double> x(DataNum);
    std::vector<double> y(DataNum);

    y[0] = alg.sample_u(eng, X0);
    x[0] = Beta0 + Beta1 * X0 + Beta2 * y[0] * y[0];
    for (std::size_t i = 1; i != DataNum; ++i) {
        for (std::size_t j = 0; j != NTrial; ++j)
            y[i] = alg.sample_u(eng, x[i - 1]) + runif(eng);
        y[i] = alg.sample_u(eng, x[i - 1]);
        x[i] = Beta0 + Beta1 * x[i - 1] + Beta2 * y[i] * y[i];
    }

    std::ofstream output;
    output.open(DataFile.c_str());
    for (std::size_t i = 0; i != DataNum; ++i)
        output << y[i] << '\n';
    output.close();
    output.clear();
}
