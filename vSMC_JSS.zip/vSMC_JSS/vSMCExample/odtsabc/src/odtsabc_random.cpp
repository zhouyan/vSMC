#include "odtsabc_@smp@.hpp"

int main (int argc, char **argv)
{
#include "options_main.hpp"
#include "odtsabc_options.hpp"
    Config.add("suffix", "Suffix to output file", &Suffix, "random");
#include "options_process.hpp"

    const std::string suffix = Suffix + ".ntrial";
    odtsabc_do<odtsabc_state_random>();

    return 0;
}
