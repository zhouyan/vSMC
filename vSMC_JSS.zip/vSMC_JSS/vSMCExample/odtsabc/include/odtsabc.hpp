#ifndef VSMC_EXAMPLE_ODTSABC_HPP
#define VSMC_EXAMPLE_ODTSABC_HPP

#define BASE_INIT  vsmc::Initialize@SMP@
#define BASE_MOVE  vsmc::Move@SMP@

#include <vsmc/smp/backend_@smp@.hpp>
#include <vsmc/cxx11/cmath.hpp>

#if VSMC_USE_HDF5
#include <vsmc/utility/hdf5io.hpp>
#endif

#if VSMC_USE_GCD
#include <vsmc/utility/dispatch.hpp>
#endif

static bool Noisy;
static double Epsilon;
static double SDX0;
static double SDBeta0;
static double SDBeta1;
static double SDBeta2;
static std::size_t NTrial;
static std::size_t IterNum;
static std::size_t DataNum;
static std::string DataFile;

#include "common.hpp"
#include "odtsabc_alg.hpp"
#include "odtsabc_param.hpp"
#include "odtsabc_state.hpp"
#include "odtsabc_init.hpp"
#include "odtsabc_move.hpp"
#include "odtsabc_do.hpp"

#endif // VSMC_EXAMPLE_ODTSABC_HPP
