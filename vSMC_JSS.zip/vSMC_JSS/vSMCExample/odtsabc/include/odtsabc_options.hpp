Config
.add("noisy",     "Use noisy ABC",                  &Noisy,    true)
.add("epsilon",   "Tolerance",                      &Epsilon,  0.5)
.add("sd_x0",     "Proposal scale for x0",          &SDX0,     1)
.add("sd_beta0",  "Proposal scale for beta0",       &SDBeta0,  1)
.add("sd_beta1",  "Proposal scale for beta1",       &SDBeta1,  1)
.add("sd_beta2",  "Proposal scale for beta2",       &SDBeta2,  1)
.add("ntrial",    "Number of trials per iteration", &NTrial,   250)
.add("data_num",  "Number of data points",          &DataNum,  532)
.add("iter_num",  "Number of iterations",           &IterNum,  200000)
.add("data_file", "File name of data",              &DataFile, "odtsabc.data")
.remove("repeat");
