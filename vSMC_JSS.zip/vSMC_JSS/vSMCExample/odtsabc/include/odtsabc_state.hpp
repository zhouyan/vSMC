#ifndef VSMC_EXAMPLE_ODTSABC_STATE_HPP
#define VSMC_EXAMPLE_ODTSABC_STATE_HPP

template <typename Alg>
class odtsabc_state : public vsmc::StateMatrix<vsmc::RowMajor, 1, Alg>
{
    public :

    typedef vsmc::StateMatrix<vsmc::RowMajor, 1, Alg> base_state;

    odtsabc_state (std::size_t N) :
        base_state(N), runif_(0, 1), lprod_now_(0), lprod_new_(0), ntrial_(N),
        x_(N), y_(N), history_accept_(0) {}

    virtual ~odtsabc_state () {}

    template <typename S>
    struct single_particle_type :
        public base_state::template single_particle_type<S>
    {
        single_particle_type (typename vsmc::Particle<S>::size_type id,
                vsmc::Particle<S> *particle_ptr) :
            base_state::template single_particle_type<S>(id, particle_ptr) {}

        std::size_t sample ()
        {
            std::size_t i = this->id();
            std::size_t n;
            if (i == 0) {
                n = this->state(0).sample(this->rng(),
                        this->particle().value().param_new_.x0(),
                        this->particle().value().y_[i]);
            } else {
                n = this->state(0).sample(this->rng(),
                        this->particle().value().x_[i - 1],
                        this->particle().value().y_[i]);
            }
            this->mutable_particle_ptr()->value().ntrial_[i] = n;

            return n;
        }
    };

    std::size_t history_size () const {return history_x0_.size();}

    std::size_t history_accept () const {return history_accept_;}

    void history_reserve (std::size_t n)
    {
        n += history_x0_.size();
        history_x0_.reserve(n);
        history_beta0_.reserve(n);
        history_beta1_.reserve(n);
        history_beta2_.reserve(n);
    }

    std::vector<const double *> history_ptr () const
    {
        std::vector<const double *> hptr;
        hptr.push_back(&history_x0_[0]);
        hptr.push_back(&history_beta0_[0]);
        hptr.push_back(&history_beta1_[0]);
        hptr.push_back(&history_beta2_[0]);

        return hptr;
    }

    std::vector<std::string> history_name () const
    {
        std::vector<std::string> hname;
        hname.push_back("x0");
        hname.push_back("beta0");
        hname.push_back("beta1");
        hname.push_back("beta2");

        return hname;
    }

    template <typename Eng>
    void init_param (Eng &eng)
    {
        // vsmc::cxx11::gamma_distribution<double> rgamma_x0(
        //         param_now_.x0_shape(), param_now_.x0_scale());
        // vsmc::cxx11::gamma_distribution<double> rgamma_beta(
        //         param_now_.beta_shape(), param_now_.beta_scale());
        // double x0    = rgamma_x0(eng);
        // double beta0 = rgamma_beta(eng);
        // double beta1 = rgamma_beta(eng);
        // double beta2 = rgamma_beta(eng);

        double x0    = 0.5;
        double beta0 = 0.00005;
        double beta1 = 0.1;
        double beta2 = 0.01;

        param_now_ = param_new_ = odtsabc_param(x0, beta0, beta1, beta2);
        read_y(eng);
        compute_x(param_now_);
        history_clear();
        history_push_back(param_now_, false);
    }

    void init_prod ()
    {lprod_now_ = compute_lprod(ntrial_.size(), &ntrial_[0]);}

    template <typename Eng>
    void sample_param (Eng &eng)
    {
        param_new_ = param_now_.sample(eng);
        compute_x(param_new_);
    }

    template <typename Eng>
    void mh_update (Eng &eng)
    {
        using std::log;

        static const double lprod_min = -std::numeric_limits<double>::max
            VSMC_MNE ();
        static const double lprod_max = std::numeric_limits<double>::max
            VSMC_MNE ();

        lprod_new_ = compute_lprod(ntrial_.size(), &ntrial_[0]);
        bool ok_now = (lprod_now_ > lprod_min && lprod_now_ < lprod_max);
        bool ok_new = (lprod_new_ > lprod_min && lprod_new_ < lprod_max);

        bool accept = false;
        if (!ok_now && !ok_new)
            accept = false;
        else if (ok_now && !ok_new)
            accept = false;
        else if (!ok_now && ok_new)
            accept = true;
        else {
            double u = log(runif_(eng));
            double p = param_new_.log_target() - param_now_.log_target();
            p += lprod_new_ - lprod_now_;
            accept = (u < p);
        }

        if (accept) {
            lprod_now_ = lprod_new_;
            param_now_ = param_new_;
        }

        history_push_back(param_now_, accept);
    }

    private :

    vsmc::cxx11::uniform_real_distribution<double> runif_;

    odtsabc_param param_now_;
    odtsabc_param param_new_;
    double lprod_now_;
    double lprod_new_;

    std::vector<std::size_t> ntrial_;
    std::vector<double> x_;
    std::vector<double> y_;

    std::size_t history_accept_;
    std::vector<double> history_x0_;
    std::vector<double> history_beta0_;
    std::vector<double> history_beta1_;
    std::vector<double> history_beta2_;

    void history_clear ()
    {
        history_x0_.clear();
        history_beta0_.clear();
        history_beta1_.clear();
        history_beta2_.clear();
    }

    void history_push_back (const odtsabc_param &param, bool accept)
    {
        if (accept)
            ++history_accept_;
        history_x0_.push_back(param.x0());
        history_beta0_.push_back(param.beta0());
        history_beta1_.push_back(param.beta1());
        history_beta2_.push_back(param.beta2());
    }

    template <typename Eng>
    void read_y (Eng &eng)
    {
        std::ifstream data;
        data.open(DataFile.c_str());
        for (std::size_t i = 0; i != this->size(); ++i)
            data >> y_[i];
        data.close();
        data.clear();

        if (Noisy) {
            vsmc::cxx11::uniform_real_distribution<double>
                runif(-Epsilon, Epsilon);
            for (std::size_t i = 0; i != this->size(); ++i)
                y_[i] += runif(eng);
        }
    }

    void compute_x (const odtsabc_param &param)
    {
        double x0 = param.x0();
        double beta0 = param.beta0();
        double beta1 = param.beta1();
        double beta2 = param.beta2();
        x_[0] = beta0 + beta1 * x0 + beta2 * y_[0] * y_[0];
        for (std::size_t i = 1; i != this->size(); ++i)
            x_[i] = beta0 + beta1 * x_[i - 1] + beta2 * y_[i] * y_[i];
    }

    virtual double compute_lprod (std::size_t, const std::size_t *) = 0;
};

class odtsabc_state_ntrial : public odtsabc_state<odtsabc_ntrial>
{
    public :

    odtsabc_state_ntrial (std::size_t N) : odtsabc_state<odtsabc_ntrial>(N) {}

    double compute_lprod (std::size_t n, const std::size_t * ntrial)
    {
        using std::log;

        double lprod = 0;
        for (std::size_t i = 0; i != n; ++i) {
            if (ntrial[i] == 0)
                return -std::numeric_limits<double>::infinity();
            lprod += log(static_cast<double>(ntrial[i]));
        }

        return lprod;
    }
};

class odtsabc_state_random : public odtsabc_state<odtsabc_random>
{
    public :

    odtsabc_state_random (std::size_t N) : odtsabc_state<odtsabc_random>(N) {}

    double compute_lprod (std::size_t n, const std::size_t *ntrial)
    {
        using std::log;

        double lprod = 0;
        for (std::size_t i = 0; i != n; ++i)
            lprod -= log(static_cast<double>(ntrial[i] - 1));

        return lprod;
    }
};

#endif // VSMC_EXAMPLE_ODTSABC_STATE_HPP
