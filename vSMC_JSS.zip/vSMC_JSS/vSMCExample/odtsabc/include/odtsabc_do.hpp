#ifndef VSMC_EXAMPLE_ODTSABC_DO_HPP
#define VSMC_EXAMPLE_ODTSABC_DO_HPP

#if VSMC_USE_HDF5
template <typename T>
inline void odtsabc_do_output (const vsmc::Sampler<T> &sampler)
{
    const std::size_t history_size = sampler.particle().value().history_size();
    std::vector<const double *> history_ptr(
            sampler.particle().value().history_ptr());
    std::vector<std::string> history_name(
            sampler.particle().value().history_name());
    std::string data_name("odtsabc_");
    std::stringstream ss;
    ss << "_" << Suffix << "_e" << Epsilon << ".hdf5";
    vsmc::hdf5store(sampler,
            data_name + "sampler" + ss.str(), data_name + "sampler");
    vsmc::hdf5store_data_frame<double>(history_size, history_ptr.size(),
            data_name + "trace" + ss.str(), data_name + "trace",
            &history_ptr[0], &history_name[0]);
}
#else // VSMC_USE_HDF5
template <typename T>
inline void odtsabc_do_output (const vsmc::Sampler<T> &) {}
#endif // VSMC_USE_HDF5

template <typename T>
inline void odtsabc_do ()
{
    vsmc::Sampler<T> sampler(DataNum);
    sampler.init(odtsabc_init<T>());
    sampler.move(odtsabc_move<T>(), false);
#if VSMC_USE_GCD
    vsmc::DispatchProgress progress;
    progress.start(IterNum);
#endif
    sampler.particle().value().history_reserve(IterNum + 1);
    sampler.initialize();
    for (std::size_t i = 0; i != IterNum; ++i) {
        sampler.iterate();
#if VSMC_USE_GCD
        progress.increment();
#endif
    }
#if VSMC_USE_GCD
    progress.stop();
#endif
    double accept =
        static_cast<double>(sampler.particle().value().history_accept()) /
        static_cast<double>(IterNum);
    std::cout << "Accept rate: " << accept << std::endl;
    odtsabc_do_output(sampler);
}

#endif // VSMC_EXAMPLE_ODTSABC_DO_HPP
