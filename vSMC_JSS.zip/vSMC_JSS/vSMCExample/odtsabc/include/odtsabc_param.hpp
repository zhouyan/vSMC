#ifndef VSMC_EXAMPLE_ODTSABC_PARAM_HPP
#define VSMC_EXAMPLE_ODTSABC_PARAM_HPP

class odtsabc_param
{
    public :

    odtsabc_param () :
        x0_(0), beta0_(0), beta1_(0), beta2_(0), log_target_(0) {}

    odtsabc_param (double x0, double beta0, double beta1, double beta2) :
        x0_(x0), beta0_(beta0), beta1_(beta1), beta2_(beta2), log_target_(0)
    {compute_log_target();}

    template <typename Eng>
    odtsabc_param sample (Eng &eng) const
    {
        using std::exp;

        vsmc::cxx11::normal_distribution<double> rnorm(0, 1);
        double x0_new    = x0_    * exp(SDX0    * rnorm(eng));
        double beta0_new = beta0_ * exp(SDBeta0 * rnorm(eng));
        double beta1_new = beta1_ * exp(SDBeta1 * rnorm(eng));
        double beta2_new = beta2_ * exp(SDBeta2 * rnorm(eng));

        return odtsabc_param(x0_new, beta0_new, beta1_new, beta2_new);
    }

    static double x0_shape   () {return 2;}
    static double x0_scale   () {return 8;}
    static double beta_shape () {return 2;}
    static double beta_scale () {return 8;}

    double x0    () const {return x0_;}
    double beta0 () const {return beta0_;}
    double beta1 () const {return beta1_;}
    double beta2 () const {return beta2_;}
    double log_target () const {return log_target_;}

    private :

    double x0_;
    double beta0_;
    double beta1_;
    double beta2_;
    double log_target_;

    void compute_log_target ()
    {
        using std::log;

        log_target_ = 0;
        log_target_ += ldgamma(x0_,    x0_shape(),   x0_scale());
        log_target_ += ldgamma(beta0_, beta_shape(), beta_scale());
        log_target_ += ldgamma(beta1_, beta_shape(), beta_scale());
        log_target_ += ldgamma(beta2_, beta_shape(), beta_scale());
        log_target_ += log(x0_);
        log_target_ += log(beta0_);
        log_target_ += log(beta1_);
        log_target_ += log(beta2_);
    }

    double ldgamma (double x, double shape, double scale)
    {
        using std::log;

        return (shape - 1) * log(x) - x / scale;
    }
};

#endif // VSMC_EXAMPLE_ODTSABC_PARAM_HPP
