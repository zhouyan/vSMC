#ifndef VSMC_EXAMPLE_ODTSABC_ALG_HPP
#define VSMC_EXAMPLE_ODTSABC_ALG_HPP

class odtsabc_alg
{
    public :

    odtsabc_alg () : runif_(0, 1), rexp_(1) {}

    template <typename Eng>
    double sample_u (Eng &eng, double xi)
    {
        using std::sin;
        using std::cos;
        using vsmc::cxx11::cbrt;

        double u = runif_(eng);
        u = (0.5 * u - 1) * vsmc::math::pi<double>();
        double numr = sin(1.5 * u);
        double dnom = cos(u);
        dnom = cbrt(dnom * dnom * cos(0.5 * u));

        return xi * cbrt(rexp_(eng)) * numr / dnom;
    }

    template <typename Eng>
    std::size_t sample_one (Eng &eng, double xi, double yi)
    {
        using std::fabs;

        double ui = sample_u(eng, xi);

        return fabs(ui - yi) < Epsilon ? 1 : 0;
    }

    private :

    vsmc::cxx11::uniform_real_distribution<double> runif_;
    vsmc::cxx11::exponential_distribution<double> rexp_;
};

class odtsabc_ntrial : public odtsabc_alg
{
    public :

    template <typename Eng>
    std::size_t sample (Eng &eng, double xi, double yi)
    {
        std::size_t close = 0;
        for (std::size_t i = 0; i != NTrial; ++i)
            close += sample_one(eng, xi, yi);

        return close;
    }
};

class odtsabc_random : public odtsabc_alg
{
    public :

    template <typename Eng>
    std::size_t sample (Eng &eng, double xi, double yi)
    {
        std::size_t remain = NTrial;
        std::size_t ntrial = 0;
        while (remain != 0) {
            ++ntrial;
            remain -= sample_one(eng, xi, yi);
        }

        return ntrial;
    }
};

#endif // VSMC_EXAMPLE_ODTSABC_ALG_HPP
