#ifndef VSMC_EXAMPLE_ODTSABC_INIT_HPP
#define VSMC_EXAMPLE_ODTSABC_INIT_HPP

template <typename T>
class odtsabc_init : public BASE_INIT<T, odtsabc_init<T> >
{
    public :

    void pre_processor (vsmc::Particle<T> &particle)
    {particle.value().init_param(particle.rng(0));}

    std::size_t initialize_state (vsmc::SingleParticle<T> sp)
    {return sp.sample();}

    void post_processor (vsmc::Particle<T> &particle)
    {particle.value().init_prod();}
};

#endif // VSMC_EXAMPLE_ODTSABC_INIT_HPP
