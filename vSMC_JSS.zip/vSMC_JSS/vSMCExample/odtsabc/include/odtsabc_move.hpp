#ifndef VSMC_EXAMPLE_ODTSABC_MOVE_HPP
#define VSMC_EXAMPLE_ODTSABC_MOVE_HPP

template <typename T>
class odtsabc_move : public BASE_MOVE<T, odtsabc_move<T> >
{
    public :

    void pre_processor (std::size_t iter, vsmc::Particle<T> &particle)
    {particle.value().sample_param(particle.rng(iter % particle.size()));}

    std::size_t move_state (std::size_t, vsmc::SingleParticle<T> sp)
    {return sp.sample();}

    void post_processor (std::size_t iter, vsmc::Particle<T> &particle)
    {particle.value().mh_update(particle.rng(iter % particle.size()));}
};

#endif // VSMC_EXAMPLE_ODTSABC_MOVE_HPP
