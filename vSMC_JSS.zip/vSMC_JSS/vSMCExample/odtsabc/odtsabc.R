suppressPackageStartupMessages(library(ggplot2))
suppressPackageStartupMessages(library(rhdf5))

read.result <- function (alg = "ntrial", epsilon = "0.5")
{
    suffix <- paste("_", alg, "_e", epsilon, ".hdf5", sep = "")

    sampler.file <- paste("odtsabc_sampler", suffix, sep = "")
    sampler <- data.frame(h5read(sampler.file, "/odtsabc_sampler"))
    sampler.thin <- sampler[seq(1, dim(sampler)[1], 100),]

    trace.file <- paste("odtsabc_trace", suffix, sep = "")
    trace <- data.frame(h5read(trace.file, "/odtsabc_trace"))
    trace.thin <- trace[seq(1, dim(trace)[1], 100),]

    full <- list(Sampler = sampler, Trace = trace)
    thin <- list(Sampler = sampler.thin, Trace = trace.thin)

    list(Full = full, Thin = thin)
}
