#include <vsmc/@headername@>

int main () {}
