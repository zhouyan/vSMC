suppressPackageStartupMessages(library(ggplot2))

ParticleNum <- 2^(4:11)
DataNum <- c(10, 25, 50, 100)

simulate <- function (var.move, var.obs)
{
    acc <- numeric()
    cmd <- paste("./hmm-data ",
        " --data_num ", max(DataNum),
        " --var_move ", var.move,
        " --var_obs ", var.obs)
    system(cmd)
    for (D in DataNum) {
        for (N in ParticleNum) {
            cat("\n\n\nT:", D, "N:", N, "\n")
            cmd <- paste("./hmm-pimh-tbb ",
                " --var_move ", var.move, " --var_obs ", var.obs,
                " --iter_num 50000 --burnin_num 10000 ",
                " --data_num ", D, " --particle_num ", N)
            system(cmd)
            accept <-
                read.table("hmm-pimh.accept.save", header = TRUE)$Accept.Rate
            acc <- rbind(acc, c(N, D, mean(accept)))
        }
    }
    acc.dat <- data.frame(
        Particle.Number = acc[,1],
        Time.Steps = as.factor(acc[,2]),
        Accept.Rate = acc[,3])
    acc.plot <- ggplot(acc.dat)
    acc.plot <- acc.plot + aes(
        x = Particle.Number, y= Accept.Rate,
        group = Time.Steps, color = Time.Steps,
        shape = Time.Steps, linetype = Time.Steps)
    acc.plot <- acc.plot + geom_line() + geom_point()
    list(Data = acc.dat, Plot = acc.plot)
}

acc.10.10 <- simulate(10, 10)
acc.10.1 <- simulate(10, 1)
