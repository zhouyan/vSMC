suppressPackageStartupMessages(library(ggplot2))

Obs <- read.table("hmm.data")$V1
Est <- read.table("hmm-smc.sampler.save", header = TRUE)$obs.1
