#include "hmm_@smp@.hpp"
#include "hmm_progress.hpp"

inline std::size_t hmm_pimh_do (vsmc::Sampler<hmm_state> &sampler,
        std::size_t iter_num)
{
    sampler.initialize();
    sampler.iterate(sampler.particle().value().data_num() - 1);
    hmm_param param(hmm_draw(sampler.particle()));
    double llh = hmm_zconst(sampler.monitor("zconst"));

    vsmc::cxx11::uniform_real_distribution<double> runif(0, 1);
    std::size_t acc = 0;
    hmm_param param_next;
    for (std::size_t i = 0; i != iter_num; ++i) {
        sampler.initialize();
        sampler.iterate(sampler.particle().value().data_num() - 1);
        param_next = hmm_draw(sampler.particle());
        double llh_next = hmm_zconst(sampler.monitor("zconst"));
        double u = std::log(runif(sampler.particle().rng(0)));
        if (u < llh_next - llh) {
            param = param_next;
            llh = llh_next;
            ++acc;
        }
        print_progress(i);
    }
    std::fprintf(stderr, "\n");

    return acc;
}

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "hmm_options.hpp"
#include "hmm_options_mcmc.hpp"
#include "options_process.hpp"

    vsmc::Sampler<hmm_state> sampler(ParticleNum, vsmc::Stratified, Threshold);
    sampler.init(hmm_init()).mcmc(hmm_move(), true);
    sampler.monitor("zconst", 1, hmm_incw());
    sampler.particle().value().sd_init() = std::sqrt(VarInit);
    sampler.particle().value().sd_move() = std::sqrt(VarMove);
    sampler.particle().value().sd_obs()  = std::sqrt(VarObs);

    data_info info(DataNum, DataFile.c_str());
    sampler.initialize(&info);

    std::string accept_file_name("hmm_pimh.accept." + Suffix);
    std::ofstream accept_file;
    accept_file.open(accept_file_name.c_str());
    accept_file << "Accept.Rate" << std::endl;
    for (std::size_t r = 0; r != Repeat; ++r) {
        if (Repeat > 1) std::cout << "\n\nRun: " << r << std::endl;
        hmm_pimh_do(sampler, BurninNum);
        double ar =  hmm_pimh_do(sampler, IterNum) /
            static_cast<double>(IterNum);
        accept_file << ar << std::endl;
    }
    accept_file.close();
    accept_file.clear();

    return 0;
}
