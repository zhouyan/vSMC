#include <vsmc/cxx11/random.hpp>
#include <vsmc/utility/program_option.hpp>
#include <fstream>

int main (int argc, char **argv)
{
    int N = 0;
    std::string data_file;
    double VarInit = 0;
    double VarMove = 0;
    double VarObs = 0;

    vsmc::ProgramOptionMap Config;
    Config
        .add("data_num",  "Number of data: ",     &N,         100)
        .add("data_file", "Output file name: ",   &data_file, "hmm.data")
        .add("var_init",  "Initialize variance",  &VarInit,   5)
        .add("var_move",  "Update move variance", &VarMove,   10)
        .add("var_obs",   "Observation variance", &VarObs,    10);
    Config.process(argc, argv);

    vsmc::cxx11::mt19937 eng;
    vsmc::cxx11::normal_distribution<double> rx(0, std::sqrt(VarInit));
    vsmc::cxx11::normal_distribution<double> rv(0, std::sqrt(VarMove));
    vsmc::cxx11::normal_distribution<double> rw(0, std::sqrt(VarObs));

    std::ofstream data(data_file.c_str());
    double X = rx(eng);
    for (int i = 0; i != N; ++i) {
        data << (0.05 * X * X + rw(eng)) << '\n';
        X = 0.5 * X + 25 * X / (1 + X * X) + 8 * std::cos(1.2 * (i + 1));
        X += rv(eng);
    }
    data.close();
    data.clear();

    return 0;
}
