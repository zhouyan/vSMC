#include "hmm_@smp@.hpp"

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "hmm_options.hpp"
#include "options_process.hpp"

    vsmc::Sampler<hmm_state> sampler(ParticleNum, vsmc::Stratified, Threshold);
    sampler.init(hmm_init()).mcmc(hmm_move(), true);
    sampler.monitor("est", 1, hmm_est());
    sampler.monitor("zconst", 1, hmm_incw());
    sampler.particle().value().sd_init() = std::sqrt(VarInit);
    sampler.particle().value().sd_move() = std::sqrt(VarMove);
    sampler.particle().value().sd_obs()  = std::sqrt(VarObs);

    data_info info(DataNum, DataFile.c_str());
    sampler.initialize(&info);

    std::string zconst_file_name("hmm-smc.zconst." + Suffix);
    std::ofstream zconst_file;
    zconst_file.open(zconst_file_name.c_str());
    zconst_file << "Log.Normalizing.Constant" << std::endl;
    for (std::size_t r = 0; r != Repeat; ++r) {
        if (Repeat > 1) std::cout << "\n\nRun: " << r << std::endl;
        sampler.initialize();
        sampler.iterate(DataNum - 1);
        double z = hmm_zconst(sampler.monitor("zconst")) +
            sampler.particle().value().log_likelihood_const();
        zconst_file << z << std::endl;
    }
    zconst_file.close();
    zconst_file.clear();

    std::string save_file_name("hmm-smc.sampler." + Suffix);
    std::ofstream save_file;
    save_file.open(save_file_name.c_str());
    save_file << sampler << std::endl;
    save_file.close();
    save_file.clear();

    return 0;
}
