#include "hmm_@smp@.hpp"
#include "hmm_progress.hpp"

const double PriorA = 0.01;
const double PriorB = 100;

inline double hmm_log_prior (double sd_move, double sd_obs)
{
    if (sd_move <= 0 || sd_obs <= 0)
        return std::numeric_limits<double>::min VSMC_MNE ();

    static const double pa1 = PriorA - 1;
    static const double pbi = 1 / PriorB;
    double p_move = 1 / (sd_move * sd_move);
    double p_obs = 1 / (sd_obs * sd_obs);
    double lp = 0;
    lp += pa1 * std::log(p_move) - pbi * p_move;
    lp += pa1 * std::log(p_obs) - pbi * p_obs;

    return lp;
}

inline std::size_t hmm_pmmh_do (vsmc::Sampler<hmm_state> &sampler,
        std::size_t iter_num, double &sd_move_init, double &sd_obs_init,
        std::vector<double> &sd_move_trace,
        std::vector<double> &sd_obs_trace)
{
    sd_move_trace.clear();
    sd_obs_trace.clear();
    double sd_move = sd_move_init;
    double sd_obs = sd_obs_init;
    sampler.particle().value().sd_move() = sd_move;
    sampler.particle().value().sd_obs()  = sd_obs;
    sampler.initialize();
    sampler.iterate(sampler.particle().value().data_num() - 1);
    hmm_param param(hmm_draw(sampler.particle()));
    double llh = hmm_zconst(sampler.monitor("zconst"));

    vsmc::cxx11::uniform_real_distribution<double> runif(0, 1);
    vsmc::cxx11::normal_distribution<double> rnorm_move(0, 0.15);
    vsmc::cxx11::normal_distribution<double> rnorm_obs(0, 0.08);
    std::size_t acc = 0;
    hmm_param param_next;
    for (std::size_t i = 0; i != iter_num; ++i) {
        double sd_move_next = sd_move += rnorm_move(sampler.particle().rng(0));
        double sd_obs_next = sd_obs += rnorm_obs(sampler.particle().rng(0));
        sampler.particle().value().sd_move() = sd_move_next;
        sampler.particle().value().sd_obs()  = sd_obs_next;
        sampler.initialize();
        sampler.iterate(sampler.particle().value().data_num() - 1);
        param_next = hmm_draw(sampler.particle());
        double llh_next = hmm_zconst(sampler.monitor("zconst"));
        double u = std::log(runif(sampler.particle().rng(0)));
        double p = 0;
        p += llh_next + hmm_log_prior(sd_move_next, sd_obs_next);
        p -= llh + hmm_log_prior(sd_move, sd_obs);
        if (u < p) {
            param = param_next;
            llh = llh_next;
            sd_move = sd_move_next;
            sd_obs = sd_obs_next;
            ++acc;
        }

        sd_move_trace.push_back(sd_move);
        sd_obs_trace.push_back(sd_obs);
        print_progress(i);
    }
    std::fprintf(stderr, "\n");

    return acc;
}

int main (int argc, char *argv[])
{
#include "options_main.hpp"
#include "hmm_options.hpp"
#include "hmm_options_mcmc.hpp"
#include "options_process.hpp"

    vsmc::Sampler<hmm_state> sampler(ParticleNum, vsmc::Stratified, Threshold);
    sampler.init(hmm_init()).mcmc(hmm_move(), true);
    sampler.monitor("zconst", 1, hmm_incw());
    sampler.particle().value().sd_init() = std::sqrt(VarInit);
    sampler.particle().value().sd_move() = std::sqrt(VarMove);
    sampler.particle().value().sd_obs()  = std::sqrt(VarObs);

    data_info info(DataNum, DataFile.c_str());
    sampler.initialize(&info);

    std::vector<double> sd_move_trace;
    std::vector<double> sd_obs_trace;
    std::string sd_est_file_name("hmm-pmmh.est." + Suffix);
    std::ofstream sd_est_file;
    sd_est_file.open(sd_est_file_name.c_str());
    sd_est_file << "Accept.Rate\tSigma.Move\tSigma.Obs" << std::endl;
    for (std::size_t r = 0; r != Repeat; ++r) {
        if (Repeat > 1) std::cout << "\n\nRun: " << r << std::endl;
        double sd_move_init = std::sqrt(VarMove);
        double sd_obs_init = std::sqrt(VarObs);
        hmm_pmmh_do(sampler, BurninNum,
                sd_move_init, sd_obs_init, sd_move_trace, sd_obs_trace);
        double ar = hmm_pmmh_do(sampler, IterNum,
                    sd_move_init, sd_obs_init, sd_move_trace, sd_obs_trace) /
            static_cast<double>(IterNum);
        double sd_move_mean = 0;
        for (std::size_t i = 0; i != sd_move_trace.size(); ++i)
            sd_move_mean += sd_move_trace[i];
        sd_move_mean /= IterNum;
        double sd_obs_mean = 0;
        for (std::size_t i = 0; i != sd_obs_trace.size(); ++i)
            sd_obs_mean += sd_obs_trace[i];
        sd_obs_mean /= IterNum;
        sd_est_file << ar
            << '\t' << sd_move_mean << '\t' << sd_obs_mean << std::endl;
    }
    sd_est_file.close();
    sd_est_file.clear();

    std::string sd_trace_file_name("hmm_pmmh.trace." + Suffix);
    std::ofstream sd_trace_file;
    sd_trace_file.open(sd_trace_file_name.c_str());
    sd_trace_file << "Sigma.Move Sigma.Obs\n";
    for (std::size_t i = 0; i != sd_move_trace.size(); ++i)
        sd_trace_file << sd_move_trace[i] << '\t' << sd_obs_trace[i] << '\n';
    sd_trace_file.close();
    sd_trace_file.clear();

    return 0;
}
