# Hidden Markov chain

This example implements particle Markov chain Monte Carlo algorithms for the
hidden Markov chain model found in:

Andrieu, C., Doucet, A., & Holenstein, R. (2010). Particle markov chain monte
carlo methods. Journal of the Royal Statistical Society: Series B (Statistical
Methodology), 72(3), 269-342.

## Algorithms

- `hmm_pimh`: Particle independent Metropolis-Hastings
- `hmm_pmmh`: Particle marginal Metropolis-Hastings
- `hmm_smc`: Sequential Monte Carlo

## Extras

- `hmm_data`: The program that generates the data
