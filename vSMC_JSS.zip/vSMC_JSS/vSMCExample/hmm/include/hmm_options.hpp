Config
.add("threshold",    "Threshold of ESS/N",   &Threshold, 0.5)
.add("particle_num", "Particle number",      &ParticleNum, 1000)
.add("data_file",    "Name of data file",    &DataFile,"hmm.data")
.add("data_num",     "Number of data",       &DataNum, 100)
.add("var_init",     "Initialize variance",  &VarInit, 5)
.add("var_move",     "Update move variance", &VarMove, 10)
.add("var_obs",      "Observation variance", &VarObs,  10);
