#ifndef VSMC_EXAMPLE_HMM_PROGRESS_HPP
#define VSMC_EXAMPLE_HMM_PROGRESS_HPP

#include <cstdio>

inline void print_progress (std::size_t iter_num)
{
    if (iter_num == 0) {
        std::fprintf(stderr, "\n");
        for (int i = 0; i != 78; ++i)
            std::fprintf(stderr, "=");
        std::fprintf(stderr, "\n");
        std::fprintf(stderr, "%6u", static_cast<unsigned>(iter_num));
        return;
    }

    if (!(iter_num % 5000))
        std::fprintf(stderr, "\n%6u", static_cast<unsigned>(iter_num));
    else if (!(iter_num % 100))
        std::fprintf(stderr, ".");
}
#endif // VSMC_EXAMPLE_HMM_PROGRESS_HPP
