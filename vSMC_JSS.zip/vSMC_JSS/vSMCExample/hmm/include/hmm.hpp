#ifndef VSMC_EXAMPLE_HMM_HPP
#define VSMC_EXAMPLE_HMM_HPP

#define BASE_STATE   vsmc::State@SMP@
#define BASE_INIT    vsmc::Initialize@SMP@
#define BASE_MOVE    vsmc::Move@SMP@
#define BASE_MONITOR vsmc::MonitorEval@SMP@

#include <vsmc/smp/backend_@smp@.hpp>

static double Threshold;
static std::size_t ParticleNum;
static std::size_t DataNum;
static std::string DataFile;
static double VarInit;
static double VarMove;
static double VarObs;

#include "common.hpp"
#include "hmm_param.hpp"
#include "hmm_state.hpp"
#include "hmm_init.hpp"
#include "hmm_move.hpp"
#include "hmm_monitor.hpp"

#endif // VSMC_EXAMPLE_HMM_HPP
