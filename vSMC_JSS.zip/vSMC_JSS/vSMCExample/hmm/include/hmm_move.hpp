#ifndef VSMC_EXAMPLE_HMM_MOVE_HPP
#define VSMC_EXAMPLE_HMM_MOVE_HPP

class hmm_move : public BASE_MOVE<hmm_state, hmm_move>
{
    public :

    std::size_t move_state (std::size_t, vsmc::SingleParticle<hmm_state> sp)
    {
        sp.state(0).update(sd_move_, sp.rng());
        inc_weight_[sp.id()] = sp.state(0).log_likelihood(obs_, sd_obs_);

        return 0;
    }

    void pre_processor (std::size_t iter, vsmc::Particle<hmm_state> &particle)
    {
        obs_ = particle.value().obs(iter);
        sd_obs_ = particle.value().sd_obs();
        sd_move_ = particle.value().sd_move();
        inc_weight_.resize(particle.size());
    }

    void post_processor (std::size_t, vsmc::Particle<hmm_state> &particle)
    {particle.weight_set().add_log_weight(&inc_weight_[0]);}

    private :

    double obs_;
    double sd_obs_;
    double sd_move_;
    std::vector<double> inc_weight_;
};

#endif // VSMC_EXAMPLE_HMM_MOVE_HPP
