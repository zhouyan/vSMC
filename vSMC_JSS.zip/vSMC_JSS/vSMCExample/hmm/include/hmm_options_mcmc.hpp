std::size_t IterNum;
std::size_t BurninNum;
Config
.add("iter_num",   "Iteration number", &IterNum,   1000)
.add("burnin_num", "Burnin number",    &BurninNum, 0);
