#ifndef VSMC_EXAMPLE_HMM_PARAM_HPP
#define VSMC_EXAMPLE_HMM_PARAM_HPP

class hmm_param
{
    public :

    hmm_param () : data_num_(0), rnorm_(0, 1) {}

    std::size_t time () const {return time_;}

    std::size_t ancestor (std::size_t t) const {return ancestor_[t];}
    std::size_t &ancestor (std::size_t t) {return ancestor_[t];}

    double state (std::size_t t) const {return state_[t];}
    double &state (std::size_t t) {return state_[t];}

    double log_likelihood (std::size_t t) const {return llh_[t];}
    double &log_likelihood (std::size_t t) {return llh_[t];}

    // weight X(t) after call of propose(t, ...)
    double log_likelihood (double y, double sd)
    {
        double mean = state_[time_];
        mean = 0.05 * mean * mean;
        double res = y - mean;

        return llh_[time_] = -0.5 * res * res / (sd * sd);
    }

    std::size_t data_num () const {return data_num_;}

    void data_num (std::size_t num)
    {
        if (data_num_ < num) {
            grow(num, ancestor_);
            grow(num, state_);
            grow(num, llh_);
        }
        data_num_ = num;
    }

    // initialize x(0)
    template <typename URNG>
    void init (std::size_t id, double sd, URNG &eng)
    {
        time_ = 0;
        for (std::size_t i = 0; i != data_num_; ++i)
            ancestor_[i] = id;
        state_[0] = sd * rnorm_(eng);
    }

    // propose X(t) from X(t-1)
    template <typename URNG>
    void update (double sd, URNG &eng)
    {
        using std::cos;

        double x = state_[time_];
        ++time_;
        x = 0.5 * x + 25 * x / (1 + x * x) + 8 * cos(1.2 * time_);
        state_[time_] = x + sd * rnorm_(eng);
    }

    private :

    std::size_t data_num_;
    std::size_t time_;
    std::vector<std::size_t> ancestor_;
    std::vector<double> state_;
    std::vector<double> llh_;
    vsmc::cxx11::normal_distribution<double> rnorm_;
};

#endif // VSMC_EXAMPLE_HMM_PARAM_HPP
