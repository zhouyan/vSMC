#!/bin/bash

if [ -z "$1" ]; then
    if [[ `uname` == Darwin ]]; then
        makeopt=-j`sysctl -n hw.ncpu`
    elif [[ `uname` == Linux ]]; then
        makeopt=-j`grep -c ^processor /proc/cpuinfo`
    else
        makeopt=-j1
    fi
else
    makeopt=$1
fi

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DIR_SOURCE=$DIR
DIR_BUILD=$DIR/Build
DIR_FIGURE=$DIR/Figure

rm -rf $DIR_BUILD
rm -rf $DIR_FIGURE
mkdir -p $DIR_BUILD
mkdir -p $DIR_FIGURE

cd $DIR_BUILD
echo "================================================================================"
echo "Configuring ... "
echo "================================================================================"
cmake $DIR_SOURCE -DCMAKE_BUILD_TYPE=Release
echo "================================================================================"
echo "Configuring ... DONE"
echo "================================================================================"

echo "================================================================================"
echo "Building examples ... "
echo "================================================================================"
make $makeopt example-benchmark.R
make $makeopt gmm_smc
make $makeopt gmm-files
make $makeopt paper_pf
make $makeopt paper-files
echo "================================================================================"
echo "Building examples ... DONE"
echo "================================================================================"

echo "================================================================================"
echo "Running Particle filter example ... "
echo "================================================================================"
cd $DIR_BUILD/vSMCExample/paper
./paper_pf
Rscript paper_pf.R
cp pf.pdf $DIR_FIGURE/.
echo "================================================================================"
echo "Running Particle filter example ... DONE"
echo "================================================================================"

echo "================================================================================"
echo "Running Gaussian Mixture Model example ... "
echo "================================================================================"
cd $DIR_BUILD/vSMCExample/gmm
../benchmark.R
cp *-running.pdf $DIR_FIGURE/.
echo "================================================================================"
echo "Running Gaussian Mixture Model example ... DONE"
echo "================================================================================"

echo "================================================================================"
echo "Results of examples are in $DIR_FIGURE"
echo "================================================================================"
